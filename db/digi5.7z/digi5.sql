-- MySQL dump 10.13  Distrib 5.7.10, for linux-glibc2.5 (x86_64)
--
-- Host: localhost    Database: digi5
-- ------------------------------------------------------
-- Server version	5.7.10-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `apis_address`
--

DROP TABLE IF EXISTS `apis_address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `apis_address` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `address_base_id` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '1 = Cliente',
  `address_ref_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT 'id para fazer a ligacao com a tabela a quem pertence o endereco',
  `address_type_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'tipo do endereco',
  `public_place` varchar(100) NOT NULL DEFAULT '' COMMENT 'logradouro',
  `number` varchar(10) NOT NULL DEFAULT 'S/N' COMMENT 'numero',
  `complement` varchar(30) DEFAULT NULL COMMENT 'complemento',
  `neighborhood` varchar(100) NOT NULL DEFAULT 'neighborhood' COMMENT 'bairro',
  `city` varchar(40) NOT NULL DEFAULT '' COMMENT 'cidade',
  `state` char(2) NOT NULL DEFAULT '' COMMENT 'estado',
  `country` char(3) NOT NULL DEFAULT 'BRA' COMMENT 'pais',
  `zip` varchar(8) NOT NULL DEFAULT '' COMMENT 'cep',
  `lat` decimal(18,10) DEFAULT NULL COMMENT 'latitude',
  `lng` decimal(18,10) DEFAULT NULL COMMENT 'longitude',
  `status_origin_id` int(11) unsigned NOT NULL DEFAULT '1' COMMENT 'id da origem do status',
  `status_code` int(11) unsigned NOT NULL DEFAULT '1' COMMENT 'status do registro',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'data de criacao',
  `updated` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT 'data de updated',
  PRIMARY KEY (`id`),
  KEY `address_type_id` (`address_type_id`),
  KEY `address_key` (`address_base_id`,`address_ref_id`,`address_type_id`),
  CONSTRAINT `fk_apis_address_address_types` FOREIGN KEY (`address_type_id`) REFERENCES `apis_address_types` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Endereco do cliente';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `apis_address`
--

LOCK TABLES `apis_address` WRITE;
/*!40000 ALTER TABLE `apis_address` DISABLE KEYS */;
/*!40000 ALTER TABLE `apis_address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `apis_address_types`
--

DROP TABLE IF EXISTS `apis_address_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `apis_address_types` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL DEFAULT '' COMMENT 'tipo de endereco',
  `status_origin_id` int(11) unsigned NOT NULL DEFAULT '1' COMMENT 'id da origem do status',
  `status_code` int(11) unsigned NOT NULL DEFAULT '1' COMMENT 'status do registro',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'data de criacao',
  `updated` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT 'data de updated',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `fk_address_type_status` (`status_origin_id`,`status_code`),
  CONSTRAINT `fk_address_type_status` FOREIGN KEY (`status_origin_id`, `status_code`) REFERENCES `apis_status` (`status_origin_id`, `status_code`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='Lista de tipos de endereco';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `apis_address_types`
--

LOCK TABLES `apis_address_types` WRITE;
/*!40000 ALTER TABLE `apis_address_types` DISABLE KEYS */;
INSERT INTO `apis_address_types` VALUES (1,'Residencial',1,2,'2018-08-21 20:13:30','2018-08-21 21:06:10');
/*!40000 ALTER TABLE `apis_address_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `apis_company_auth_users`
--

DROP TABLE IF EXISTS `apis_company_auth_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `apis_company_auth_users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'id da compania',
  `user_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'id do usuario',
  `status_origin_id` int(11) unsigned NOT NULL DEFAULT '1' COMMENT 'id da origem do status',
  `status_code` int(11) unsigned NOT NULL DEFAULT '1' COMMENT 'status do registro',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'data de criacao',
  `updated` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT 'data de atualizacao',
  PRIMARY KEY (`id`),
  KEY `campany_id` (`company_id`),
  KEY `created` (`created`),
  KEY `status_code` (`status_code`),
  KEY `updated` (`updated`),
  KEY `user_id` (`user_id`),
  KEY `fk_company_user_status` (`status_origin_id`,`status_code`),
  CONSTRAINT `fk_company_auth_user_status` FOREIGN KEY (`status_origin_id`, `status_code`) REFERENCES `apis_status` (`status_origin_id`, `status_code`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_company_auth_user_user` FOREIGN KEY (`user_id`) REFERENCES `apis_users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='Relacao entre companhias e usuarios';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `apis_company_auth_users`
--

LOCK TABLES `apis_company_auth_users` WRITE;
/*!40000 ALTER TABLE `apis_company_auth_users` DISABLE KEYS */;
INSERT INTO `apis_company_auth_users` VALUES (1,1,1,1,2,'2018-08-14 19:07:20','2018-08-14 19:07:29'),(2,2,2,1,2,'2018-09-10 17:30:35',NULL);
/*!40000 ALTER TABLE `apis_company_auth_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `apis_companys`
--

DROP TABLE IF EXISTS `apis_companys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `apis_companys` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(60) NOT NULL DEFAULT '' COMMENT 'nome da companhia',
  `status_origin_id` int(11) unsigned NOT NULL DEFAULT '1' COMMENT 'id da origem do status',
  `status_code` int(11) unsigned NOT NULL DEFAULT '1' COMMENT 'status do registro',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'data de criacao',
  `updated` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT 'data de atualizacao',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `created` (`created`),
  KEY `status_code` (`status_code`),
  KEY `updated` (`updated`),
  KEY `fk_company_status` (`status_origin_id`,`status_code`),
  CONSTRAINT `fk_company_status` FOREIGN KEY (`status_origin_id`, `status_code`) REFERENCES `apis_status` (`status_origin_id`, `status_code`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='Companhias';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `apis_companys`
--

LOCK TABLES `apis_companys` WRITE;
/*!40000 ALTER TABLE `apis_companys` DISABLE KEYS */;
INSERT INTO `apis_companys` VALUES (1,'Digi5',1,2,'2018-08-13 19:47:29','2018-08-13 19:47:49'),(2,'VidaClass',1,2,'2018-08-21 16:29:21',NULL);
/*!40000 ALTER TABLE `apis_companys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `apis_credit_card`
--

DROP TABLE IF EXISTS `apis_credit_card`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `apis_credit_card` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `credit_card_base_id` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT 'cliente',
  `credit_card_ref_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT 'id para fazer a ligacao com a tabela a quem pertence o cartao',
  `card_brand_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'id da bandeira do cartao',
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT 'nome impresso no cartao',
  `number` varchar(20) NOT NULL DEFAULT '' COMMENT 'numero do cartao',
  `expire_month` char(2) NOT NULL DEFAULT '' COMMENT 'mes valida cartao',
  `expire_year` char(4) NOT NULL DEFAULT '' COMMENT 'ano validade cartao',
  `secure_code` char(4) NOT NULL DEFAULT '' COMMENT 'codigo de seguranca',
  `status_origin_id` int(11) unsigned NOT NULL DEFAULT '1' COMMENT 'id da origem do status',
  `status_code` int(11) unsigned NOT NULL DEFAULT '1' COMMENT 'status do registro',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'data da criacao',
  `updated` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT 'data da ultima alteracao do registro',
  PRIMARY KEY (`id`),
  KEY `created` (`created`),
  KEY `updated` (`updated`),
  KEY `fk_credit_card_status` (`status_origin_id`,`status_code`),
  KEY `fk_credit_card_card_brands` (`card_brand_id`),
  KEY `credit_card_key` (`credit_card_base_id`,`credit_card_ref_id`,`status_code`),
  CONSTRAINT `fk_credit_card_card_brands` FOREIGN KEY (`card_brand_id`) REFERENCES `pay_card_brands` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_credit_card_status` FOREIGN KEY (`status_origin_id`, `status_code`) REFERENCES `apis_status` (`status_origin_id`, `status_code`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Base de cartoes Cartoes';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `apis_credit_card`
--

LOCK TABLES `apis_credit_card` WRITE;
/*!40000 ALTER TABLE `apis_credit_card` DISABLE KEYS */;
/*!40000 ALTER TABLE `apis_credit_card` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `apis_document_emitters`
--

DROP TABLE IF EXISTS `apis_document_emitters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `apis_document_emitters` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT 'tipo de emissor do documento',
  `status_origin_id` int(11) unsigned DEFAULT '1' COMMENT 'id da origem do status',
  `status_code` int(11) unsigned NOT NULL DEFAULT '1' COMMENT 'status do registro',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'data de criacao',
  `updated` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT 'data de updated',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `fk_document_emitter_status` (`status_origin_id`,`status_code`),
  CONSTRAINT `fk_document_emitter_status` FOREIGN KEY (`status_origin_id`, `status_code`) REFERENCES `apis_status` (`status_origin_id`, `status_code`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='Lista de tipos de documento';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `apis_document_emitters`
--

LOCK TABLES `apis_document_emitters` WRITE;
/*!40000 ALTER TABLE `apis_document_emitters` DISABLE KEYS */;
INSERT INTO `apis_document_emitters` VALUES (1,'OUTROS',1,2,'2018-08-22 15:14:33',NULL);
/*!40000 ALTER TABLE `apis_document_emitters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `apis_document_types`
--

DROP TABLE IF EXISTS `apis_document_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `apis_document_types` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT 'tipo de documento',
  `status_origin_id` int(11) unsigned DEFAULT '1' COMMENT 'id da origem do status',
  `status_code` int(11) unsigned NOT NULL DEFAULT '1' COMMENT 'status do registro',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'data de criacao',
  `updated` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT 'data de updated',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `fk_document_type_status` (`status_origin_id`,`status_code`),
  CONSTRAINT `fk_document_type_status` FOREIGN KEY (`status_origin_id`, `status_code`) REFERENCES `apis_status` (`status_origin_id`, `status_code`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='Lista de tipos de documento';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `apis_document_types`
--

LOCK TABLES `apis_document_types` WRITE;
/*!40000 ALTER TABLE `apis_document_types` DISABLE KEYS */;
INSERT INTO `apis_document_types` VALUES (1,'RG',1,2,'2018-08-22 15:02:49',NULL),(2,'Passaporte',1,2,'2018-08-24 02:20:35',NULL);
/*!40000 ALTER TABLE `apis_document_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `apis_mail_types`
--

DROP TABLE IF EXISTS `apis_mail_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `apis_mail_types` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL DEFAULT '' COMMENT 'tipo de email',
  `status_origin_id` int(11) unsigned NOT NULL DEFAULT '1' COMMENT 'id da origem do status',
  `status_code` int(11) unsigned NOT NULL DEFAULT '1' COMMENT 'status do registro',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'data de criacao',
  `updated` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT 'data de updated',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `fk_mail_type_status` (`status_origin_id`,`status_code`),
  CONSTRAINT `fk_mail_type_status` FOREIGN KEY (`status_origin_id`, `status_code`) REFERENCES `apis_status` (`status_origin_id`, `status_code`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='Lista de tipos de email';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `apis_mail_types`
--

LOCK TABLES `apis_mail_types` WRITE;
/*!40000 ALTER TABLE `apis_mail_types` DISABLE KEYS */;
INSERT INTO `apis_mail_types` VALUES (1,'Pessoal',1,2,'2018-08-21 19:12:30',NULL),(2,'Comercial',1,2,'2018-08-23 21:23:22',NULL);
/*!40000 ALTER TABLE `apis_mail_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `apis_maritals`
--

DROP TABLE IF EXISTS `apis_maritals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `apis_maritals` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL DEFAULT '' COMMENT 'estado civil',
  `status_origin_id` int(11) unsigned NOT NULL DEFAULT '1' COMMENT 'id da origem do status',
  `status_code` int(11) unsigned NOT NULL DEFAULT '1' COMMENT 'status do registro',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'data de criacao',
  `updated` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT 'data de updated',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `fk_marital_status` (`status_origin_id`,`status_code`),
  CONSTRAINT `fk_customer_profession_status` FOREIGN KEY (`status_origin_id`, `status_code`) REFERENCES `apis_status` (`status_origin_id`, `status_code`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COMMENT='Lista de estado civil';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `apis_maritals`
--

LOCK TABLES `apis_maritals` WRITE;
/*!40000 ALTER TABLE `apis_maritals` DISABLE KEYS */;
INSERT INTO `apis_maritals` VALUES (1,'Casado',1,2,'2018-08-21 14:39:27',NULL),(2,'Divorciado(a)',1,2,'2018-08-21 14:40:06',NULL),(3,'Separado Judicialmente',1,2,'2018-08-21 14:40:21',NULL),(4,'Separado(a)',1,2,'2018-08-21 14:40:34',NULL),(5,'Desquitado(a)',1,2,'2018-08-21 14:40:53',NULL),(6,'Solteiro(a)',1,2,'2018-08-21 14:41:06',NULL),(7,'Outros',1,2,'2018-08-21 14:41:19',NULL),(8,'União Estável',1,2,'2018-08-21 14:41:32',NULL),(9,'Viuvo(a)',1,2,'2018-08-21 14:41:50',NULL);
/*!40000 ALTER TABLE `apis_maritals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `apis_occupations`
--

DROP TABLE IF EXISTS `apis_occupations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `apis_occupations` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL DEFAULT '' COMMENT 'profissao',
  `status_origin_id` int(11) unsigned NOT NULL DEFAULT '5' COMMENT 'id da origem do status',
  `status_code` int(11) unsigned NOT NULL DEFAULT '1' COMMENT 'status do registro',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'data de criacao',
  `updated` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT 'data de updated',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `fk_occupation_status` (`status_origin_id`,`status_code`) USING BTREE,
  CONSTRAINT `fk_occupation_status` FOREIGN KEY (`status_origin_id`, `status_code`) REFERENCES `apis_status` (`status_origin_id`, `status_code`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=4096 DEFAULT CHARSET=utf8 COMMENT='Lista de profissoes';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `apis_occupations`
--

LOCK TABLES `apis_occupations` WRITE;
/*!40000 ALTER TABLE `apis_occupations` DISABLE KEYS */;
INSERT INTO `apis_occupations` VALUES (1,'Abatedor',1,2,'2018-08-21 14:15:54',NULL),(2,'Acabador de calçados',1,2,'2018-08-21 14:15:54',NULL),(3,'Acabador de embalagens (flexíveis e cartotécnicas)',1,2,'2018-08-21 14:15:54',NULL),(4,'Acabador de superfícies de concreto',1,2,'2018-08-21 14:15:54',NULL),(5,'Açougueiro',1,2,'2018-08-21 14:15:54',NULL),(6,'Acrobata',1,2,'2018-08-21 14:15:54',NULL),(7,'Adestrador de animais',1,2,'2018-08-21 14:15:54',NULL),(8,'Administrador',1,2,'2018-08-21 14:15:54',NULL),(9,'Administrador de banco de dados',1,2,'2018-08-21 14:15:54',NULL),(10,'Administrador de edifícios',1,2,'2018-08-21 14:15:54',NULL),(11,'Administrador de fundos e carteiras de investimento',1,2,'2018-08-21 14:15:54',NULL),(12,'Administrador de redes',1,2,'2018-08-21 14:15:54',NULL),(13,'Administrador de sistemas operacionais',1,2,'2018-08-21 14:15:54',NULL),(14,'Administrador em segurança da informação',1,2,'2018-08-21 14:15:54',NULL),(15,'Advogado',1,2,'2018-08-21 14:15:54',NULL),(16,'Advogado (áreas especiais)',1,2,'2018-08-21 14:15:54',NULL),(17,'Advogado (direito civil)',1,2,'2018-08-21 14:15:54',NULL),(18,'Advogado (direito do trabalho)',1,2,'2018-08-21 14:15:54',NULL),(19,'Advogado (direito penal)',1,2,'2018-08-21 14:15:54',NULL),(20,'Advogado (direito público)',1,2,'2018-08-21 14:15:54',NULL),(21,'Advogado da união',1,2,'2018-08-21 14:15:54',NULL),(22,'Advogado de empresa',1,2,'2018-08-21 14:15:54',NULL),(23,'Afiador de cardas',1,2,'2018-08-21 14:15:54',NULL),(24,'Afiador de cutelaria',1,2,'2018-08-21 14:15:54',NULL),(25,'Afiador de ferramentas',1,2,'2018-08-21 14:15:54',NULL),(26,'Afiador de serras',1,2,'2018-08-21 14:15:54',NULL),(27,'Afinador de instrumentos musicais',1,2,'2018-08-21 14:15:54',NULL),(28,'Afretador',1,2,'2018-08-21 14:15:54',NULL),(29,'Agenciador de propaganda',1,2,'2018-08-21 14:15:54',NULL),(30,'Agente comunitário de saúde',1,2,'2018-08-21 14:15:54',NULL),(31,'Agente de ação social',1,2,'2018-08-21 14:15:54',NULL),(32,'Agente de combate às endemias',1,2,'2018-08-21 14:15:54',NULL),(33,'Agente de defesa ambiental',1,2,'2018-08-21 14:15:54',NULL),(34,'Agente de direitos autorais',1,2,'2018-08-21 14:15:54',NULL),(35,'Agente de estação (ferrovia e metrô)',1,2,'2018-08-21 14:15:54',NULL),(36,'Agente de higiene e segurança',1,2,'2018-08-21 14:15:54',NULL),(37,'Agente de inteligência',1,2,'2018-08-21 14:15:54',NULL),(38,'Agente de manobra e docagem',1,2,'2018-08-21 14:15:54',NULL),(39,'Agente de microcrédito',1,2,'2018-08-21 14:15:54',NULL),(40,'Agente de pátio',1,2,'2018-08-21 14:15:54',NULL),(41,'Agente de polícia federal',1,2,'2018-08-21 14:15:54',NULL),(42,'Agente de proteção de aeroporto',1,2,'2018-08-21 14:15:54',NULL),(43,'Agente de proteção de aviação civil',1,2,'2018-08-21 14:15:54',NULL),(44,'Agente de recrutamento e seleção',1,2,'2018-08-21 14:15:54',NULL),(45,'Agente de saúde pública',1,2,'2018-08-21 14:15:54',NULL),(46,'Agente de segurança',1,2,'2018-08-21 14:15:54',NULL),(47,'Agente de segurança penitenciária',1,2,'2018-08-21 14:15:54',NULL),(48,'Agente de trânsito',1,2,'2018-08-21 14:15:54',NULL),(49,'Agente de vendas de serviços',1,2,'2018-08-21 14:15:54',NULL),(50,'Agente de viagem',1,2,'2018-08-21 14:15:54',NULL),(51,'Agente fiscal de qualidade',1,2,'2018-08-21 14:15:54',NULL),(52,'Agente fiscal metrológico',1,2,'2018-08-21 14:15:54',NULL),(53,'Agente fiscal têxtil',1,2,'2018-08-21 14:15:54',NULL),(54,'Agente funerário',1,2,'2018-08-21 14:15:54',NULL),(55,'Agente indígena de saneamento',1,2,'2018-08-21 14:15:54',NULL),(56,'Agente indígena de saúde',1,2,'2018-08-21 14:15:54',NULL),(57,'Agente técnico de inteligência',1,2,'2018-08-21 14:15:54',NULL),(58,'Ajudante de carvoaria',1,2,'2018-08-21 14:15:54',NULL),(59,'Ajudante de confecção',1,2,'2018-08-21 14:15:54',NULL),(60,'Ajudante de despachante aduaneiro',1,2,'2018-08-21 14:15:54',NULL),(61,'Ajudante de motorista',1,2,'2018-08-21 14:15:54',NULL),(62,'Ajustador de instrumentos de precisão',1,2,'2018-08-21 14:15:54',NULL),(63,'Ajustador ferramenteiro',1,2,'2018-08-21 14:15:54',NULL),(64,'Ajustador mecânico',1,2,'2018-08-21 14:15:54',NULL),(65,'Ajustador mecânico (usinagem em bancada e em máquinas-ferramentas)',1,2,'2018-08-21 14:15:54',NULL),(66,'Ajustador mecânico em bancada',1,2,'2018-08-21 14:15:54',NULL),(67,'Ajustador naval (reparo e construção)',1,2,'2018-08-21 14:15:54',NULL),(68,'Alambiqueiro',1,2,'2018-08-21 14:15:54',NULL),(69,'Alfaiate',1,2,'2018-08-21 14:15:54',NULL),(70,'Alimentador de linha de produção',1,2,'2018-08-21 14:15:54',NULL),(71,'Alinhador de pneus',1,2,'2018-08-21 14:15:54',NULL),(72,'Almoxarife',1,2,'2018-08-21 14:15:54',NULL),(73,'Alvejador (tecidos)',1,2,'2018-08-21 14:15:54',NULL),(74,'Amostrador de minérios',1,2,'2018-08-21 14:15:54',NULL),(75,'Analista de câmbio',1,2,'2018-08-21 14:15:54',NULL),(76,'Analista de cobrança (instituições financeiras)',1,2,'2018-08-21 14:15:54',NULL),(77,'Analista de crédito (instituições financeiras)',1,2,'2018-08-21 14:15:54',NULL),(78,'Analista de crédito rural',1,2,'2018-08-21 14:15:54',NULL),(79,'Analista de desenvolvimento de sistemas',1,2,'2018-08-21 14:15:54',NULL),(80,'Analista de exportação e importação',1,2,'2018-08-21 14:15:54',NULL),(81,'Analista de folha de pagamento',1,2,'2018-08-21 14:15:54',NULL),(82,'Analista de informações (pesquisador de informações de rede)',1,2,'2018-08-21 14:15:54',NULL),(83,'Analista de leasing',1,2,'2018-08-21 14:15:54',NULL),(84,'Analista de negócios',1,2,'2018-08-21 14:15:54',NULL),(85,'Analista de pesquisa de mercado',1,2,'2018-08-21 14:15:54',NULL),(86,'Analista de planejamento e orçamento - apo',1,2,'2018-08-21 14:15:54',NULL),(87,'Analista de produtos bancários',1,2,'2018-08-21 14:15:54',NULL),(88,'Analista de recursos humanos',1,2,'2018-08-21 14:15:54',NULL),(89,'Analista de redes e de comunicação de dados',1,2,'2018-08-21 14:15:54',NULL),(90,'Analista de seguros (técnico)',1,2,'2018-08-21 14:15:54',NULL),(91,'Analista de sinistros',1,2,'2018-08-21 14:15:54',NULL),(92,'Analista de sistemas de automação',1,2,'2018-08-21 14:15:54',NULL),(93,'Analista de suporte computacional',1,2,'2018-08-21 14:15:54',NULL),(94,'Analista de transporte em comércio exterior',1,2,'2018-08-21 14:15:54',NULL),(95,'Analista financeiro (instituições financeiras)',1,2,'2018-08-21 14:15:54',NULL),(96,'Âncora de rádio e televisão',1,2,'2018-08-21 14:15:54',NULL),(97,'Antropólogo',1,2,'2018-08-21 14:15:54',NULL),(98,'Apicultor',1,2,'2018-08-21 14:15:54',NULL),(99,'Aplicador de asfalto impermeabilizante (coberturas)',1,2,'2018-08-21 14:15:54',NULL),(100,'Aplicador serigráfico em vidros',1,2,'2018-08-21 14:15:54',NULL),(101,'Apontador de mão-de-obra',1,2,'2018-08-21 14:15:54',NULL),(102,'Apontador de produção',1,2,'2018-08-21 14:15:54',NULL),(103,'Aposentado',1,2,'2018-08-21 14:15:54',NULL),(104,'Apresentador de circo',1,2,'2018-08-21 14:15:54',NULL),(105,'Apresentador de eventos',1,2,'2018-08-21 14:15:54',NULL),(106,'Apresentador de festas populares',1,2,'2018-08-21 14:15:54',NULL),(107,'Apresentador de programas de rádio',1,2,'2018-08-21 14:15:54',NULL),(108,'Apresentador de programas de televisão',1,2,'2018-08-21 14:15:54',NULL),(109,'Árbitro de atletismo',1,2,'2018-08-21 14:15:54',NULL),(110,'Árbitro de basquete',1,2,'2018-08-21 14:15:54',NULL),(111,'Árbitro de futebol',1,2,'2018-08-21 14:15:54',NULL),(112,'Árbitro de futebol de salão',1,2,'2018-08-21 14:15:54',NULL),(113,'Árbitro de judô',1,2,'2018-08-21 14:15:54',NULL),(114,'Árbitro de karatê',1,2,'2018-08-21 14:15:54',NULL),(115,'Árbitro de poló aquático',1,2,'2018-08-21 14:15:54',NULL),(116,'Árbitro de vôlei',1,2,'2018-08-21 14:15:54',NULL),(117,'Árbitro desportivo',1,2,'2018-08-21 14:15:54',NULL),(118,'Armador de estrutura de concreto',1,2,'2018-08-21 14:15:54',NULL),(119,'Armador de estrutura de concreto armado',1,2,'2018-08-21 14:15:54',NULL),(120,'Armazenista',1,2,'2018-08-21 14:15:54',NULL),(121,'Aromista',1,2,'2018-08-21 14:15:54',NULL),(122,'Arqueólogo',1,2,'2018-08-21 14:15:54',NULL),(123,'Arquiteto de edificações',1,2,'2018-08-21 14:15:54',NULL),(124,'Arquiteto de interiores',1,2,'2018-08-21 14:15:54',NULL),(125,'Arquiteto de patrimônio',1,2,'2018-08-21 14:15:54',NULL),(126,'Arquiteto paisagista',1,2,'2018-08-21 14:15:54',NULL),(127,'Arquiteto urbanista',1,2,'2018-08-21 14:15:54',NULL),(128,'Arquivista',1,2,'2018-08-21 14:15:54',NULL),(129,'Arquivista de documentos',1,2,'2018-08-21 14:15:54',NULL),(130,'Arquivista pesquisador (jornalismo)',1,2,'2018-08-21 14:15:54',NULL),(131,'Arrematadeira',1,2,'2018-08-21 14:15:54',NULL),(132,'Artesão bordador',1,2,'2018-08-21 14:15:54',NULL),(133,'Artesão ceramista',1,2,'2018-08-21 14:15:54',NULL),(134,'Artesão com material reciclável',1,2,'2018-08-21 14:15:54',NULL),(135,'Artesão confeccionador de biojóias e ecojóias',1,2,'2018-08-21 14:15:54',NULL),(136,'Artesão crocheteiro',1,2,'2018-08-21 14:15:54',NULL),(137,'Artesão do couro',1,2,'2018-08-21 14:15:54',NULL),(138,'Artesão escultor',1,2,'2018-08-21 14:15:54',NULL),(139,'Artesão modelador (vidros)',1,2,'2018-08-21 14:15:54',NULL),(140,'Artesão moveleiro (exceto reciclado)',1,2,'2018-08-21 14:15:54',NULL),(141,'Artesão rendeiro',1,2,'2018-08-21 14:15:54',NULL),(142,'Artesão tecelão',1,2,'2018-08-21 14:15:54',NULL),(143,'Artesão trançador',1,2,'2018-08-21 14:15:54',NULL),(144,'Artesão tricoteiro',1,2,'2018-08-21 14:15:54',NULL),(145,'Arteterapeuta',1,2,'2018-08-21 14:15:54',NULL),(146,'Artífice do couro',1,2,'2018-08-21 14:15:54',NULL),(147,'Artista (artes visuais)',1,2,'2018-08-21 14:15:54',NULL),(148,'Artista aéreo',1,2,'2018-08-21 14:15:54',NULL),(149,'Artista de circo (outros)',1,2,'2018-08-21 14:15:54',NULL),(150,'Ascensorista',1,2,'2018-08-21 14:15:54',NULL),(151,'Assentador de canalização (edificações)',1,2,'2018-08-21 14:15:54',NULL),(152,'Assessor de imprensa',1,2,'2018-08-21 14:15:54',NULL),(153,'Assistente administrativo',1,2,'2018-08-21 14:15:54',NULL),(154,'Assistente comercial de seguros',1,2,'2018-08-21 14:15:54',NULL),(155,'Assistente de coreografia',1,2,'2018-08-21 14:15:54',NULL),(156,'Assistente de laboratório industrial',1,2,'2018-08-21 14:15:54',NULL),(157,'Assistente de vendas',1,2,'2018-08-21 14:15:54',NULL),(158,'Assistente social',1,2,'2018-08-21 14:15:54',NULL),(159,'Assistente técnico de seguros',1,2,'2018-08-21 14:15:54',NULL),(160,'Assoalhador',1,2,'2018-08-21 14:15:54',NULL),(161,'Astrólogo',1,2,'2018-08-21 14:15:54',NULL),(162,'Astrônomo',1,2,'2018-08-21 14:15:54',NULL),(163,'Atendente comercial (agência postal)',1,2,'2018-08-21 14:15:54',NULL),(164,'Atendente de agência',1,2,'2018-08-21 14:15:54',NULL),(165,'Atendente de enfermagem',1,2,'2018-08-21 14:15:54',NULL),(166,'Atendente de farmácia - balconista',1,2,'2018-08-21 14:15:54',NULL),(167,'Atendente de judiciário',1,2,'2018-08-21 14:15:54',NULL),(168,'Atendente de lanchonete',1,2,'2018-08-21 14:15:54',NULL),(169,'Atendente de lavanderia',1,2,'2018-08-21 14:15:54',NULL),(170,'Atendente de lojas e mercados',1,2,'2018-08-21 14:15:54',NULL),(171,'Atleta profissional (outras modalidades)',1,2,'2018-08-21 14:15:54',NULL),(172,'Atleta profissional de futebol',1,2,'2018-08-21 14:15:54',NULL),(173,'Atleta profissional de golfe',1,2,'2018-08-21 14:15:54',NULL),(174,'Atleta profissional de luta',1,2,'2018-08-21 14:15:54',NULL),(175,'Atleta profissional de tênis',1,2,'2018-08-21 14:15:54',NULL),(176,'Ator',1,2,'2018-08-21 14:15:54',NULL),(177,'Atuário',1,2,'2018-08-21 14:15:54',NULL),(178,'Audiodescritor',1,2,'2018-08-21 14:15:54',NULL),(179,'Auditor (contadores e afins)',1,2,'2018-08-21 14:15:54',NULL),(180,'Auditor-fiscal da previdência social',1,2,'2018-08-21 14:15:54',NULL),(181,'Auditor-fiscal da receita federal',1,2,'2018-08-21 14:15:54',NULL),(182,'Auditor-fiscal do trabalho',1,2,'2018-08-21 14:15:54',NULL),(183,'Autor-roteirista',1,2,'2018-08-21 14:15:54',NULL),(184,'Auxiliar de banco de sangue',1,2,'2018-08-21 14:15:54',NULL),(185,'Auxiliar de biblioteca',1,2,'2018-08-21 14:15:54',NULL),(186,'Auxiliar de cartório',1,2,'2018-08-21 14:15:54',NULL),(187,'Auxiliar de contabilidade',1,2,'2018-08-21 14:15:54',NULL),(188,'Auxiliar de corte (preparação da confecção de roupas)',1,2,'2018-08-21 14:15:54',NULL),(189,'Auxiliar de desenvolvimento infantil',1,2,'2018-08-21 14:15:54',NULL),(190,'Auxiliar de enfermagem',1,2,'2018-08-21 14:15:54',NULL),(191,'Auxiliar de enfermagem da estratégia de saúde da família',1,2,'2018-08-21 14:15:54',NULL),(192,'Auxiliar de enfermagem do trabalho',1,2,'2018-08-21 14:15:54',NULL),(193,'Auxiliar de escritório',1,2,'2018-08-21 14:15:54',NULL),(194,'Auxiliar de estatística',1,2,'2018-08-21 14:15:54',NULL),(195,'Auxiliar de farmácia de manipulação',1,2,'2018-08-21 14:15:54',NULL),(196,'Auxiliar de faturamento',1,2,'2018-08-21 14:15:54',NULL),(197,'Auxiliar de judiciário',1,2,'2018-08-21 14:15:54',NULL),(198,'Auxiliar de laboratório de análises clínicas',1,2,'2018-08-21 14:15:54',NULL),(199,'Auxiliar de laboratório de análises físico-químicas',1,2,'2018-08-21 14:15:54',NULL),(200,'Auxiliar de laboratório de imunobiológicos',1,2,'2018-08-21 14:15:54',NULL),(201,'Auxiliar de lavanderia',1,2,'2018-08-21 14:15:54',NULL),(202,'Auxiliar de manutenção predial',1,2,'2018-08-21 14:15:54',NULL),(203,'Auxiliar de maquinista de trem',1,2,'2018-08-21 14:15:54',NULL),(204,'Auxiliar de pessoal',1,2,'2018-08-21 14:15:54',NULL),(205,'Auxiliar de processamento de fumo',1,2,'2018-08-21 14:15:54',NULL),(206,'Auxiliar de produção farmacêutica',1,2,'2018-08-21 14:15:54',NULL),(207,'Auxiliar de prótese dentária',1,2,'2018-08-21 14:15:54',NULL),(208,'Auxiliar de radiologia (revelação fotográfica)',1,2,'2018-08-21 14:15:54',NULL),(209,'Auxiliar de saúde (navegação marítima)',1,2,'2018-08-21 14:15:54',NULL),(210,'Auxiliar de seguros',1,2,'2018-08-21 14:15:54',NULL),(211,'Auxiliar de serviços de importação e exportação',1,2,'2018-08-21 14:15:54',NULL),(212,'Auxiliar de serviços jurídicos',1,2,'2018-08-21 14:15:54',NULL),(213,'Auxiliar de veterinário',1,2,'2018-08-21 14:15:54',NULL),(214,'Auxiliar em saúde bucal',1,2,'2018-08-21 14:15:54',NULL),(215,'Auxiliar em saúde bucal da estratégia de saúde da família',1,2,'2018-08-21 14:15:54',NULL),(216,'Auxiliar geral de conservação de vias permanentes (exceto trilhos)',1,2,'2018-08-21 14:15:54',NULL),(217,'Auxiliar nos serviços de alimentação',1,2,'2018-08-21 14:15:54',NULL),(218,'Auxiliar técnico em laboratório de farmácia',1,2,'2018-08-21 14:15:54',NULL),(219,'Avaliador de bens móveis',1,2,'2018-08-21 14:15:54',NULL),(220,'Avaliador de imóveis',1,2,'2018-08-21 14:15:54',NULL),(221,'Avaliador de produtos do meio de comunicação',1,2,'2018-08-21 14:15:54',NULL),(222,'Avaliador físico',1,2,'2018-08-21 14:15:54',NULL),(223,'Avicultor',1,2,'2018-08-21 14:15:54',NULL),(224,'Babá',1,2,'2018-08-21 14:15:54',NULL),(225,'Bailarino (exceto danças populares)',1,2,'2018-08-21 14:15:54',NULL),(226,'Balanceador',1,2,'2018-08-21 14:15:54',NULL),(227,'Balanceiro',1,2,'2018-08-21 14:15:54',NULL),(228,'Bamburista',1,2,'2018-08-21 14:15:54',NULL),(229,'Banhista de animais domésticos',1,2,'2018-08-21 14:15:54',NULL),(230,'Barbeiro',1,2,'2018-08-21 14:15:54',NULL),(231,'Barista',1,2,'2018-08-21 14:15:54',NULL),(232,'Barman',1,2,'2018-08-21 14:15:54',NULL),(233,'Bate-folha a  máquina',1,2,'2018-08-21 14:15:54',NULL),(234,'Bibliotecário',1,2,'2018-08-21 14:15:54',NULL),(235,'Bilheteiro (estações de metrô, ferroviárias e assemelhadas)',1,2,'2018-08-21 14:15:54',NULL),(236,'Bilheteiro de transportes coletivos',1,2,'2018-08-21 14:15:54',NULL),(237,'Bilheteiro no serviço de diversões',1,2,'2018-08-21 14:15:54',NULL),(238,'Bioengenheiro',1,2,'2018-08-21 14:15:54',NULL),(239,'Biólogo',1,2,'2018-08-21 14:15:54',NULL),(240,'Biomédico',1,2,'2018-08-21 14:15:54',NULL),(241,'Biotecnologista',1,2,'2018-08-21 14:15:54',NULL),(242,'Bloqueiro (trabalhador portuário)',1,2,'2018-08-21 14:15:54',NULL),(243,'Bobinador eletricista, à mão',1,2,'2018-08-21 14:15:54',NULL),(244,'Bobinador eletricista, à máquina',1,2,'2018-08-21 14:15:54',NULL),(245,'Boiadeiro',1,2,'2018-08-21 14:15:54',NULL),(246,'Bombeiro civil',1,2,'2018-08-21 14:15:54',NULL),(247,'Bombeiro de aeródromo',1,2,'2018-08-21 14:15:54',NULL),(248,'Boneleiro',1,2,'2018-08-21 14:15:54',NULL),(249,'Bordador, a  mão',1,2,'2018-08-21 14:15:54',NULL),(250,'Bordador, à máquina',1,2,'2018-08-21 14:15:54',NULL),(251,'Borracheiro',1,2,'2018-08-21 14:15:54',NULL),(252,'Brasador',1,2,'2018-08-21 14:15:54',NULL),(253,'Cabeleireiro',1,2,'2018-08-21 14:15:54',NULL),(254,'Cableador',1,2,'2018-08-21 14:15:54',NULL),(255,'Cabo bombeiro militar',1,2,'2018-08-21 14:15:54',NULL),(256,'Cabo da polícia militar',1,2,'2018-08-21 14:15:54',NULL),(257,'Cacique',1,2,'2018-08-21 14:15:54',NULL),(258,'Cafeicultor',1,2,'2018-08-21 14:15:54',NULL),(259,'Caixa de banco',1,2,'2018-08-21 14:15:54',NULL),(260,'Calafetador',1,2,'2018-08-21 14:15:54',NULL),(261,'Calandrista de borracha',1,2,'2018-08-21 14:15:54',NULL),(262,'Calandrista de papel',1,2,'2018-08-21 14:15:54',NULL),(263,'Calceteiro',1,2,'2018-08-21 14:15:54',NULL),(264,'Caldeireiro (chapas de cobre)',1,2,'2018-08-21 14:15:54',NULL),(265,'Caldeireiro (chapas de ferro e aço)',1,2,'2018-08-21 14:15:54',NULL),(266,'Camareira de teatro',1,2,'2018-08-21 14:15:54',NULL),(267,'Camareira de televisão',1,2,'2018-08-21 14:15:54',NULL),(268,'Camareiro  de hotel',1,2,'2018-08-21 14:15:54',NULL),(269,'Camareiro de embarcações',1,2,'2018-08-21 14:15:54',NULL),(270,'Caminhoneiro autônomo (rotas regionais e internacionais)',1,2,'2018-08-21 14:15:54',NULL),(271,'Canteiro',1,2,'2018-08-21 14:15:54',NULL),(272,'Capitão bombeiro militar',1,2,'2018-08-21 14:15:54',NULL),(273,'Capitão da polícia militar',1,2,'2018-08-21 14:15:54',NULL),(274,'Capitão de manobra da marinha mercante',1,2,'2018-08-21 14:15:54',NULL),(275,'Carbonizador',1,2,'2018-08-21 14:15:54',NULL),(276,'Carpinteiro',1,2,'2018-08-21 14:15:54',NULL),(277,'Carpinteiro (cenários)',1,2,'2018-08-21 14:15:54',NULL),(278,'Carpinteiro (esquadrias)',1,2,'2018-08-21 14:15:54',NULL),(279,'Carpinteiro (mineração)',1,2,'2018-08-21 14:15:54',NULL),(280,'Carpinteiro (telhados)',1,2,'2018-08-21 14:15:54',NULL),(281,'Carpinteiro de carretas',1,2,'2018-08-21 14:15:54',NULL),(282,'Carpinteiro de carrocerias',1,2,'2018-08-21 14:15:54',NULL),(283,'Carpinteiro de fôrmas para concreto',1,2,'2018-08-21 14:15:54',NULL),(284,'Carpinteiro de obras',1,2,'2018-08-21 14:15:54',NULL),(285,'Carpinteiro de obras civis de arte (pontes, túneis, barragens)',1,2,'2018-08-21 14:15:54',NULL),(286,'Carpinteiro naval (construção de pequenas embarcações)',1,2,'2018-08-21 14:15:54',NULL),(287,'Carpinteiro naval (embarcações)',1,2,'2018-08-21 14:15:54',NULL),(288,'Carpinteiro naval (estaleiros)',1,2,'2018-08-21 14:15:54',NULL),(289,'Carregador (aeronaves)',1,2,'2018-08-21 14:15:54',NULL),(290,'Carregador (armazém)',1,2,'2018-08-21 14:15:54',NULL),(291,'Carregador (veículos de transportes terrestres)',1,2,'2018-08-21 14:15:54',NULL),(292,'Cartazeiro',1,2,'2018-08-21 14:15:54',NULL),(293,'Carteiro',1,2,'2018-08-21 14:15:54',NULL),(294,'Cartonageiro, a mão (caixas de papelão)',1,2,'2018-08-21 14:15:54',NULL),(295,'Cartonageiro, a máquina',1,2,'2018-08-21 14:15:54',NULL),(296,'Carvoeiro',1,2,'2018-08-21 14:15:54',NULL),(297,'Caseiro (agricultura)',1,2,'2018-08-21 14:15:54',NULL),(298,'Casqueador de animais',1,2,'2018-08-21 14:15:54',NULL),(299,'Catador de caranguejos e siris',1,2,'2018-08-21 14:15:54',NULL),(300,'Catador de mariscos',1,2,'2018-08-21 14:15:54',NULL),(301,'Catador de material reciclável',1,2,'2018-08-21 14:15:54',NULL),(302,'Celofanista na fabricação de charutos',1,2,'2018-08-21 14:15:54',NULL),(303,'Cementador de metais',1,2,'2018-08-21 14:15:54',NULL),(304,'Cenógrafo carnavalesco e festas populares',1,2,'2018-08-21 14:15:54',NULL),(305,'Cenógrafo de cinema',1,2,'2018-08-21 14:15:54',NULL),(306,'Cenógrafo de eventos',1,2,'2018-08-21 14:15:54',NULL),(307,'Cenógrafo de teatro',1,2,'2018-08-21 14:15:54',NULL),(308,'Cenógrafo de tv',1,2,'2018-08-21 14:15:54',NULL),(309,'Cenotécnico (cinema, vídeo, televisão, teatro e espetáculos)',1,2,'2018-08-21 14:15:54',NULL),(310,'Ceramista',1,2,'2018-08-21 14:15:54',NULL),(311,'Ceramista (torno de pedal e motor)',1,2,'2018-08-21 14:15:54',NULL),(312,'Ceramista (torno semi-automático)',1,2,'2018-08-21 14:15:54',NULL),(313,'Ceramista modelador',1,2,'2018-08-21 14:15:54',NULL),(314,'Ceramista moldador',1,2,'2018-08-21 14:15:54',NULL),(315,'Ceramista prensador',1,2,'2018-08-21 14:15:54',NULL),(316,'Cerimonialista',1,2,'2018-08-21 14:15:54',NULL),(317,'Cerzidor',1,2,'2018-08-21 14:15:54',NULL),(318,'Cesteiro',1,2,'2018-08-21 14:15:54',NULL),(319,'Chapeador',1,2,'2018-08-21 14:15:54',NULL),(320,'Chapeador de aeronaves',1,2,'2018-08-21 14:15:54',NULL),(321,'Chapeador de carrocerias metálicas (fabricação)',1,2,'2018-08-21 14:15:54',NULL),(322,'Chapeador naval',1,2,'2018-08-21 14:15:54',NULL),(323,'Chapeleiro (chapéus de palha)',1,2,'2018-08-21 14:15:54',NULL),(324,'Chapeleiro de senhoras',1,2,'2018-08-21 14:15:54',NULL),(325,'Charuteiro a mão',1,2,'2018-08-21 14:15:54',NULL),(326,'Chaveiro',1,2,'2018-08-21 14:15:54',NULL),(327,'Chefe de bar',1,2,'2018-08-21 14:15:54',NULL),(328,'Chefe de confeitaria',1,2,'2018-08-21 14:15:54',NULL),(329,'Chefe de contabilidade (técnico)',1,2,'2018-08-21 14:15:54',NULL),(330,'Chefe de cozinha',1,2,'2018-08-21 14:15:54',NULL),(331,'Chefe de estação portuária',1,2,'2018-08-21 14:15:54',NULL),(332,'Chefe de portaria de hotel',1,2,'2018-08-21 14:15:54',NULL),(333,'Chefe de serviço de transporte rodoviário (passageiros e cargas)',1,2,'2018-08-21 14:15:54',NULL),(334,'Chefe de serviços bancários',1,2,'2018-08-21 14:15:54',NULL),(335,'Churrasqueiro',1,2,'2018-08-21 14:15:54',NULL),(336,'Ciclista mensageiro',1,2,'2018-08-21 14:15:54',NULL),(337,'Cientista político',1,2,'2018-08-21 14:15:54',NULL),(338,'Cilindreiro na preparação de pasta para fabricação de papel',1,2,'2018-08-21 14:15:54',NULL),(339,'Cilindrista (petroquímica e afins)',1,2,'2018-08-21 14:15:54',NULL),(340,'Cimentador (poços de petróleo)',1,2,'2018-08-21 14:15:54',NULL),(341,'Cirurgião dentista - auditor',1,2,'2018-08-21 14:15:54',NULL),(342,'Cirurgião dentista - clínico geral',1,2,'2018-08-21 14:15:54',NULL),(343,'Cirurgião dentista - dentística',1,2,'2018-08-21 14:15:54',NULL),(344,'Cirurgião dentista - disfunção temporomandibular e dor orofacial',1,2,'2018-08-21 14:15:54',NULL),(345,'Cirurgião dentista - endodontista',1,2,'2018-08-21 14:15:54',NULL),(346,'Cirurgião dentista - epidemiologista',1,2,'2018-08-21 14:15:54',NULL),(347,'Cirurgião dentista - estomatologista',1,2,'2018-08-21 14:15:54',NULL),(348,'Cirurgião dentista - implantodontista',1,2,'2018-08-21 14:15:54',NULL),(349,'Cirurgião dentista - odontogeriatra',1,2,'2018-08-21 14:15:54',NULL),(350,'Cirurgião dentista - odontologia do trabalho',1,2,'2018-08-21 14:15:54',NULL),(351,'Cirurgião dentista - odontologia para pacientes com necessidades especiais',1,2,'2018-08-21 14:15:54',NULL),(352,'Cirurgião dentista - odontologista legal',1,2,'2018-08-21 14:15:54',NULL),(353,'Cirurgião dentista - odontopediatra',1,2,'2018-08-21 14:15:54',NULL),(354,'Cirurgião dentista - ortopedista e ortodontista',1,2,'2018-08-21 14:15:54',NULL),(355,'Cirurgião dentista - patologista bucal',1,2,'2018-08-21 14:15:54',NULL),(356,'Cirurgião dentista - periodontista',1,2,'2018-08-21 14:15:54',NULL),(357,'Cirurgião dentista - protesiólogo bucomaxilofacial',1,2,'2018-08-21 14:15:54',NULL),(358,'Cirurgião dentista - protesista',1,2,'2018-08-21 14:15:54',NULL),(359,'Cirurgião dentista - radiologista',1,2,'2018-08-21 14:15:54',NULL),(360,'Cirurgião dentista - reabilitador oral',1,2,'2018-08-21 14:15:54',NULL),(361,'Cirurgião dentista - traumatologista bucomaxilofacial',1,2,'2018-08-21 14:15:54',NULL),(362,'Cirurgião dentista de saúde coletiva',1,2,'2018-08-21 14:15:54',NULL),(363,'Cirurgião-dentista da estratégia de saúde da família',1,2,'2018-08-21 14:15:54',NULL),(364,'Citotécnico',1,2,'2018-08-21 14:15:54',NULL),(365,'Classificador de charutos',1,2,'2018-08-21 14:15:54',NULL),(366,'Classificador de couros',1,2,'2018-08-21 14:15:54',NULL),(367,'Classificador de fibras têxteis',1,2,'2018-08-21 14:15:54',NULL),(368,'Classificador de fumo',1,2,'2018-08-21 14:15:54',NULL),(369,'Classificador de grãos',1,2,'2018-08-21 14:15:54',NULL),(370,'Classificador de madeira',1,2,'2018-08-21 14:15:54',NULL),(371,'Classificador de peles',1,2,'2018-08-21 14:15:54',NULL),(372,'Classificador de toras',1,2,'2018-08-21 14:15:54',NULL),(373,'Classificador e empilhador de tijolos refratários',1,2,'2018-08-21 14:15:54',NULL),(374,'Cobrador de transportes coletivos (exceto trem)',1,2,'2018-08-21 14:15:54',NULL),(375,'Cobrador externo',1,2,'2018-08-21 14:15:54',NULL),(376,'Cobrador interno',1,2,'2018-08-21 14:15:54',NULL),(377,'Codificador de dados',1,2,'2018-08-21 14:15:54',NULL),(378,'Colchoeiro (confecção de colchões)',1,2,'2018-08-21 14:15:54',NULL),(379,'Colecionador de selos e moedas',1,2,'2018-08-21 14:15:54',NULL),(380,'Coletor de lixo domiciliar',1,2,'2018-08-21 14:15:54',NULL),(381,'Coletor de resíduos sólidos de serviços de saúde',1,2,'2018-08-21 14:15:54',NULL),(382,'Colorista de papel',1,2,'2018-08-21 14:15:54',NULL),(383,'Colorista têxtil',1,2,'2018-08-21 14:15:54',NULL),(384,'Comandante da marinha mercante',1,2,'2018-08-21 14:15:54',NULL),(385,'Comentarista de rádio e televisão',1,2,'2018-08-21 14:15:54',NULL),(386,'Comerciante atacadista',1,2,'2018-08-21 14:15:54',NULL),(387,'Comerciante varejista',1,2,'2018-08-21 14:15:54',NULL),(388,'Comissário de trem',1,2,'2018-08-21 14:15:54',NULL),(389,'Comissário de vôo',1,2,'2018-08-21 14:15:54',NULL),(390,'Compensador de banco',1,2,'2018-08-21 14:15:54',NULL),(391,'Compositor',1,2,'2018-08-21 14:15:54',NULL),(392,'Comprador',1,2,'2018-08-21 14:15:54',NULL),(393,'Concierge',1,2,'2018-08-21 14:15:54',NULL),(394,'Condutor de ambulância',1,2,'2018-08-21 14:15:54',NULL),(395,'Condutor de máquinas',1,2,'2018-08-21 14:15:54',NULL),(396,'Condutor de máquinas (bombeador)',1,2,'2018-08-21 14:15:54',NULL),(397,'Condutor de máquinas (mecânico)',1,2,'2018-08-21 14:15:54',NULL),(398,'Condutor de processos robotizados de pintura',1,2,'2018-08-21 14:15:54',NULL),(399,'Condutor de processos robotizados de soldagem',1,2,'2018-08-21 14:15:54',NULL),(400,'Condutor de turismo de aventura',1,2,'2018-08-21 14:15:54',NULL),(401,'Condutor de turismo de pesca',1,2,'2018-08-21 14:15:54',NULL),(402,'Condutor de veículos a pedais',1,2,'2018-08-21 14:15:54',NULL),(403,'Condutor de veículos de tração animal (ruas e estradas)',1,2,'2018-08-21 14:15:54',NULL),(404,'Condutor maquinista motorista fluvial',1,2,'2018-08-21 14:15:54',NULL),(405,'Confeccionador de acordeão',1,2,'2018-08-21 14:15:54',NULL),(406,'Confeccionador de artefatos de couro (exceto sapatos)',1,2,'2018-08-21 14:15:54',NULL),(407,'Confeccionador de bolsas, sacos e sacolas e papel, a máquina',1,2,'2018-08-21 14:15:54',NULL),(408,'Confeccionador de brinquedos de pano',1,2,'2018-08-21 14:15:54',NULL),(409,'Confeccionador de carimbos de borracha',1,2,'2018-08-21 14:15:54',NULL),(410,'Confeccionador de escovas, pincéis e produtos similares (a mão)',1,2,'2018-08-21 14:15:54',NULL),(411,'Confeccionador de escovas, pincéis e produtos similares (a máquina)',1,2,'2018-08-21 14:15:54',NULL),(412,'Confeccionador de instrumentos de corda',1,2,'2018-08-21 14:15:54',NULL),(413,'Confeccionador de instrumentos de percussão (pele, couro ou plástico)',1,2,'2018-08-21 14:15:54',NULL),(414,'Confeccionador de instrumentos de sopro (madeira)',1,2,'2018-08-21 14:15:54',NULL),(415,'Confeccionador de instrumentos de sopro (metal)',1,2,'2018-08-21 14:15:54',NULL),(416,'Confeccionador de móveis de vime, junco e bambu',1,2,'2018-08-21 14:15:54',NULL),(417,'Confeccionador de órgão',1,2,'2018-08-21 14:15:54',NULL),(418,'Confeccionador de piano',1,2,'2018-08-21 14:15:54',NULL),(419,'Confeccionador de pneumáticos',1,2,'2018-08-21 14:15:54',NULL),(420,'Confeccionador de sacos de celofane, a máquina',1,2,'2018-08-21 14:15:54',NULL),(421,'Confeccionador de velas náuticas, barracas e toldos',1,2,'2018-08-21 14:15:54',NULL),(422,'Confeccionador de velas por imersão',1,2,'2018-08-21 14:15:54',NULL),(423,'Confeccionador de velas por moldagem',1,2,'2018-08-21 14:15:54',NULL),(424,'Confeiteiro',1,2,'2018-08-21 14:15:54',NULL),(425,'Conferente de carga e descarga',1,2,'2018-08-21 14:15:54',NULL),(426,'Conferente de serviços bancários',1,2,'2018-08-21 14:15:54',NULL),(427,'Conferente-expedidor de roupas (lavanderias)',1,2,'2018-08-21 14:15:54',NULL),(428,'Conselheiro tutelar',1,2,'2018-08-21 14:15:54',NULL),(429,'Conservador de via permanente (trilhos)',1,2,'2018-08-21 14:15:54',NULL),(430,'Conservador-restaurador de bens  culturais',1,2,'2018-08-21 14:15:54',NULL),(431,'Consultor contábil (técnico)',1,2,'2018-08-21 14:15:54',NULL),(432,'Consultor jurídico',1,2,'2018-08-21 14:15:54',NULL),(433,'Contador',1,2,'2018-08-21 14:15:54',NULL),(434,'Contínuo',1,2,'2018-08-21 14:15:54',NULL),(435,'Contorcionista',1,2,'2018-08-21 14:15:54',NULL),(436,'Contramestre de acabamento (indústria têxtil)',1,2,'2018-08-21 14:15:54',NULL),(437,'Contramestre de cabotagem',1,2,'2018-08-21 14:15:54',NULL),(438,'Contramestre de fiação (indústria têxtil)',1,2,'2018-08-21 14:15:54',NULL),(439,'Contramestre de malharia (indústria têxtil)',1,2,'2018-08-21 14:15:54',NULL),(440,'Contramestre de tecelagem (indústria têxtil)',1,2,'2018-08-21 14:15:54',NULL),(441,'Controlador de entrada e saída',1,2,'2018-08-21 14:15:54',NULL),(442,'Controlador de pragas',1,2,'2018-08-21 14:15:54',NULL),(443,'Controlador de serviços de máquinas e veículos',1,2,'2018-08-21 14:15:54',NULL),(444,'Controlador de tráfego aéreo',1,2,'2018-08-21 14:15:54',NULL),(445,'Coordenador de operações de combate à poluição no meio aquaviário',1,2,'2018-08-21 14:15:54',NULL),(446,'Coordenador pedagógico',1,2,'2018-08-21 14:15:54',NULL),(447,'Copeiro',1,2,'2018-08-21 14:15:54',NULL),(448,'Copeiro de hospital',1,2,'2018-08-21 14:15:54',NULL),(449,'Copiador de chapa',1,2,'2018-08-21 14:15:54',NULL),(450,'Coreógrafo',1,2,'2018-08-21 14:15:54',NULL),(451,'Coronel bombeiro militar',1,2,'2018-08-21 14:15:54',NULL),(452,'Coronel da polícia militar',1,2,'2018-08-21 14:15:54',NULL),(453,'Corretor de imóveis',1,2,'2018-08-21 14:15:54',NULL),(454,'Corretor de seguros',1,2,'2018-08-21 14:15:54',NULL),(455,'Corretor de valores, ativos financeiros, mercadorias e derivativos',1,2,'2018-08-21 14:15:54',NULL),(456,'Cortador de artefatos de couro (exceto roupas e calçados)',1,2,'2018-08-21 14:15:54',NULL),(457,'Cortador de calçados, a  mão (exceto solas)',1,2,'2018-08-21 14:15:54',NULL),(458,'Cortador de calçados, a  máquina (exceto solas e palmilhas)',1,2,'2018-08-21 14:15:54',NULL),(459,'Cortador de charutos',1,2,'2018-08-21 14:15:54',NULL),(460,'Cortador de laminados de madeira',1,2,'2018-08-21 14:15:54',NULL),(461,'Cortador de pedras',1,2,'2018-08-21 14:15:54',NULL),(462,'Cortador de roupas',1,2,'2018-08-21 14:15:54',NULL),(463,'Cortador de solas e palmilhas, a  máquina',1,2,'2018-08-21 14:15:54',NULL),(464,'Cortador de tapeçaria',1,2,'2018-08-21 14:15:54',NULL),(465,'Cortador de vidro',1,2,'2018-08-21 14:15:54',NULL),(466,'Costurador de artefatos de couro, a  mão (exceto roupas e calçados)',1,2,'2018-08-21 14:15:54',NULL),(467,'Costurador de artefatos de couro, a  máquina (exceto roupas e calçados)',1,2,'2018-08-21 14:15:54',NULL),(468,'Costurador de calçados, a  máquina',1,2,'2018-08-21 14:15:54',NULL),(469,'Costureira de peças sob encomenda',1,2,'2018-08-21 14:15:54',NULL),(470,'Costureira de reparação de roupas',1,2,'2018-08-21 14:15:54',NULL),(471,'Costureiro de roupa de couro e pele',1,2,'2018-08-21 14:15:54',NULL),(472,'Costureiro de roupas de couro e pele, a  máquina na  confecção em série',1,2,'2018-08-21 14:15:54',NULL),(473,'Costureiro na confecção em série',1,2,'2018-08-21 14:15:54',NULL),(474,'Costureiro, a  máquina  na confecção em série',1,2,'2018-08-21 14:15:54',NULL),(475,'Cozinhador (conservação de alimentos)',1,2,'2018-08-21 14:15:54',NULL),(476,'Cozinhador de carnes',1,2,'2018-08-21 14:15:54',NULL),(477,'Cozinhador de frutas e legumes',1,2,'2018-08-21 14:15:54',NULL),(478,'Cozinhador de malte',1,2,'2018-08-21 14:15:54',NULL),(479,'Cozinhador de pescado',1,2,'2018-08-21 14:15:54',NULL),(480,'Cozinheiro de embarcações',1,2,'2018-08-21 14:15:54',NULL),(481,'Cozinheiro de hospital',1,2,'2018-08-21 14:15:54',NULL),(482,'Cozinheiro do serviço doméstico',1,2,'2018-08-21 14:15:54',NULL),(483,'Cozinheiro geral',1,2,'2018-08-21 14:15:54',NULL),(484,'Cozinheiro industrial',1,2,'2018-08-21 14:15:54',NULL),(485,'Criador de animais domésticos',1,2,'2018-08-21 14:15:54',NULL),(486,'Criador de animais produtores de veneno',1,2,'2018-08-21 14:15:54',NULL),(487,'Criador de asininos e muares',1,2,'2018-08-21 14:15:54',NULL),(488,'Criador de bovinos (corte)',1,2,'2018-08-21 14:15:54',NULL),(489,'Criador de bovinos (leite)',1,2,'2018-08-21 14:15:54',NULL),(490,'Criador de bubalinos (corte)',1,2,'2018-08-21 14:15:54',NULL),(491,'Criador de bubalinos (leite)',1,2,'2018-08-21 14:15:54',NULL),(492,'Criador de camarões',1,2,'2018-08-21 14:15:54',NULL),(493,'Criador de caprinos',1,2,'2018-08-21 14:15:54',NULL),(494,'Criador de eqüínos',1,2,'2018-08-21 14:15:54',NULL),(495,'Criador de jacarés',1,2,'2018-08-21 14:15:54',NULL),(496,'Criador de mexilhões',1,2,'2018-08-21 14:15:54',NULL),(497,'Criador de ostras',1,2,'2018-08-21 14:15:54',NULL),(498,'Criador de ovinos',1,2,'2018-08-21 14:15:54',NULL),(499,'Criador de peixes',1,2,'2018-08-21 14:15:54',NULL),(500,'Criador de quelônios',1,2,'2018-08-21 14:15:54',NULL),(501,'Criador de rãs',1,2,'2018-08-21 14:15:54',NULL),(502,'Criador de suínos',1,2,'2018-08-21 14:15:54',NULL),(503,'Criador em pecuária polivalente',1,2,'2018-08-21 14:15:54',NULL),(504,'Crítico',1,2,'2018-08-21 14:15:54',NULL),(505,'Crocheteiro, a  mão',1,2,'2018-08-21 14:15:54',NULL),(506,'Cronoanalista',1,2,'2018-08-21 14:15:54',NULL),(507,'Cronometrista',1,2,'2018-08-21 14:15:54',NULL),(508,'Cubador de madeira',1,2,'2018-08-21 14:15:54',NULL),(509,'Cuidador de idosos',1,2,'2018-08-21 14:15:54',NULL),(510,'Cuidador em saúde',1,2,'2018-08-21 14:15:54',NULL),(511,'Cumim',1,2,'2018-08-21 14:15:54',NULL),(512,'Cunicultor',1,2,'2018-08-21 14:15:54',NULL),(513,'Curtidor (couros e peles)',1,2,'2018-08-21 14:15:54',NULL),(514,'Dançarino popular',1,2,'2018-08-21 14:15:54',NULL),(515,'Dançarino tradicional',1,2,'2018-08-21 14:15:54',NULL),(516,'Datilógrafo',1,2,'2018-08-21 14:15:54',NULL),(517,'Decapador',1,2,'2018-08-21 14:15:54',NULL),(518,'Decorador de cerâmica',1,2,'2018-08-21 14:15:54',NULL),(519,'Decorador de eventos',1,2,'2018-08-21 14:15:54',NULL),(520,'Decorador de interiores de nível superior',1,2,'2018-08-21 14:15:54',NULL),(521,'Decorador de vidro',1,2,'2018-08-21 14:15:54',NULL),(522,'Decorador de vidro à pincel',1,2,'2018-08-21 14:15:54',NULL),(523,'Defensor público',1,2,'2018-08-21 14:15:54',NULL),(524,'Defumador de carnes e pescados',1,2,'2018-08-21 14:15:54',NULL),(525,'Degustador de café',1,2,'2018-08-21 14:15:54',NULL),(526,'Degustador de chá',1,2,'2018-08-21 14:15:54',NULL),(527,'Degustador de charutos',1,2,'2018-08-21 14:15:54',NULL),(528,'Degustador de derivados de cacau',1,2,'2018-08-21 14:15:54',NULL),(529,'Degustador de vinhos ou licores',1,2,'2018-08-21 14:15:54',NULL),(530,'Delegado de polícia',1,2,'2018-08-21 14:15:54',NULL),(531,'Demolidor de edificações',1,2,'2018-08-21 14:15:54',NULL),(532,'Demonstrador de mercadorias',1,2,'2018-08-21 14:15:54',NULL),(533,'Deputado estadual e distrital',1,2,'2018-08-21 14:15:54',NULL),(534,'Deputado federal',1,2,'2018-08-21 14:15:54',NULL),(535,'Descarnador de couros e peles, à maquina',1,2,'2018-08-21 14:15:54',NULL),(536,'Desenhista copista',1,2,'2018-08-21 14:15:54',NULL),(537,'Desenhista detalhista',1,2,'2018-08-21 14:15:54',NULL),(538,'Desenhista industrial de produto (designer de produto)',1,2,'2018-08-21 14:15:54',NULL),(539,'Desenhista industrial de produto de moda (designer de moda)',1,2,'2018-08-21 14:15:54',NULL),(540,'Desenhista industrial gráfico (designer gráfico)',1,2,'2018-08-21 14:15:54',NULL),(541,'Desenhista projetista de arquitetura',1,2,'2018-08-21 14:15:54',NULL),(542,'Desenhista projetista de construção civil',1,2,'2018-08-21 14:15:54',NULL),(543,'Desenhista projetista de eletricidade',1,2,'2018-08-21 14:15:54',NULL),(544,'Desenhista projetista de máquinas',1,2,'2018-08-21 14:15:54',NULL),(545,'Desenhista projetista eletrônico',1,2,'2018-08-21 14:15:54',NULL),(546,'Desenhista projetista mecânico',1,2,'2018-08-21 14:15:54',NULL),(547,'Desenhista técnico',1,2,'2018-08-21 14:15:54',NULL),(548,'Desenhista técnico (arquitetura)',1,2,'2018-08-21 14:15:54',NULL),(549,'Desenhista técnico (artes gráficas)',1,2,'2018-08-21 14:15:54',NULL),(550,'Desenhista técnico (calefação, ventilação e refrigeração)',1,2,'2018-08-21 14:15:54',NULL),(551,'Desenhista técnico (cartografia)',1,2,'2018-08-21 14:15:54',NULL),(552,'Desenhista técnico (construção civil)',1,2,'2018-08-21 14:15:54',NULL),(553,'Desenhista técnico (eletricidade e eletrônica)',1,2,'2018-08-21 14:15:54',NULL),(554,'Desenhista técnico (ilustrações artísticas)',1,2,'2018-08-21 14:15:54',NULL),(555,'Desenhista técnico (ilustrações técnicas)',1,2,'2018-08-21 14:15:54',NULL),(556,'Desenhista técnico (indústria têxtil)',1,2,'2018-08-21 14:15:54',NULL),(557,'Desenhista técnico (instalações hidrossanitárias)',1,2,'2018-08-21 14:15:54',NULL),(558,'Desenhista técnico (mobiliário)',1,2,'2018-08-21 14:15:54',NULL),(559,'Desenhista técnico aeronáutico',1,2,'2018-08-21 14:15:54',NULL),(560,'Desenhista técnico de embalagens, maquetes e leiautes',1,2,'2018-08-21 14:15:54',NULL),(561,'Desenhista técnico mecânico',1,2,'2018-08-21 14:15:54',NULL),(562,'Desenhista técnico naval',1,2,'2018-08-21 14:15:54',NULL),(563,'Desidratador de alimentos',1,2,'2018-08-21 14:15:54',NULL),(564,'Designer de interiores',1,2,'2018-08-21 14:15:54',NULL),(565,'Designer de vitrines',1,2,'2018-08-21 14:15:54',NULL),(566,'Designer educacional',1,2,'2018-08-21 14:15:54',NULL),(567,'Desincrustador (poços de petróleo)',1,2,'2018-08-21 14:15:54',NULL),(568,'Desossador',1,2,'2018-08-21 14:15:54',NULL),(569,'Despachante aduaneiro',1,2,'2018-08-21 14:15:54',NULL),(570,'Despachante de trânsito',1,2,'2018-08-21 14:15:54',NULL),(571,'Despachante de transportes coletivos (exceto trem)',1,2,'2018-08-21 14:15:54',NULL),(572,'Despachante documentalista',1,2,'2018-08-21 14:15:54',NULL),(573,'Despachante operacional de vôo',1,2,'2018-08-21 14:15:54',NULL),(574,'Dessecador de malte',1,2,'2018-08-21 14:15:54',NULL),(575,'Destilador de madeira',1,2,'2018-08-21 14:15:54',NULL),(576,'Destilador de produtos químicos (exceto petróleo)',1,2,'2018-08-21 14:15:54',NULL),(577,'Destroçador de pedra',1,2,'2018-08-21 14:15:54',NULL),(578,'Detetive profissional',1,2,'2018-08-21 14:15:54',NULL),(579,'Detonador',1,2,'2018-08-21 14:15:54',NULL),(580,'Dietista',1,2,'2018-08-21 14:15:54',NULL),(581,'Digitador',1,2,'2018-08-21 14:15:54',NULL),(582,'Diretor administrativo',1,2,'2018-08-21 14:15:54',NULL),(583,'Diretor administrativo e financeiro',1,2,'2018-08-21 14:15:54',NULL),(584,'Diretor comercial',1,2,'2018-08-21 14:15:54',NULL),(585,'Diretor comercial em operações de intermediação financeira',1,2,'2018-08-21 14:15:54',NULL),(586,'Diretor de  produção e operações de alimentação',1,2,'2018-08-21 14:15:54',NULL),(587,'Diretor de  produção e operações de hotel',1,2,'2018-08-21 14:15:54',NULL),(588,'Diretor de  produção e operações de turismo',1,2,'2018-08-21 14:15:54',NULL),(589,'Diretor de arte',1,2,'2018-08-21 14:15:54',NULL),(590,'Diretor de arte (publicidade)',1,2,'2018-08-21 14:15:54',NULL),(591,'Diretor de câmbio e comércio exterior',1,2,'2018-08-21 14:15:54',NULL),(592,'Diretor de cinema',1,2,'2018-08-21 14:15:54',NULL),(593,'Diretor de compliance',1,2,'2018-08-21 14:15:54',NULL),(594,'Diretor de contas (publicidade)',1,2,'2018-08-21 14:15:54',NULL),(595,'Diretor de crédito (exceto crédito imobiliário)',1,2,'2018-08-21 14:15:54',NULL),(596,'Diretor de crédito imobiliário',1,2,'2018-08-21 14:15:54',NULL),(597,'Diretor de crédito rural',1,2,'2018-08-21 14:15:54',NULL),(598,'Diretor de criação',1,2,'2018-08-21 14:15:54',NULL),(599,'Diretor de fotografia',1,2,'2018-08-21 14:15:54',NULL),(600,'Diretor de instituição educacional da área privada',1,2,'2018-08-21 14:15:54',NULL),(601,'Diretor de instituição educacional pública',1,2,'2018-08-21 14:15:54',NULL),(602,'Diretor de leasing',1,2,'2018-08-21 14:15:54',NULL),(603,'Diretor de manutenção',1,2,'2018-08-21 14:15:54',NULL),(604,'Diretor de marketing',1,2,'2018-08-21 14:15:54',NULL),(605,'Diretor de mercado de capitais',1,2,'2018-08-21 14:15:54',NULL),(606,'Diretor de mídia (publicidade)',1,2,'2018-08-21 14:15:54',NULL),(607,'Diretor de operações comerciais (comércio atacadista e varejista)',1,2,'2018-08-21 14:15:54',NULL),(608,'Diretor de operações de correios',1,2,'2018-08-21 14:15:54',NULL),(609,'Diretor de operações de obras pública e civil',1,2,'2018-08-21 14:15:54',NULL),(610,'Diretor de operações de serviços de armazenamento',1,2,'2018-08-21 14:15:54',NULL),(611,'Diretor de operações de serviços de telecomunicações',1,2,'2018-08-21 14:15:54',NULL),(612,'Diretor de operações de serviços de transporte',1,2,'2018-08-21 14:15:54',NULL),(613,'Diretor de pesquisa e desenvolvimento (p&d)',1,2,'2018-08-21 14:15:54',NULL),(614,'Diretor de planejamento estratégico',1,2,'2018-08-21 14:15:54',NULL),(615,'Diretor de produção e operações da indústria de transformação, extração mineral e utilidades',1,2,'2018-08-21 14:15:54',NULL),(616,'Diretor de produção e operações em empresa agropecuária',1,2,'2018-08-21 14:15:54',NULL),(617,'Diretor de produção e operações em empresa aqüícola',1,2,'2018-08-21 14:15:54',NULL),(618,'Diretor de produção e operações em empresa florestal',1,2,'2018-08-21 14:15:54',NULL),(619,'Diretor de produção e operações em empresa pesqueira',1,2,'2018-08-21 14:15:54',NULL),(620,'Diretor de produtos bancários',1,2,'2018-08-21 14:15:54',NULL),(621,'Diretor de programas de rádio',1,2,'2018-08-21 14:15:54',NULL),(622,'Diretor de programas de televisão',1,2,'2018-08-21 14:15:54',NULL),(623,'Diretor de recuperação de créditos em operações de intermediação financeira',1,2,'2018-08-21 14:15:54',NULL),(624,'Diretor de recursos humanos',1,2,'2018-08-21 14:15:54',NULL),(625,'Diretor de redação',1,2,'2018-08-21 14:15:54',NULL),(626,'Diretor de relações de trabalho',1,2,'2018-08-21 14:15:54',NULL),(627,'Diretor de riscos de mercado',1,2,'2018-08-21 14:15:54',NULL),(628,'Diretor de serviços culturais',1,2,'2018-08-21 14:15:54',NULL),(629,'Diretor de serviços de informática',1,2,'2018-08-21 14:15:54',NULL),(630,'Diretor de serviços de saúde',1,2,'2018-08-21 14:15:54',NULL),(631,'Diretor de serviços sociais',1,2,'2018-08-21 14:15:54',NULL),(632,'Diretor de suprimentos',1,2,'2018-08-21 14:15:54',NULL),(633,'Diretor de suprimentos no serviço público',1,2,'2018-08-21 14:15:54',NULL),(634,'Diretor financeiro',1,2,'2018-08-21 14:15:54',NULL),(635,'Diretor geral de empresa e organizações (exceto de interesse público)',1,2,'2018-08-21 14:15:54',NULL),(636,'Diretor teatral',1,2,'2018-08-21 14:15:54',NULL),(637,'Dirigente de partido político',1,2,'2018-08-21 14:15:54',NULL),(638,'Dirigente do serviço público estadual e distrital',1,2,'2018-08-21 14:15:54',NULL),(639,'Dirigente do serviço público federal',1,2,'2018-08-21 14:15:54',NULL),(640,'Dirigente do serviço público municipal',1,2,'2018-08-21 14:15:54',NULL),(641,'Dirigente e administrador de organização da sociedade civil sem fins lucrativos',1,2,'2018-08-21 14:15:54',NULL),(642,'Dirigente e administrador de organização religiosa',1,2,'2018-08-21 14:15:54',NULL),(643,'Dirigentes de entidades de trabalhadores',1,2,'2018-08-21 14:15:54',NULL),(644,'Dirigentes de entidades patronais',1,2,'2018-08-21 14:15:54',NULL),(645,'Dj (disc jockey)',1,2,'2018-08-21 14:15:54',NULL),(646,'Documentalista',1,2,'2018-08-21 14:15:54',NULL),(647,'Domador de animais (circense)',1,2,'2018-08-21 14:15:54',NULL),(648,'Doula',1,2,'2018-08-21 14:15:54',NULL),(649,'Drageador (medicamentos)',1,2,'2018-08-21 14:15:54',NULL),(650,'Dramaturgo de dança',1,2,'2018-08-21 14:15:54',NULL),(651,'Economista',1,2,'2018-08-21 14:15:54',NULL),(652,'Economista agroindustrial',1,2,'2018-08-21 14:15:54',NULL),(653,'Economista ambiental',1,2,'2018-08-21 14:15:54',NULL),(654,'Economista do setor público',1,2,'2018-08-21 14:15:54',NULL),(655,'Economista doméstico',1,2,'2018-08-21 14:15:54',NULL),(656,'Economista financeiro',1,2,'2018-08-21 14:15:54',NULL),(657,'Economista industrial',1,2,'2018-08-21 14:15:54',NULL),(658,'Economista regional e urbano',1,2,'2018-08-21 14:15:54',NULL),(659,'Editor',1,2,'2018-08-21 14:15:54',NULL),(660,'Editor de jornal',1,2,'2018-08-21 14:15:54',NULL),(661,'Editor de livro',1,2,'2018-08-21 14:15:54',NULL),(662,'Editor de mídia eletrônica',1,2,'2018-08-21 14:15:54',NULL),(663,'Editor de revista',1,2,'2018-08-21 14:15:54',NULL),(664,'Editor de revista científica',1,2,'2018-08-21 14:15:54',NULL),(665,'Editor de texto e imagem',1,2,'2018-08-21 14:15:54',NULL),(666,'Editor de tv  e vídeo',1,2,'2018-08-21 14:15:54',NULL),(667,'Educador social',1,2,'2018-08-21 14:15:54',NULL),(668,'Eletricista de bordo',1,2,'2018-08-21 14:15:54',NULL),(669,'Eletricista de instalações',1,2,'2018-08-21 14:15:54',NULL),(670,'Eletricista de instalações (aeronaves)',1,2,'2018-08-21 14:15:54',NULL),(671,'Eletricista de instalações (cenários)',1,2,'2018-08-21 14:15:54',NULL),(672,'Eletricista de instalações (edifícios)',1,2,'2018-08-21 14:15:54',NULL),(673,'Eletricista de instalações (embarcações)',1,2,'2018-08-21 14:15:54',NULL),(674,'Eletricista de instalações (veículos automotores e máquinas operatrizes, exceto aeronaves e embarcaç',1,2,'2018-08-21 14:15:54',NULL),(675,'Eletricista de manutenção de linhas elétricas, telefônicas e de comunicação de dados',1,2,'2018-08-21 14:15:54',NULL),(676,'Eletricista de manutenção eletroeletrônica',1,2,'2018-08-21 14:15:54',NULL),(677,'Eletromecânico de manutenção de elevadores',1,2,'2018-08-21 14:15:54',NULL),(678,'Eletromecânico de manutenção de escadas rolantes',1,2,'2018-08-21 14:15:54',NULL),(679,'Eletromecânico de manutenção de portas automáticas',1,2,'2018-08-21 14:15:54',NULL),(680,'Eletrotécnico',1,2,'2018-08-21 14:15:54',NULL),(681,'Eletrotécnico (produção de energia)',1,2,'2018-08-21 14:15:54',NULL),(682,'Eletrotécnico na fabricação, montagem e instalação de máquinas e equipamentos',1,2,'2018-08-21 14:15:54',NULL),(683,'Embalador, a mão',1,2,'2018-08-21 14:15:54',NULL),(684,'Embalador, a máquina',1,2,'2018-08-21 14:15:54',NULL),(685,'Embalsamador',1,2,'2018-08-21 14:15:54',NULL),(686,'Emendador de cabos elétricos e telefônicos (aéreos e subterrâneos)',1,2,'2018-08-21 14:15:54',NULL),(687,'Emissor de passagens',1,2,'2018-08-21 14:15:54',NULL),(688,'Empregado  doméstico  nos serviços gerais',1,2,'2018-08-21 14:15:54',NULL),(689,'Empregado doméstico  arrumador',1,2,'2018-08-21 14:15:54',NULL),(690,'Empregado doméstico  faxineiro',1,2,'2018-08-21 14:15:54',NULL),(691,'Empregado doméstico diarista',1,2,'2018-08-21 14:15:54',NULL),(692,'Encanador',1,2,'2018-08-21 14:15:54',NULL),(693,'Encarregado de acabamento de chapas e metais  (têmpera)',1,2,'2018-08-21 14:15:54',NULL),(694,'Encarregado de corte na confecção do vestuário',1,2,'2018-08-21 14:15:54',NULL),(695,'Encarregado de costura na confecção do vestuário',1,2,'2018-08-21 14:15:54',NULL),(696,'Encarregado de equipe de conservação de vias permanentes (exceto trilhos)',1,2,'2018-08-21 14:15:54',NULL),(697,'Encarregado de manutenção de instrumentos de controle, medição e similares',1,2,'2018-08-21 14:15:54',NULL),(698,'Encarregado de manutenção elétrica de veículos',1,2,'2018-08-21 14:15:54',NULL),(699,'Encarregado de manutenção mecânica de sistemas operacionais',1,2,'2018-08-21 14:15:54',NULL),(700,'Encarregado geral de operações de conservação de vias permanentes (exceto trilhos)',1,2,'2018-08-21 14:15:54',NULL),(701,'Enfermeiro',1,2,'2018-08-21 14:15:54',NULL),(702,'Enfermeiro auditor',1,2,'2018-08-21 14:15:54',NULL),(703,'Enfermeiro da estratégia de saúde da família',1,2,'2018-08-21 14:15:54',NULL),(704,'Enfermeiro de bordo',1,2,'2018-08-21 14:15:54',NULL),(705,'Enfermeiro de centro cirúrgico',1,2,'2018-08-21 14:15:54',NULL),(706,'Enfermeiro de terapia intensiva',1,2,'2018-08-21 14:15:54',NULL),(707,'Enfermeiro do trabalho',1,2,'2018-08-21 14:15:54',NULL),(708,'Enfermeiro nefrologista',1,2,'2018-08-21 14:15:54',NULL),(709,'Enfermeiro neonatologista',1,2,'2018-08-21 14:15:54',NULL),(710,'Enfermeiro obstétrico',1,2,'2018-08-21 14:15:54',NULL),(711,'Enfermeiro psiquiátrico',1,2,'2018-08-21 14:15:54',NULL),(712,'Enfermeiro puericultor e pediátrico',1,2,'2018-08-21 14:15:54',NULL),(713,'Enfermeiro sanitarista',1,2,'2018-08-21 14:15:54',NULL),(714,'Enfestador de roupas',1,2,'2018-08-21 14:15:54',NULL),(715,'Engastador (jóias)',1,2,'2018-08-21 14:15:54',NULL),(716,'Engenheiro aeronáutico',1,2,'2018-08-21 14:15:54',NULL),(717,'Engenheiro agrícola',1,2,'2018-08-21 14:15:54',NULL),(718,'Engenheiro agrimensor',1,2,'2018-08-21 14:15:54',NULL),(719,'Engenheiro agrônomo',1,2,'2018-08-21 14:15:54',NULL),(720,'Engenheiro ambiental',1,2,'2018-08-21 14:15:54',NULL),(721,'Engenheiro cartógrafo',1,2,'2018-08-21 14:15:54',NULL),(722,'Engenheiro civil',1,2,'2018-08-21 14:15:54',NULL),(723,'Engenheiro civil (aeroportos)',1,2,'2018-08-21 14:15:54',NULL),(724,'Engenheiro civil (edificações)',1,2,'2018-08-21 14:15:54',NULL),(725,'Engenheiro civil (estruturas metálicas)',1,2,'2018-08-21 14:15:54',NULL),(726,'Engenheiro civil (ferrovias e metrovias)',1,2,'2018-08-21 14:15:54',NULL),(727,'Engenheiro civil (geotécnia)',1,2,'2018-08-21 14:15:54',NULL),(728,'Engenheiro civil (hidráulica)',1,2,'2018-08-21 14:15:54',NULL),(729,'Engenheiro civil (hidrologia)',1,2,'2018-08-21 14:15:54',NULL),(730,'Engenheiro civil (pontes e viadutos)',1,2,'2018-08-21 14:15:54',NULL),(731,'Engenheiro civil (portos e vias navegáveis)',1,2,'2018-08-21 14:15:54',NULL),(732,'Engenheiro civil (rodovias)',1,2,'2018-08-21 14:15:54',NULL),(733,'Engenheiro civil (saneamento)',1,2,'2018-08-21 14:15:54',NULL),(734,'Engenheiro civil (transportes e trânsito)',1,2,'2018-08-21 14:15:54',NULL),(735,'Engenheiro civil (túneis)',1,2,'2018-08-21 14:15:54',NULL),(736,'Engenheiro de alimentos',1,2,'2018-08-21 14:15:54',NULL),(737,'Engenheiro de aplicativos em computação',1,2,'2018-08-21 14:15:54',NULL),(738,'Engenheiro de controle de qualidade',1,2,'2018-08-21 14:15:54',NULL),(739,'Engenheiro de controle e automação',1,2,'2018-08-21 14:15:54',NULL),(740,'Engenheiro de equipamentos em computação',1,2,'2018-08-21 14:15:54',NULL),(741,'Engenheiro de manutenção de telecomunicações',1,2,'2018-08-21 14:15:54',NULL),(742,'Engenheiro de materiais',1,2,'2018-08-21 14:15:54',NULL),(743,'Engenheiro de minas',1,2,'2018-08-21 14:15:54',NULL),(744,'Engenheiro de minas (beneficiamento)',1,2,'2018-08-21 14:15:54',NULL),(745,'Engenheiro de minas (lavra a céu aberto)',1,2,'2018-08-21 14:15:54',NULL),(746,'Engenheiro de minas (lavra subterrânea)',1,2,'2018-08-21 14:15:54',NULL),(747,'Engenheiro de minas (pesquisa mineral)',1,2,'2018-08-21 14:15:54',NULL),(748,'Engenheiro de minas (planejamento)',1,2,'2018-08-21 14:15:54',NULL),(749,'Engenheiro de minas (processo)',1,2,'2018-08-21 14:15:54',NULL),(750,'Engenheiro de minas (projeto)',1,2,'2018-08-21 14:15:54',NULL),(751,'Engenheiro de pesca',1,2,'2018-08-21 14:15:54',NULL),(752,'Engenheiro de produção',1,2,'2018-08-21 14:15:54',NULL),(753,'Engenheiro de redes de comunicação',1,2,'2018-08-21 14:15:54',NULL),(754,'Engenheiro de riscos',1,2,'2018-08-21 14:15:54',NULL),(755,'Engenheiro de segurança do trabalho',1,2,'2018-08-21 14:15:54',NULL),(756,'Engenheiro de telecomunicações',1,2,'2018-08-21 14:15:54',NULL),(757,'Engenheiro de tempos e movimentos',1,2,'2018-08-21 14:15:54',NULL),(758,'Engenheiro eletricista',1,2,'2018-08-21 14:15:54',NULL),(759,'Engenheiro eletricista de manutenção',1,2,'2018-08-21 14:15:54',NULL),(760,'Engenheiro eletricista de projetos',1,2,'2018-08-21 14:15:54',NULL),(761,'Engenheiro eletrônico',1,2,'2018-08-21 14:15:54',NULL),(762,'Engenheiro eletrônico de manutenção',1,2,'2018-08-21 14:15:54',NULL),(763,'Engenheiro eletrônico de projetos',1,2,'2018-08-21 14:15:54',NULL),(764,'Engenheiro florestal',1,2,'2018-08-21 14:15:54',NULL),(765,'Engenheiro mecânico',1,2,'2018-08-21 14:15:54',NULL),(766,'Engenheiro mecânico (energia nuclear)',1,2,'2018-08-21 14:15:54',NULL),(767,'Engenheiro mecânico automotivo',1,2,'2018-08-21 14:15:54',NULL),(768,'Engenheiro mecânico industrial',1,2,'2018-08-21 14:15:54',NULL),(769,'Engenheiro mecatrônico',1,2,'2018-08-21 14:15:54',NULL),(770,'Engenheiro metalurgista',1,2,'2018-08-21 14:15:54',NULL),(771,'Engenheiro naval',1,2,'2018-08-21 14:15:54',NULL),(772,'Engenheiro projetista de telecomunicações',1,2,'2018-08-21 14:15:54',NULL),(773,'Engenheiro químico',1,2,'2018-08-21 14:15:54',NULL),(774,'Engenheiro químico (indústria química)',1,2,'2018-08-21 14:15:54',NULL),(775,'Engenheiro químico (mineração, metalurgia, siderurgia, cimenteira e cerâmica)',1,2,'2018-08-21 14:15:54',NULL),(776,'Engenheiro químico (papel e celulose)',1,2,'2018-08-21 14:15:54',NULL),(777,'Engenheiro químico (petróleo e borracha)',1,2,'2018-08-21 14:15:54',NULL),(778,'Engenheiro químico (utilidades e meio ambiente)',1,2,'2018-08-21 14:15:54',NULL),(779,'Engenheiros de sistemas operacionais em computação',1,2,'2018-08-21 14:15:54',NULL),(780,'Engraxate',1,2,'2018-08-21 14:15:54',NULL),(781,'Enólogo',1,2,'2018-08-21 14:15:54',NULL),(782,'Ensaiador de dança',1,2,'2018-08-21 14:15:54',NULL),(783,'Entalhador  de madeira',1,2,'2018-08-21 14:15:54',NULL),(784,'Entregador de publicações',1,2,'2018-08-21 14:15:54',NULL),(785,'Entrevistador censitário e de pesquisas amostrais',1,2,'2018-08-21 14:15:54',NULL),(786,'Entrevistador de pesquisa de opinião e mídia',1,2,'2018-08-21 14:15:54',NULL),(787,'Entrevistador de pesquisas de mercado',1,2,'2018-08-21 14:15:54',NULL),(788,'Entrevistador de preços',1,2,'2018-08-21 14:15:54',NULL),(789,'Entrevistador social',1,2,'2018-08-21 14:15:54',NULL),(790,'Enxugador de couros',1,2,'2018-08-21 14:15:54',NULL),(791,'Equilibrista',1,2,'2018-08-21 14:15:54',NULL),(792,'Equoterapeuta',1,2,'2018-08-21 14:15:54',NULL),(793,'Escarfador',1,2,'2018-08-21 14:15:54',NULL),(794,'Escolhedor de papel',1,2,'2018-08-21 14:15:54',NULL),(795,'Escorador de minas',1,2,'2018-08-21 14:15:54',NULL),(796,'Escrevente',1,2,'2018-08-21 14:15:54',NULL),(797,'Escritor de ficção',1,2,'2018-08-21 14:15:54',NULL),(798,'Escritor de não ficção',1,2,'2018-08-21 14:15:54',NULL),(799,'Escriturário  em  estatística',1,2,'2018-08-21 14:15:54',NULL),(800,'Escriturário de banco',1,2,'2018-08-21 14:15:54',NULL),(801,'Escrivão de polícia',1,2,'2018-08-21 14:15:54',NULL),(802,'Escrivão extra - judicial',1,2,'2018-08-21 14:15:54',NULL),(803,'Escrivão judicial',1,2,'2018-08-21 14:15:54',NULL),(804,'Esotérico',1,2,'2018-08-21 14:15:54',NULL),(805,'Especialista de políticas públicas e gestão governamental - eppgg',1,2,'2018-08-21 14:15:54',NULL),(806,'Especialista em calibrações metrológicas',1,2,'2018-08-21 14:15:54',NULL),(807,'Especialista em desenvolvimento de cigarros',1,2,'2018-08-21 14:15:54',NULL),(808,'Especialista em ensaios metrológicos',1,2,'2018-08-21 14:15:54',NULL),(809,'Especialista em instrumentação metrológica',1,2,'2018-08-21 14:15:54',NULL),(810,'Especialista em materiais de referência metrológica',1,2,'2018-08-21 14:15:54',NULL),(811,'Especialista em pesquisa operacional',1,2,'2018-08-21 14:15:54',NULL),(812,'Estampador de tecido',1,2,'2018-08-21 14:15:54',NULL),(813,'Estatístico',1,2,'2018-08-21 14:15:54',NULL),(814,'Estatístico (estatística aplicada)',1,2,'2018-08-21 14:15:54',NULL),(815,'Estatístico teórico',1,2,'2018-08-21 14:15:54',NULL),(816,'Esteireiro',1,2,'2018-08-21 14:15:54',NULL),(817,'Estenotipista',1,2,'2018-08-21 14:15:54',NULL),(818,'Esterilizador de alimentos',1,2,'2018-08-21 14:15:54',NULL),(819,'Esteticista',1,2,'2018-08-21 14:15:54',NULL),(820,'Esteticista de animais domésticos',1,2,'2018-08-21 14:15:54',NULL),(821,'Estirador de couros e peles (acabamento)',1,2,'2018-08-21 14:15:54',NULL),(822,'Estirador de couros e peles (preparação)',1,2,'2018-08-21 14:15:54',NULL),(823,'Estirador de tubos de metal sem costura',1,2,'2018-08-21 14:15:54',NULL),(824,'Estivador',1,2,'2018-08-21 14:15:54',NULL),(825,'Estofador de aviões',1,2,'2018-08-21 14:15:54',NULL),(826,'Estofador de móveis',1,2,'2018-08-21 14:15:54',NULL),(827,'Examinador de cabos, linhas elétricas e telefônicas',1,2,'2018-08-21 14:15:54',NULL),(828,'Extrusor de fios ou fibras de vidro',1,2,'2018-08-21 14:15:54',NULL),(829,'Farmacêutico',1,2,'2018-08-21 14:15:54',NULL),(830,'Farmacêutico analista clínico',1,2,'2018-08-21 14:15:54',NULL),(831,'Farmacêutico de alimentos',1,2,'2018-08-21 14:15:54',NULL),(832,'Farmacêutico em saúde pública',1,2,'2018-08-21 14:15:54',NULL),(833,'Farmacêutico hospitalar e clínico',1,2,'2018-08-21 14:15:54',NULL),(834,'Farmacêutico industrial',1,2,'2018-08-21 14:15:54',NULL),(835,'Farmacêutico práticas integrativas e complementares',1,2,'2018-08-21 14:15:54',NULL),(836,'Farmacêutico toxicologista',1,2,'2018-08-21 14:15:54',NULL),(837,'Faxineiro',1,2,'2018-08-21 14:15:54',NULL),(838,'Feirante',1,2,'2018-08-21 14:15:54',NULL),(839,'Fermentador',1,2,'2018-08-21 14:15:54',NULL),(840,'Ferrador de animais',1,2,'2018-08-21 14:15:54',NULL),(841,'Ferramenteiro',1,2,'2018-08-21 14:15:54',NULL),(842,'Ferramenteiro de mandris, calibradores e outros dispositivos',1,2,'2018-08-21 14:15:54',NULL),(843,'Filólogo',1,2,'2018-08-21 14:15:54',NULL),(844,'Filósofo',1,2,'2018-08-21 14:15:54',NULL),(845,'Filtrador de cerveja',1,2,'2018-08-21 14:15:54',NULL),(846,'Finalizador de filmes',1,2,'2018-08-21 14:15:54',NULL),(847,'Finalizador de vídeo',1,2,'2018-08-21 14:15:54',NULL),(848,'Fiscal de atividades urbanas',1,2,'2018-08-21 14:15:54',NULL),(849,'Fiscal de aviação civil (fac)',1,2,'2018-08-21 14:15:54',NULL),(850,'Fiscal de loja',1,2,'2018-08-21 14:15:54',NULL),(851,'Fiscal de pátio de usina de concreto',1,2,'2018-08-21 14:15:54',NULL),(852,'Fiscal de transportes coletivos (exceto trem)',1,2,'2018-08-21 14:15:54',NULL),(853,'Fiscal de tributos estadual',1,2,'2018-08-21 14:15:54',NULL),(854,'Fiscal de tributos municipal',1,2,'2018-08-21 14:15:54',NULL),(855,'Físico',1,2,'2018-08-21 14:15:54',NULL),(856,'Físico (acústica)',1,2,'2018-08-21 14:15:54',NULL),(857,'Físico (atômica e molecular)',1,2,'2018-08-21 14:15:54',NULL),(858,'Físico (cosmologia)',1,2,'2018-08-21 14:15:54',NULL),(859,'Físico (estatística e matemática)',1,2,'2018-08-21 14:15:54',NULL),(860,'Físico (fluidos)',1,2,'2018-08-21 14:15:54',NULL),(861,'Físico (instrumentação)',1,2,'2018-08-21 14:15:54',NULL),(862,'Físico (matéria condensada)',1,2,'2018-08-21 14:15:54',NULL),(863,'Físico (materiais)',1,2,'2018-08-21 14:15:54',NULL),(864,'Físico (medicina)',1,2,'2018-08-21 14:15:54',NULL),(865,'Físico (nuclear e reatores)',1,2,'2018-08-21 14:15:54',NULL),(866,'Físico (óptica)',1,2,'2018-08-21 14:15:54',NULL),(867,'Físico (partículas e campos)',1,2,'2018-08-21 14:15:54',NULL),(868,'Físico (plasma)',1,2,'2018-08-21 14:15:54',NULL),(869,'Físico (térmica)',1,2,'2018-08-21 14:15:54',NULL),(870,'Fisioterapeuta  do trabalho',1,2,'2018-08-21 14:15:54',NULL),(871,'Fisioterapeuta acupunturista',1,2,'2018-08-21 14:15:54',NULL),(872,'Fisioterapeuta esportivo',1,2,'2018-08-21 14:15:54',NULL),(873,'Fisioterapeuta geral',1,2,'2018-08-21 14:15:54',NULL),(874,'Fisioterapeuta neurofuncional',1,2,'2018-08-21 14:15:54',NULL),(875,'Fisioterapeuta osteopata',1,2,'2018-08-21 14:15:54',NULL),(876,'Fisioterapeuta quiropraxista',1,2,'2018-08-21 14:15:54',NULL),(877,'Fisioterapeuta respiratória',1,2,'2018-08-21 14:15:54',NULL),(878,'Fisioterapeuta traumato-ortopédica funcional',1,2,'2018-08-21 14:15:54',NULL),(879,'Fitotecário',1,2,'2018-08-21 14:15:54',NULL),(880,'Foguista (locomotivas a vapor)',1,2,'2018-08-21 14:15:54',NULL),(881,'Folheador de móveis de madeira',1,2,'2018-08-21 14:15:54',NULL),(882,'Fonoaudiólogo educacional',1,2,'2018-08-21 14:15:54',NULL),(883,'Fonoaudiólogo em audiologia',1,2,'2018-08-21 14:15:54',NULL),(884,'Fonoaudiólogo em disfagia',1,2,'2018-08-21 14:15:54',NULL),(885,'Fonoaudiólogo em linguagem',1,2,'2018-08-21 14:15:54',NULL),(886,'Fonoaudiólogo em motricidade orofacial',1,2,'2018-08-21 14:15:54',NULL),(887,'Fonoaudiólogo em saúde coletiva',1,2,'2018-08-21 14:15:54',NULL),(888,'Fonoaudiólogo em voz',1,2,'2018-08-21 14:15:54',NULL),(889,'Fonoaudiólogo geral',1,2,'2018-08-21 14:15:54',NULL),(890,'Forjador',1,2,'2018-08-21 14:15:54',NULL),(891,'Forjador a martelo',1,2,'2018-08-21 14:15:54',NULL),(892,'Forjador prensista',1,2,'2018-08-21 14:15:54',NULL),(893,'Forneiro (materiais de construção)',1,2,'2018-08-21 14:15:54',NULL),(894,'Forneiro de cubilô',1,2,'2018-08-21 14:15:54',NULL),(895,'Forneiro de forno-poço',1,2,'2018-08-21 14:15:54',NULL),(896,'Forneiro de fundição (forno de redução)',1,2,'2018-08-21 14:15:54',NULL),(897,'Forneiro de reaquecimento e tratamento térmico na metalurgia',1,2,'2018-08-21 14:15:54',NULL),(898,'Forneiro de revérbero',1,2,'2018-08-21 14:15:54',NULL),(899,'Forneiro e operador (alto-forno)',1,2,'2018-08-21 14:15:54',NULL),(900,'Forneiro e operador (conversor a oxigênio)',1,2,'2018-08-21 14:15:54',NULL),(901,'Forneiro e operador (forno elétrico)',1,2,'2018-08-21 14:15:54',NULL),(902,'Forneiro e operador (refino de metais não-ferrosos)',1,2,'2018-08-21 14:15:54',NULL),(903,'Forneiro e operador de forno de redução direta',1,2,'2018-08-21 14:15:54',NULL),(904,'Forneiro na fundição de vidro',1,2,'2018-08-21 14:15:54',NULL),(905,'Forneiro no recozimento de vidro',1,2,'2018-08-21 14:15:54',NULL),(906,'Fosfatizador',1,2,'2018-08-21 14:15:54',NULL),(907,'Fotógrafo',1,2,'2018-08-21 14:15:54',NULL),(908,'Fotógrafo publicitário',1,2,'2018-08-21 14:15:54',NULL),(909,'Fotógrafo retratista',1,2,'2018-08-21 14:15:54',NULL),(910,'Frentista',1,2,'2018-08-21 14:15:54',NULL),(911,'Fuloneiro',1,2,'2018-08-21 14:15:54',NULL),(912,'Fuloneiro no acabamento de couros e peles',1,2,'2018-08-21 14:15:54',NULL),(913,'Funcionário Público Estadual',1,2,'2018-08-21 14:15:54',NULL),(914,'Funcionário Público Federal',1,2,'2018-08-21 14:15:54',NULL),(915,'Funcionário Público Municipal',1,2,'2018-08-21 14:15:54',NULL),(916,'Fundidor (joalheria e ourivesaria)',1,2,'2018-08-21 14:15:54',NULL),(917,'Fundidor de metais',1,2,'2018-08-21 14:15:54',NULL),(918,'Funileiro de veículos (reparação)',1,2,'2018-08-21 14:15:54',NULL),(919,'Funileiro industrial',1,2,'2018-08-21 14:15:54',NULL),(920,'Galvanizador',1,2,'2018-08-21 14:15:54',NULL),(921,'Gandula',1,2,'2018-08-21 14:15:54',NULL),(922,'Garagista',1,2,'2018-08-21 14:15:54',NULL),(923,'Garçom',1,2,'2018-08-21 14:15:54',NULL),(924,'Garçom (serviços de vinhos)',1,2,'2018-08-21 14:15:54',NULL),(925,'Garimpeiro',1,2,'2018-08-21 14:15:54',NULL),(926,'Gelador industrial',1,2,'2018-08-21 14:15:54',NULL),(927,'Gelador profissional',1,2,'2018-08-21 14:15:54',NULL),(928,'Geneticista',1,2,'2018-08-21 14:15:54',NULL),(929,'Geofísico',1,2,'2018-08-21 14:15:54',NULL),(930,'Geofísico espacial',1,2,'2018-08-21 14:15:54',NULL),(931,'Geógrafo',1,2,'2018-08-21 14:15:54',NULL),(932,'Geólogo',1,2,'2018-08-21 14:15:54',NULL),(933,'Geólogo de engenharia',1,2,'2018-08-21 14:15:54',NULL),(934,'Geoquímico',1,2,'2018-08-21 14:15:54',NULL),(935,'Gerente administrativo',1,2,'2018-08-21 14:15:54',NULL),(936,'Gerente comercial',1,2,'2018-08-21 14:15:54',NULL),(937,'Gerente da administração de aeroportos',1,2,'2018-08-21 14:15:54',NULL),(938,'Gerente de agência',1,2,'2018-08-21 14:15:54',NULL),(939,'Gerente de almoxarifado',1,2,'2018-08-21 14:15:54',NULL),(940,'Gerente de bar',1,2,'2018-08-21 14:15:54',NULL),(941,'Gerente de câmbio e comércio exterior',1,2,'2018-08-21 14:15:54',NULL),(942,'Gerente de captação (fundos e investimentos institucionais)',1,2,'2018-08-21 14:15:54',NULL),(943,'Gerente de clientes especiais (private)',1,2,'2018-08-21 14:15:54',NULL),(944,'Gerente de compras',1,2,'2018-08-21 14:15:54',NULL),(945,'Gerente de comunicação',1,2,'2018-08-21 14:15:54',NULL),(946,'Gerente de contas - pessoa física e jurídica',1,2,'2018-08-21 14:15:54',NULL),(947,'Gerente de crédito e cobrança',1,2,'2018-08-21 14:15:54',NULL),(948,'Gerente de crédito imobiliário',1,2,'2018-08-21 14:15:54',NULL),(949,'Gerente de crédito rural',1,2,'2018-08-21 14:15:54',NULL),(950,'Gerente de departamento pessoal',1,2,'2018-08-21 14:15:54',NULL),(951,'Gerente de desenvolvimento de sistemas',1,2,'2018-08-21 14:15:54',NULL),(952,'Gerente de empresa aérea em aeroportos',1,2,'2018-08-21 14:15:54',NULL),(953,'Gerente de grandes contas (corporate)',1,2,'2018-08-21 14:15:54',NULL),(954,'Gerente de hotel',1,2,'2018-08-21 14:15:54',NULL),(955,'Gerente de instituição educacional da área privada',1,2,'2018-08-21 14:15:54',NULL),(956,'Gerente de logística (armazenagem e distribuição)',1,2,'2018-08-21 14:15:54',NULL),(957,'Gerente de loja e supermercado',1,2,'2018-08-21 14:15:54',NULL),(958,'Gerente de marketing',1,2,'2018-08-21 14:15:54',NULL),(959,'Gerente de operações de correios e telecomunicações',1,2,'2018-08-21 14:15:54',NULL),(960,'Gerente de operações de serviços de assistência técnica',1,2,'2018-08-21 14:15:54',NULL),(961,'Gerente de operações de transportes',1,2,'2018-08-21 14:15:54',NULL),(962,'Gerente de pensão',1,2,'2018-08-21 14:15:54',NULL),(963,'Gerente de pesquisa e desenvolvimento (p&d)',1,2,'2018-08-21 14:15:54',NULL),(964,'Gerente de produção de tecnologia da informação',1,2,'2018-08-21 14:15:54',NULL),(965,'Gerente de produção e operações',1,2,'2018-08-21 14:15:54',NULL),(966,'Gerente de produção e operações  aqüícolas',1,2,'2018-08-21 14:15:54',NULL),(967,'Gerente de produção e operações  florestais',1,2,'2018-08-21 14:15:54',NULL),(968,'Gerente de produção e operações agropecuárias',1,2,'2018-08-21 14:15:54',NULL),(969,'Gerente de produção e operações da construção civil e obras públicas',1,2,'2018-08-21 14:15:54',NULL),(970,'Gerente de produção e operações pesqueiras',1,2,'2018-08-21 14:15:54',NULL),(971,'Gerente de produtos bancários',1,2,'2018-08-21 14:15:54',NULL),(972,'Gerente de projetos de tecnologia da informação',1,2,'2018-08-21 14:15:54',NULL),(973,'Gerente de projetos e serviços de manutenção',1,2,'2018-08-21 14:15:54',NULL),(974,'Gerente de recuperação de crédito',1,2,'2018-08-21 14:15:54',NULL),(975,'Gerente de recursos humanos',1,2,'2018-08-21 14:15:54',NULL),(976,'Gerente de rede',1,2,'2018-08-21 14:15:54',NULL),(977,'Gerente de restaurante',1,2,'2018-08-21 14:15:54',NULL),(978,'Gerente de riscos',1,2,'2018-08-21 14:15:54',NULL),(979,'Gerente de segurança de tecnologia da informação',1,2,'2018-08-21 14:15:54',NULL),(980,'Gerente de serviços culturais',1,2,'2018-08-21 14:15:54',NULL),(981,'Gerente de serviços de saúde',1,2,'2018-08-21 14:15:54',NULL),(982,'Gerente de serviços educacionais da área pública',1,2,'2018-08-21 14:15:54',NULL),(983,'Gerente de serviços sociais',1,2,'2018-08-21 14:15:54',NULL),(984,'Gerente de suporte técnico de tecnologia da informação',1,2,'2018-08-21 14:15:54',NULL),(985,'Gerente de suprimentos',1,2,'2018-08-21 14:15:54',NULL),(986,'Gerente de turismo',1,2,'2018-08-21 14:15:54',NULL),(987,'Gerente de vendas',1,2,'2018-08-21 14:15:54',NULL),(988,'Gerente financeiro',1,2,'2018-08-21 14:15:54',NULL),(989,'Gerontólogo',1,2,'2018-08-21 14:15:54',NULL),(990,'Gesseiro',1,2,'2018-08-21 14:15:54',NULL),(991,'Gestor em segurança',1,2,'2018-08-21 14:15:54',NULL),(992,'Governador de estado',1,2,'2018-08-21 14:15:54',NULL),(993,'Governador do distrito federal',1,2,'2018-08-21 14:15:54',NULL),(994,'Governanta de hotelaria',1,2,'2018-08-21 14:15:54',NULL),(995,'Gravador (joalheria e ourivesaria)',1,2,'2018-08-21 14:15:54',NULL),(996,'Gravador de inscrições em pedra',1,2,'2018-08-21 14:15:54',NULL),(997,'Gravador de matriz calcográfica',1,2,'2018-08-21 14:15:54',NULL),(998,'Gravador de matriz para flexografia (clicherista)',1,2,'2018-08-21 14:15:54',NULL),(999,'Gravador de matriz para rotogravura (eletromecânico e químico)',1,2,'2018-08-21 14:15:54',NULL),(1000,'Gravador de matriz serigráfica',1,2,'2018-08-21 14:15:54',NULL),(1001,'Gravador de relevos em pedra',1,2,'2018-08-21 14:15:54',NULL),(1002,'Gravador de vidro a  água-forte',1,2,'2018-08-21 14:15:54',NULL),(1003,'Gravador de vidro a  esmeril',1,2,'2018-08-21 14:15:54',NULL),(1004,'Gravador de vidro a  jato de areia',1,2,'2018-08-21 14:15:54',NULL),(1005,'Gravador, à mão (encadernação)',1,2,'2018-08-21 14:15:54',NULL),(1006,'Guarda portuário',1,2,'2018-08-21 14:15:54',NULL),(1007,'Guarda-civil municipal',1,2,'2018-08-21 14:15:54',NULL),(1008,'Guarda-roupeira de cinema',1,2,'2018-08-21 14:15:54',NULL),(1009,'Guardador de veículos',1,2,'2018-08-21 14:15:54',NULL),(1010,'Guia de turismo',1,2,'2018-08-21 14:15:54',NULL),(1011,'Guia florestal',1,2,'2018-08-21 14:15:54',NULL),(1012,'Guincheiro (construção civil)',1,2,'2018-08-21 14:15:54',NULL),(1013,'Hidrogenador de óleos e gorduras',1,2,'2018-08-21 14:15:54',NULL),(1014,'Hidrogeólogo',1,2,'2018-08-21 14:15:54',NULL),(1015,'Higienista ocupacional',1,2,'2018-08-21 14:15:54',NULL),(1016,'Identificador florestal',1,2,'2018-08-21 14:15:54',NULL),(1017,'Iluminador (televisão)',1,2,'2018-08-21 14:15:54',NULL),(1018,'Imediato da marinha mercante',1,2,'2018-08-21 14:15:54',NULL),(1019,'Impregnador de madeira',1,2,'2018-08-21 14:15:54',NULL),(1020,'Impressor (serigrafia)',1,2,'2018-08-21 14:15:54',NULL),(1021,'Impressor calcográfico',1,2,'2018-08-21 14:15:54',NULL),(1022,'Impressor de corte e vinco',1,2,'2018-08-21 14:15:54',NULL),(1023,'Impressor de ofsete (plano e rotativo)',1,2,'2018-08-21 14:15:54',NULL),(1024,'Impressor de rotativa',1,2,'2018-08-21 14:15:54',NULL),(1025,'Impressor de rotogravura',1,2,'2018-08-21 14:15:54',NULL),(1026,'Impressor digital',1,2,'2018-08-21 14:15:54',NULL),(1027,'Impressor flexográfico',1,2,'2018-08-21 14:15:54',NULL),(1028,'Impressor letterset',1,2,'2018-08-21 14:15:54',NULL),(1029,'Impressor tampográfico',1,2,'2018-08-21 14:15:54',NULL),(1030,'Impressor tipográfico',1,2,'2018-08-21 14:15:54',NULL),(1031,'Inseminador',1,2,'2018-08-21 14:15:54',NULL),(1032,'Inspetor de alunos de escola privada',1,2,'2018-08-21 14:15:54',NULL),(1033,'Inspetor de alunos de escola pública',1,2,'2018-08-21 14:15:54',NULL),(1034,'Inspetor de aviação civil',1,2,'2018-08-21 14:15:54',NULL),(1035,'Inspetor de estamparia (produção têxtil)',1,2,'2018-08-21 14:15:54',NULL),(1036,'Inspetor de qualidade',1,2,'2018-08-21 14:15:54',NULL),(1037,'Inspetor de risco',1,2,'2018-08-21 14:15:54',NULL),(1038,'Inspetor de serviços de transportes rodoviários (passageiros e cargas)',1,2,'2018-08-21 14:15:54',NULL),(1039,'Inspetor de sinistros',1,2,'2018-08-21 14:15:54',NULL),(1040,'Inspetor de soldagem',1,2,'2018-08-21 14:15:54',NULL),(1041,'Inspetor de terminal',1,2,'2018-08-21 14:15:54',NULL),(1042,'Inspetor de terraplenagem',1,2,'2018-08-21 14:15:54',NULL),(1043,'Inspetor de via permanente (trilhos)',1,2,'2018-08-21 14:15:54',NULL),(1044,'Inspetor naval',1,2,'2018-08-21 14:15:54',NULL),(1045,'Instalador de cortinas e persianas, portas sanfonadas e boxe',1,2,'2018-08-21 14:15:54',NULL),(1046,'Instalador de isolantes acústicos',1,2,'2018-08-21 14:15:54',NULL),(1047,'Instalador de isolantes térmicos (refrigeração e climatização)',1,2,'2018-08-21 14:15:54',NULL),(1048,'Instalador de isolantes térmicos de caldeira e tubulações',1,2,'2018-08-21 14:15:54',NULL),(1049,'Instalador de linhas elétricas de alta e baixa - tensão (rede aérea e subterrânea)',1,2,'2018-08-21 14:15:54',NULL),(1050,'Instalador de material isolante, a mão (edificações)',1,2,'2018-08-21 14:15:54',NULL),(1051,'Instalador de material isolante, a máquina (edificações)',1,2,'2018-08-21 14:15:54',NULL),(1052,'Instalador de sistemas eletroeletrônicos de segurança',1,2,'2018-08-21 14:15:54',NULL),(1053,'Instalador de som e acessórios de veículos',1,2,'2018-08-21 14:15:54',NULL),(1054,'Instalador de tubulações',1,2,'2018-08-21 14:15:54',NULL),(1055,'Instalador de tubulações (aeronaves)',1,2,'2018-08-21 14:15:54',NULL),(1056,'Instalador de tubulações (embarcações)',1,2,'2018-08-21 14:15:54',NULL),(1057,'Instalador de tubulações de gás combustível (produção e distribuição)',1,2,'2018-08-21 14:15:54',NULL),(1058,'Instalador de tubulações de vapor (produção e distribuição)',1,2,'2018-08-21 14:15:54',NULL),(1059,'Instalador eletricista (tração de veículos)',1,2,'2018-08-21 14:15:54',NULL),(1060,'Instalador-reparador de equipamentos de comutação em telefonia',1,2,'2018-08-21 14:15:54',NULL),(1061,'Instalador-reparador de equipamentos de energia em telefonia',1,2,'2018-08-21 14:15:54',NULL),(1062,'Instalador-reparador de equipamentos de transmissão em telefonia',1,2,'2018-08-21 14:15:54',NULL),(1063,'Instalador-reparador de linhas e aparelhos de telecomunicações',1,2,'2018-08-21 14:15:54',NULL),(1064,'Instalador-reparador de redes e cabos telefônicos',1,2,'2018-08-21 14:15:54',NULL),(1065,'Instalador-reparador de redes telefônicas e de comunicação de dados',1,2,'2018-08-21 14:15:54',NULL),(1066,'Instrumentador cirúrgico',1,2,'2018-08-21 14:15:54',NULL),(1067,'Instrutor de aprendizagem e treinamento agropecuário',1,2,'2018-08-21 14:15:54',NULL),(1068,'Instrutor de aprendizagem e treinamento comercial',1,2,'2018-08-21 14:15:54',NULL),(1069,'Instrutor de aprendizagem e treinamento industrial',1,2,'2018-08-21 14:15:54',NULL),(1070,'Instrutor de auto-escola',1,2,'2018-08-21 14:15:54',NULL),(1071,'Instrutor de cursos livres',1,2,'2018-08-21 14:15:54',NULL),(1072,'Instrutor de vôo',1,2,'2018-08-21 14:15:54',NULL),(1073,'Intérprete',1,2,'2018-08-21 14:15:54',NULL),(1074,'Intérprete de língua de sinais',1,2,'2018-08-21 14:15:54',NULL),(1075,'Investigador de polícia',1,2,'2018-08-21 14:15:54',NULL),(1076,'Jardineiro',1,2,'2018-08-21 14:15:54',NULL),(1077,'Joalheiro',1,2,'2018-08-21 14:15:54',NULL),(1078,'Joalheiro (reparações)',1,2,'2018-08-21 14:15:54',NULL),(1079,'Jóquei',1,2,'2018-08-21 14:15:54',NULL),(1080,'Jornaleiro (em banca de jornal)',1,2,'2018-08-21 14:15:54',NULL),(1081,'Jornalista',1,2,'2018-08-21 14:15:54',NULL),(1082,'Juiz auditor estadual - justiça militar',1,2,'2018-08-21 14:15:54',NULL),(1083,'Juiz auditor federal - justiça militar',1,2,'2018-08-21 14:15:54',NULL),(1084,'Juiz de direito',1,2,'2018-08-21 14:15:54',NULL),(1085,'Juiz do trabalho',1,2,'2018-08-21 14:15:54',NULL),(1086,'Juiz federal',1,2,'2018-08-21 14:15:54',NULL),(1087,'Kardexista',1,2,'2018-08-21 14:15:54',NULL),(1088,'Laboratorista fotográfico',1,2,'2018-08-21 14:15:54',NULL),(1089,'Ladrilheiro',1,2,'2018-08-21 14:15:54',NULL),(1090,'Lagareiro',1,2,'2018-08-21 14:15:54',NULL),(1091,'Laminador de metais preciosos a  mão',1,2,'2018-08-21 14:15:54',NULL),(1092,'Laminador de plástico',1,2,'2018-08-21 14:15:54',NULL),(1093,'Lapidador (jóias)',1,2,'2018-08-21 14:15:54',NULL),(1094,'Lapidador de vidros e cristais',1,2,'2018-08-21 14:15:54',NULL),(1095,'Lavadeiro, em geral',1,2,'2018-08-21 14:15:54',NULL),(1096,'Lavador de artefatos de tapeçaria',1,2,'2018-08-21 14:15:54',NULL),(1097,'Lavador de garrafas, vidros e outros utensílios',1,2,'2018-08-21 14:15:54',NULL),(1098,'Lavador de lã',1,2,'2018-08-21 14:15:54',NULL),(1099,'Lavador de peças',1,2,'2018-08-21 14:15:54',NULL),(1100,'Lavador de roupas',1,2,'2018-08-21 14:15:54',NULL),(1101,'Lavador de roupas  a maquina',1,2,'2018-08-21 14:15:54',NULL),(1102,'Lavador de veículos',1,2,'2018-08-21 14:15:54',NULL),(1103,'Leiloeiro',1,2,'2018-08-21 14:15:54',NULL),(1104,'Leiturista',1,2,'2018-08-21 14:15:54',NULL),(1105,'Líder de comunidade caiçara',1,2,'2018-08-21 14:15:54',NULL),(1106,'Ligador de linhas telefônicas',1,2,'2018-08-21 14:15:54',NULL),(1107,'Limpador a seco, à máquina',1,2,'2018-08-21 14:15:54',NULL),(1108,'Limpador de fachadas',1,2,'2018-08-21 14:15:54',NULL),(1109,'Limpador de piscinas',1,2,'2018-08-21 14:15:54',NULL),(1110,'Limpador de roupas a seco, à mão',1,2,'2018-08-21 14:15:54',NULL),(1111,'Limpador de vidros',1,2,'2018-08-21 14:15:54',NULL),(1112,'Lingotador',1,2,'2018-08-21 14:15:54',NULL),(1113,'Lingüista',1,2,'2018-08-21 14:15:54',NULL),(1114,'Linotipista',1,2,'2018-08-21 14:15:54',NULL),(1115,'Lixador de couros e peles',1,2,'2018-08-21 14:15:54',NULL),(1116,'Localizador (cobrador)',1,2,'2018-08-21 14:15:54',NULL),(1117,'Locutor de rádio e televisão',1,2,'2018-08-21 14:15:54',NULL),(1118,'Locutor publicitário de rádio e televisão',1,2,'2018-08-21 14:15:54',NULL),(1119,'Lubrificador de embarcações',1,2,'2018-08-21 14:15:54',NULL),(1120,'Lubrificador de veículos automotores (exceto embarcações)',1,2,'2018-08-21 14:15:54',NULL),(1121,'Lubrificador industrial',1,2,'2018-08-21 14:15:54',NULL),(1122,'Ludomotricista',1,2,'2018-08-21 14:15:54',NULL),(1123,'Lustrador de peças de madeira',1,2,'2018-08-21 14:15:54',NULL),(1124,'Lustrador de piso',1,2,'2018-08-21 14:15:54',NULL),(1125,'Luthier (restauração de cordas arcadas)',1,2,'2018-08-21 14:15:54',NULL),(1126,'Macheiro, a  máquina',1,2,'2018-08-21 14:15:54',NULL),(1127,'Macheiro, a mão',1,2,'2018-08-21 14:15:54',NULL),(1128,'Mãe social',1,2,'2018-08-21 14:15:54',NULL),(1129,'Magarefe',1,2,'2018-08-21 14:15:54',NULL),(1130,'Mágico',1,2,'2018-08-21 14:15:54',NULL),(1131,'Maître',1,2,'2018-08-21 14:15:54',NULL),(1132,'Major bombeiro militar',1,2,'2018-08-21 14:15:54',NULL),(1133,'Major da polícia militar',1,2,'2018-08-21 14:15:54',NULL),(1134,'Malabarista',1,2,'2018-08-21 14:15:54',NULL),(1135,'Malteiro (germinação)',1,2,'2018-08-21 14:15:54',NULL),(1136,'Manicure',1,2,'2018-08-21 14:15:54',NULL),(1137,'Manobrador',1,2,'2018-08-21 14:15:54',NULL),(1138,'Manteigueiro na fabricação de laticínio',1,2,'2018-08-21 14:15:54',NULL),(1139,'Mantenedor de equipamentos de parques de diversões e similares',1,2,'2018-08-21 14:15:54',NULL),(1140,'Mantenedor de sistemas eletroeletrônicos de segurança',1,2,'2018-08-21 14:15:54',NULL),(1141,'Maquetista na marcenaria',1,2,'2018-08-21 14:15:54',NULL),(1142,'Maquiador',1,2,'2018-08-21 14:15:54',NULL),(1143,'Maquiador de caracterização',1,2,'2018-08-21 14:15:54',NULL),(1144,'Maquinista de cinema e vídeo',1,2,'2018-08-21 14:15:54',NULL),(1145,'Maquinista de embarcações',1,2,'2018-08-21 14:15:54',NULL),(1146,'Maquinista de teatro e espetáculos',1,2,'2018-08-21 14:15:54',NULL),(1147,'Maquinista de trem',1,2,'2018-08-21 14:15:54',NULL),(1148,'Maquinista de trem metropolitano',1,2,'2018-08-21 14:15:54',NULL),(1149,'Marcador de peças confeccionadas para bordar',1,2,'2018-08-21 14:15:54',NULL),(1150,'Marcador de produtos (siderúrgico e metalúrgico)',1,2,'2018-08-21 14:15:54',NULL),(1151,'Marceneiro',1,2,'2018-08-21 14:15:54',NULL),(1152,'Marcheteiro',1,2,'2018-08-21 14:15:54',NULL),(1153,'Marinheiro auxiliar de convés (marítimo e aquaviario)',1,2,'2018-08-21 14:15:54',NULL),(1154,'Marinheiro auxiliar de máquinas (marítimo e aquaviário)',1,2,'2018-08-21 14:15:54',NULL),(1155,'Marinheiro de convés (marítimo e fluviário)',1,2,'2018-08-21 14:15:54',NULL),(1156,'Marinheiro de esporte e recreio',1,2,'2018-08-21 14:15:54',NULL),(1157,'Marinheiro de máquinas',1,2,'2018-08-21 14:15:54',NULL),(1158,'Marmorista (construção)',1,2,'2018-08-21 14:15:54',NULL),(1159,'Masseiro (massas alimentícias)',1,2,'2018-08-21 14:15:54',NULL),(1160,'Massoterapeuta',1,2,'2018-08-21 14:15:54',NULL),(1161,'Matemático',1,2,'2018-08-21 14:15:54',NULL),(1162,'Matemático aplicado',1,2,'2018-08-21 14:15:54',NULL),(1163,'Matizador de couros e peles',1,2,'2018-08-21 14:15:54',NULL),(1164,'Mecânico de manutenção de aeronaves, em geral',1,2,'2018-08-21 14:15:54',NULL),(1165,'Mecânico de manutenção de aparelhos de levantamento',1,2,'2018-08-21 14:15:54',NULL),(1166,'Mecânico de manutenção de aparelhos esportivos e de ginástica',1,2,'2018-08-21 14:15:54',NULL),(1167,'Mecânico de manutenção de automóveis, motocicletas e veículos similares',1,2,'2018-08-21 14:15:54',NULL),(1168,'Mecânico de manutenção de bicicletas e veículos similares',1,2,'2018-08-21 14:15:54',NULL),(1169,'Mecânico de manutenção de bomba injetora (exceto de veículos automotores)',1,2,'2018-08-21 14:15:54',NULL),(1170,'Mecânico de manutenção de bombas',1,2,'2018-08-21 14:15:54',NULL),(1171,'Mecânico de manutenção de compressores de ar',1,2,'2018-08-21 14:15:54',NULL),(1172,'Mecânico de manutenção de empilhadeiras e outros veículos de cargas leves',1,2,'2018-08-21 14:15:54',NULL),(1173,'Mecânico de manutenção de equipamento de mineração',1,2,'2018-08-21 14:15:54',NULL),(1174,'Mecânico de manutenção de instalações mecânicas de edifícios',1,2,'2018-08-21 14:15:54',NULL),(1175,'Mecânico de manutenção de máquinas agrícolas',1,2,'2018-08-21 14:15:54',NULL),(1176,'Mecânico de manutenção de máquinas cortadoras de grama, roçadeiras, motosserras e similares',1,2,'2018-08-21 14:15:54',NULL),(1177,'Mecânico de manutenção de máquinas de construção e terraplenagem',1,2,'2018-08-21 14:15:54',NULL),(1178,'Mecânico de manutenção de máquinas gráficas',1,2,'2018-08-21 14:15:54',NULL),(1179,'Mecânico de manutenção de máquinas operatrizes (lavra de madeira)',1,2,'2018-08-21 14:15:54',NULL),(1180,'Mecânico de manutenção de máquinas têxteis',1,2,'2018-08-21 14:15:54',NULL),(1181,'Mecânico de manutenção de máquinas, em geral',1,2,'2018-08-21 14:15:54',NULL),(1182,'Mecânico de manutenção de máquinas-ferramentas (usinagem de metais)',1,2,'2018-08-21 14:15:54',NULL),(1183,'Mecânico de manutenção de motocicletas',1,2,'2018-08-21 14:15:54',NULL),(1184,'Mecânico de manutenção de motores diesel (exceto de veículos automotores)',1,2,'2018-08-21 14:15:54',NULL),(1185,'Mecânico de manutenção de motores e equipamentos navais',1,2,'2018-08-21 14:15:54',NULL),(1186,'Mecânico de manutenção de redutores',1,2,'2018-08-21 14:15:54',NULL),(1187,'Mecânico de manutenção de sistema hidráulico de aeronaves (serviços de pista e hangar)',1,2,'2018-08-21 14:15:54',NULL),(1188,'Mecânico de manutenção de tratores',1,2,'2018-08-21 14:15:54',NULL),(1189,'Mecânico de manutenção de turbinas (exceto de aeronaves)',1,2,'2018-08-21 14:15:54',NULL),(1190,'Mecânico de manutenção de turbocompressores',1,2,'2018-08-21 14:15:54',NULL),(1191,'Mecânico de manutenção de veículos ferroviários',1,2,'2018-08-21 14:15:54',NULL),(1192,'Mecânico de manutenção e instalação de aparelhos de climatização e  refrigeração',1,2,'2018-08-21 14:15:54',NULL),(1193,'Mecânico de refrigeração',1,2,'2018-08-21 14:15:54',NULL),(1194,'Mecânico de veículos automotores a diesel (exceto tratores)',1,2,'2018-08-21 14:15:54',NULL),(1195,'Mecânico de vôo',1,2,'2018-08-21 14:15:54',NULL),(1196,'Mecânico montador de motores de aeronaves',1,2,'2018-08-21 14:15:54',NULL),(1197,'Mecânico montador de motores de embarcações',1,2,'2018-08-21 14:15:54',NULL),(1198,'Mecânico montador de motores de explosão e diesel',1,2,'2018-08-21 14:15:54',NULL),(1199,'Mecânico montador de turboalimentadores',1,2,'2018-08-21 14:15:54',NULL),(1200,'Médico acupunturista',1,2,'2018-08-21 14:15:54',NULL),(1201,'Médico alergista e imunologista',1,2,'2018-08-21 14:15:54',NULL),(1202,'Médico anatomopatologista',1,2,'2018-08-21 14:15:54',NULL),(1203,'Médico anestesiologista',1,2,'2018-08-21 14:15:54',NULL),(1204,'Médico angiologista',1,2,'2018-08-21 14:15:54',NULL),(1205,'Médico antroposófico',1,2,'2018-08-21 14:15:54',NULL),(1206,'Médico cancerologista cirurgíco',1,2,'2018-08-21 14:15:54',NULL),(1207,'Médico cancerologista pediátrico',1,2,'2018-08-21 14:15:54',NULL),(1208,'Médico cardiologista',1,2,'2018-08-21 14:15:54',NULL),(1209,'Médico cirurgião cardiovascular',1,2,'2018-08-21 14:15:54',NULL),(1210,'Médico cirurgião da mão',1,2,'2018-08-21 14:15:54',NULL),(1211,'Médico cirurgião de cabeça e pescoço',1,2,'2018-08-21 14:15:54',NULL),(1212,'Médico cirurgião do aparelho digestivo',1,2,'2018-08-21 14:15:54',NULL),(1213,'Médico cirurgião geral',1,2,'2018-08-21 14:15:54',NULL),(1214,'Médico cirurgião pediátrico',1,2,'2018-08-21 14:15:54',NULL),(1215,'Médico cirurgião plástico',1,2,'2018-08-21 14:15:54',NULL),(1216,'Médico cirurgião torácico',1,2,'2018-08-21 14:15:54',NULL),(1217,'Médico citopatologista',1,2,'2018-08-21 14:15:54',NULL),(1218,'Médico clínico',1,2,'2018-08-21 14:15:54',NULL),(1219,'Médico coloproctologista',1,2,'2018-08-21 14:15:54',NULL),(1220,'Médico da estratégia de saúde da família',1,2,'2018-08-21 14:15:54',NULL),(1221,'Médico de família e comunidade',1,2,'2018-08-21 14:15:54',NULL),(1222,'Médico dermatologista',1,2,'2018-08-21 14:15:54',NULL),(1223,'Médico do trabalho',1,2,'2018-08-21 14:15:54',NULL),(1224,'Médico em cirurgia vascular',1,2,'2018-08-21 14:15:54',NULL),(1225,'Médico em endoscopia',1,2,'2018-08-21 14:15:54',NULL),(1226,'Médico em medicina de tráfego',1,2,'2018-08-21 14:15:54',NULL),(1227,'Médico em medicina intensiva',1,2,'2018-08-21 14:15:54',NULL),(1228,'Médico em medicina nuclear',1,2,'2018-08-21 14:15:54',NULL),(1229,'Médico em radiologia e diagnóstico por imagem',1,2,'2018-08-21 14:15:54',NULL),(1230,'Médico endocrinologista e metabologista',1,2,'2018-08-21 14:15:54',NULL),(1231,'Médico fisiatra',1,2,'2018-08-21 14:15:54',NULL),(1232,'Médico gastroenterologista',1,2,'2018-08-21 14:15:54',NULL),(1233,'Médico generalista',1,2,'2018-08-21 14:15:54',NULL),(1234,'Médico geneticista',1,2,'2018-08-21 14:15:54',NULL),(1235,'Médico geriatra',1,2,'2018-08-21 14:15:54',NULL),(1236,'Médico ginecologista e obstetra',1,2,'2018-08-21 14:15:54',NULL),(1237,'Médico hematologista',1,2,'2018-08-21 14:15:54',NULL),(1238,'Médico hemoterapeuta',1,2,'2018-08-21 14:15:54',NULL),(1239,'Médico hiperbarista',1,2,'2018-08-21 14:15:54',NULL),(1240,'Médico homeopata',1,2,'2018-08-21 14:15:54',NULL),(1241,'Médico infectologista',1,2,'2018-08-21 14:15:54',NULL),(1242,'Médico legista',1,2,'2018-08-21 14:15:54',NULL),(1243,'Médico mastologista',1,2,'2018-08-21 14:15:54',NULL),(1244,'Médico nefrologista',1,2,'2018-08-21 14:15:54',NULL),(1245,'Médico neurocirurgião',1,2,'2018-08-21 14:15:54',NULL),(1246,'Médico neurofisiologista clínico',1,2,'2018-08-21 14:15:54',NULL),(1247,'Médico neurologista',1,2,'2018-08-21 14:15:54',NULL),(1248,'Médico nutrologista',1,2,'2018-08-21 14:15:54',NULL),(1249,'Médico oftalmologista',1,2,'2018-08-21 14:15:54',NULL),(1250,'Médico oncologista clínico',1,2,'2018-08-21 14:15:54',NULL),(1251,'Médico ortopedista e traumatologista',1,2,'2018-08-21 14:15:54',NULL),(1252,'Médico otorrinolaringologista',1,2,'2018-08-21 14:15:54',NULL),(1253,'Médico patologista',1,2,'2018-08-21 14:15:54',NULL),(1254,'Médico patologista clínico / medicina laboratorial',1,2,'2018-08-21 14:15:54',NULL),(1255,'Médico pediatra',1,2,'2018-08-21 14:15:54',NULL),(1256,'Médico pneumologista',1,2,'2018-08-21 14:15:54',NULL),(1257,'Médico psiquiatra',1,2,'2018-08-21 14:15:54',NULL),(1258,'Médico radioterapeuta',1,2,'2018-08-21 14:15:54',NULL),(1259,'Médico reumatologista',1,2,'2018-08-21 14:15:54',NULL),(1260,'Médico sanitarista',1,2,'2018-08-21 14:15:54',NULL),(1261,'Médico urologista',1,2,'2018-08-21 14:15:54',NULL),(1262,'Médico veterinário',1,2,'2018-08-21 14:15:54',NULL),(1263,'Membro de liderança quilombola',1,2,'2018-08-21 14:15:54',NULL),(1264,'Membro superior do poder executivo',1,2,'2018-08-21 14:15:54',NULL),(1265,'Mergulhador profissional (raso e profundo)',1,2,'2018-08-21 14:15:54',NULL),(1266,'Mestre (afiador de ferramentas)',1,2,'2018-08-21 14:15:54',NULL),(1267,'Mestre (construção civil)',1,2,'2018-08-21 14:15:54',NULL),(1268,'Mestre (construção naval)',1,2,'2018-08-21 14:15:54',NULL),(1269,'Mestre (indústria de automotores e material de transportes)',1,2,'2018-08-21 14:15:54',NULL),(1270,'Mestre (indústria de borracha e plástico)',1,2,'2018-08-21 14:15:54',NULL),(1271,'Mestre (indústria de celulose, papel e papelão)',1,2,'2018-08-21 14:15:54',NULL),(1272,'Mestre (indústria de madeira e mobiliário)',1,2,'2018-08-21 14:15:54',NULL),(1273,'Mestre (indústria de máquinas e outros equipamentos mecânicos)',1,2,'2018-08-21 14:15:54',NULL),(1274,'Mestre (indústria petroquímica e carboquímica)',1,2,'2018-08-21 14:15:54',NULL),(1275,'Mestre (indústria têxtil e de confecções)',1,2,'2018-08-21 14:15:54',NULL),(1276,'Mestre carpinteiro',1,2,'2018-08-21 14:15:54',NULL),(1277,'Mestre de aciaria',1,2,'2018-08-21 14:15:54',NULL),(1278,'Mestre de alto-forno',1,2,'2018-08-21 14:15:54',NULL),(1279,'Mestre de cabotagem',1,2,'2018-08-21 14:15:54',NULL),(1280,'Mestre de caldeiraria',1,2,'2018-08-21 14:15:54',NULL),(1281,'Mestre de cerimonias',1,2,'2018-08-21 14:15:54',NULL),(1282,'Mestre de construção de fornos',1,2,'2018-08-21 14:15:54',NULL),(1283,'Mestre de ferramentaria',1,2,'2018-08-21 14:15:54',NULL),(1284,'Mestre de forjaria',1,2,'2018-08-21 14:15:54',NULL),(1285,'Mestre de forno elétrico',1,2,'2018-08-21 14:15:54',NULL),(1286,'Mestre de fundição',1,2,'2018-08-21 14:15:54',NULL),(1287,'Mestre de galvanoplastia',1,2,'2018-08-21 14:15:54',NULL),(1288,'Mestre de laminação',1,2,'2018-08-21 14:15:54',NULL),(1289,'Mestre de linhas (ferrovias)',1,2,'2018-08-21 14:15:54',NULL),(1290,'Mestre de pintura (tratamento de superfícies)',1,2,'2018-08-21 14:15:54',NULL),(1291,'Mestre de produção farmacêutica',1,2,'2018-08-21 14:15:54',NULL),(1292,'Mestre de produção química',1,2,'2018-08-21 14:15:54',NULL),(1293,'Mestre de siderurgia',1,2,'2018-08-21 14:15:54',NULL),(1294,'Mestre de soldagem',1,2,'2018-08-21 14:15:54',NULL),(1295,'Mestre de trefilação de metais',1,2,'2018-08-21 14:15:54',NULL),(1296,'Mestre de usinagem',1,2,'2018-08-21 14:15:54',NULL),(1297,'Mestre fluvial',1,2,'2018-08-21 14:15:54',NULL),(1298,'Mestre serralheiro',1,2,'2018-08-21 14:15:54',NULL),(1299,'Metalizador (banho quente)',1,2,'2018-08-21 14:15:54',NULL),(1300,'Metalizador a pistola',1,2,'2018-08-21 14:15:54',NULL),(1301,'Meteorologista',1,2,'2018-08-21 14:15:54',NULL),(1302,'Metrologista',1,2,'2018-08-21 14:15:54',NULL),(1303,'Microfonista',1,2,'2018-08-21 14:15:54',NULL),(1304,'Mineiro',1,2,'2018-08-21 14:15:54',NULL),(1305,'Minhocultor',1,2,'2018-08-21 14:15:54',NULL),(1306,'Ministro de culto religioso',1,2,'2018-08-21 14:15:54',NULL),(1307,'Ministro de estado',1,2,'2018-08-21 14:15:54',NULL),(1308,'Ministro do  superior tribunal do trabalho',1,2,'2018-08-21 14:15:54',NULL),(1309,'Ministro do  superior tribunal militar',1,2,'2018-08-21 14:15:54',NULL),(1310,'Ministro do superior tribunal de justiça',1,2,'2018-08-21 14:15:54',NULL),(1311,'Ministro do supremo tribunal federal',1,2,'2018-08-21 14:15:54',NULL),(1312,'Missionário',1,2,'2018-08-21 14:15:54',NULL),(1313,'Misturador de café',1,2,'2018-08-21 14:15:54',NULL),(1314,'Misturador de chá ou mate',1,2,'2018-08-21 14:15:54',NULL),(1315,'Moço de convés (marítimo e fluviário)',1,2,'2018-08-21 14:15:54',NULL),(1316,'Moço de máquinas (marítimo e fluviário)',1,2,'2018-08-21 14:15:54',NULL),(1317,'Modelador de madeira',1,2,'2018-08-21 14:15:54',NULL),(1318,'Modelador de metais (fundição)',1,2,'2018-08-21 14:15:54',NULL),(1319,'Modelista de calçados',1,2,'2018-08-21 14:15:54',NULL),(1320,'Modelista de roupas',1,2,'2018-08-21 14:15:54',NULL),(1321,'Modelo artístico',1,2,'2018-08-21 14:15:54',NULL),(1322,'Modelo de modas',1,2,'2018-08-21 14:15:54',NULL),(1323,'Modelo publicitário',1,2,'2018-08-21 14:15:54',NULL),(1324,'Moedor de café',1,2,'2018-08-21 14:15:54',NULL),(1325,'Moedor de sal',1,2,'2018-08-21 14:15:54',NULL),(1326,'Moldador (vidros)',1,2,'2018-08-21 14:15:54',NULL),(1327,'Moldador de abrasivos na fabricação de cerâmica, vidro e porcelana',1,2,'2018-08-21 14:15:54',NULL),(1328,'Moldador de borracha por compressão',1,2,'2018-08-21 14:15:54',NULL),(1329,'Moldador de corpos de prova em usinas de concreto',1,2,'2018-08-21 14:15:54',NULL),(1330,'Moldador de plástico por compressão',1,2,'2018-08-21 14:15:54',NULL),(1331,'Moldador de plástico por injeção',1,2,'2018-08-21 14:15:54',NULL),(1332,'Moldador, a  mão',1,2,'2018-08-21 14:15:54',NULL),(1333,'Moldador, a  máquina',1,2,'2018-08-21 14:15:54',NULL),(1334,'Moleiro (tratamentos químicos e afins)',1,2,'2018-08-21 14:15:54',NULL),(1335,'Moleiro de cereais (exceto arroz)',1,2,'2018-08-21 14:15:54',NULL),(1336,'Moleiro de especiarias',1,2,'2018-08-21 14:15:54',NULL),(1337,'Moleiro de minérios',1,2,'2018-08-21 14:15:54',NULL),(1338,'Monitor de dependente químico',1,2,'2018-08-21 14:15:54',NULL),(1339,'Monitor de sistemas eletrônicos de segurança externo',1,2,'2018-08-21 14:15:54',NULL),(1340,'Monitor de sistemas eletrônicos de segurança interno',1,2,'2018-08-21 14:15:54',NULL),(1341,'Monitor de teleatendimento',1,2,'2018-08-21 14:15:54',NULL),(1342,'Monitor de transporte escolar',1,2,'2018-08-21 14:15:54',NULL),(1343,'Monotipista',1,2,'2018-08-21 14:15:54',NULL),(1344,'Montador de andaimes (edificações)',1,2,'2018-08-21 14:15:54',NULL),(1345,'Montador de artefatos de couro (exceto roupas e calçados)',1,2,'2018-08-21 14:15:54',NULL),(1346,'Montador de bicicletas',1,2,'2018-08-21 14:15:54',NULL),(1347,'Montador de calçados',1,2,'2018-08-21 14:15:54',NULL),(1348,'Montador de equipamento de levantamento',1,2,'2018-08-21 14:15:54',NULL),(1349,'Montador de equipamentos elétricos',1,2,'2018-08-21 14:15:54',NULL),(1350,'Montador de equipamentos elétricos (aparelhos eletrodomésticos)',1,2,'2018-08-21 14:15:54',NULL),(1351,'Montador de equipamentos elétricos (centrais elétricas)',1,2,'2018-08-21 14:15:54',NULL),(1352,'Montador de equipamentos elétricos (elevadores e equipamentos similares)',1,2,'2018-08-21 14:15:54',NULL),(1353,'Montador de equipamentos elétricos (instrumentos de medição)',1,2,'2018-08-21 14:15:54',NULL),(1354,'Montador de equipamentos elétricos (motores e dínamos)',1,2,'2018-08-21 14:15:54',NULL),(1355,'Montador de equipamentos elétricos (transformadores)',1,2,'2018-08-21 14:15:54',NULL),(1356,'Montador de equipamentos eletrônicos',1,2,'2018-08-21 14:15:54',NULL),(1357,'Montador de equipamentos eletrônicos (aparelhos médicos)',1,2,'2018-08-21 14:15:54',NULL),(1358,'Montador de equipamentos eletrônicos (computadores e equipamentos auxiliares)',1,2,'2018-08-21 14:15:54',NULL),(1359,'Montador de equipamentos eletrônicos (estação de rádio, tv e equipamentos de radar)',1,2,'2018-08-21 14:15:54',NULL),(1360,'Montador de equipamentos eletrônicos (instalações de sinalização)',1,2,'2018-08-21 14:15:54',NULL),(1361,'Montador de equipamentos eletrônicos (máquinas industriais)',1,2,'2018-08-21 14:15:54',NULL),(1362,'Montador de estruturas de aeronaves',1,2,'2018-08-21 14:15:54',NULL),(1363,'Montador de estruturas metálicas',1,2,'2018-08-21 14:15:54',NULL),(1364,'Montador de estruturas metálicas de embarcações',1,2,'2018-08-21 14:15:54',NULL),(1365,'Montador de filmes',1,2,'2018-08-21 14:15:54',NULL),(1366,'Montador de fotolito (analógico e digital)',1,2,'2018-08-21 14:15:54',NULL),(1367,'Montador de instrumentos de óptica',1,2,'2018-08-21 14:15:54',NULL),(1368,'Montador de instrumentos de precisão',1,2,'2018-08-21 14:15:54',NULL),(1369,'Montador de máquinas',1,2,'2018-08-21 14:15:54',NULL),(1370,'Montador de máquinas agrícolas',1,2,'2018-08-21 14:15:54',NULL),(1371,'Montador de máquinas de minas e pedreiras',1,2,'2018-08-21 14:15:54',NULL),(1372,'Montador de máquinas de terraplenagem',1,2,'2018-08-21 14:15:54',NULL),(1373,'Montador de máquinas gráficas',1,2,'2018-08-21 14:15:54',NULL),(1374,'Montador de máquinas operatrizes para madeira',1,2,'2018-08-21 14:15:54',NULL),(1375,'Montador de máquinas têxteis',1,2,'2018-08-21 14:15:54',NULL),(1376,'Montador de máquinas, motores e acessórios (montagem em série)',1,2,'2018-08-21 14:15:54',NULL),(1377,'Montador de máquinas-ferramentas (usinagem de metais)',1,2,'2018-08-21 14:15:54',NULL),(1378,'Montador de móveis e artefatos de madeira',1,2,'2018-08-21 14:15:54',NULL),(1379,'Montador de sistemas de combustível de aeronaves',1,2,'2018-08-21 14:15:54',NULL),(1380,'Montador de veículos (linha de montagem)',1,2,'2018-08-21 14:15:54',NULL),(1381,'Montador de veículos (reparação)',1,2,'2018-08-21 14:15:54',NULL),(1382,'Mordomo de hotelaria',1,2,'2018-08-21 14:15:54',NULL),(1383,'Mordomo de residência',1,2,'2018-08-21 14:15:54',NULL),(1384,'Mosaísta',1,2,'2018-08-21 14:15:54',NULL),(1385,'Motofretista',1,2,'2018-08-21 14:15:54',NULL),(1386,'Motorista de caminhão (rotas regionais e internacionais)',1,2,'2018-08-21 14:15:54',NULL),(1387,'Motorista de carro de passeio',1,2,'2018-08-21 14:15:54',NULL),(1388,'Motorista de furgão ou veículo similar',1,2,'2018-08-21 14:15:54',NULL),(1389,'Motorista de ônibus rodoviário',1,2,'2018-08-21 14:15:54',NULL),(1390,'Motorista de ônibus urbano',1,2,'2018-08-21 14:15:54',NULL),(1391,'Motorista de táxi',1,2,'2018-08-21 14:15:54',NULL),(1392,'Motorista de trólebus',1,2,'2018-08-21 14:15:54',NULL),(1393,'Motorista operacional de guincho',1,2,'2018-08-21 14:15:54',NULL),(1394,'Motorneiro',1,2,'2018-08-21 14:15:54',NULL),(1395,'Mototaxista',1,2,'2018-08-21 14:15:54',NULL),(1396,'Museólogo',1,2,'2018-08-21 14:15:54',NULL),(1397,'Músico arranjador',1,2,'2018-08-21 14:15:54',NULL),(1398,'Músico intérprete cantor',1,2,'2018-08-21 14:15:54',NULL),(1399,'Músico intérprete instrumentista',1,2,'2018-08-21 14:15:54',NULL),(1400,'Músico regente',1,2,'2018-08-21 14:15:54',NULL),(1401,'Musicólogo',1,2,'2018-08-21 14:15:54',NULL),(1402,'Musicoterapeuta',1,2,'2018-08-21 14:15:54',NULL),(1403,'Narrador em programas de rádio e televisão',1,2,'2018-08-21 14:15:54',NULL),(1404,'Naturólogo',1,2,'2018-08-21 14:15:54',NULL),(1405,'Neuropsicólogo',1,2,'2018-08-21 14:15:54',NULL),(1406,'Normalizador de metais e de compósitos',1,2,'2018-08-21 14:15:54',NULL),(1407,'Numerólogo',1,2,'2018-08-21 14:15:54',NULL),(1408,'Nutricionista',1,2,'2018-08-21 14:15:54',NULL),(1409,'Oceanógrafo',1,2,'2018-08-21 14:15:54',NULL),(1410,'Oficial da aeronáutica',1,2,'2018-08-21 14:15:54',NULL),(1411,'Oficial da marinha',1,2,'2018-08-21 14:15:54',NULL),(1412,'Oficial de inteligência',1,2,'2018-08-21 14:15:54',NULL),(1413,'Oficial de justiça',1,2,'2018-08-21 14:15:54',NULL),(1414,'Oficial de quarto de navegação da marinha mercante',1,2,'2018-08-21 14:15:54',NULL),(1415,'Oficial de registro de contratos marítimos',1,2,'2018-08-21 14:15:54',NULL),(1416,'Oficial do exército',1,2,'2018-08-21 14:15:54',NULL),(1417,'Oficial do registro civil de pessoas jurídicas',1,2,'2018-08-21 14:15:54',NULL),(1418,'Oficial do registro civil de pessoas naturais',1,2,'2018-08-21 14:15:54',NULL),(1419,'Oficial do registro de distribuições',1,2,'2018-08-21 14:15:54',NULL),(1420,'Oficial do registro de imóveis',1,2,'2018-08-21 14:15:54',NULL),(1421,'Oficial do registro de títulos e documentos',1,2,'2018-08-21 14:15:54',NULL),(1422,'Oficial general da aeronáutica',1,2,'2018-08-21 14:15:54',NULL),(1423,'Oficial general da marinha',1,2,'2018-08-21 14:15:54',NULL),(1424,'Oficial general do exército',1,2,'2018-08-21 14:15:54',NULL),(1425,'Oficial superior de máquinas da marinha mercante',1,2,'2018-08-21 14:15:54',NULL),(1426,'Oficial técnico de inteligência',1,2,'2018-08-21 14:15:54',NULL),(1427,'Oleiro (fabricação de telhas)',1,2,'2018-08-21 14:15:54',NULL),(1428,'Oleiro (fabricação de tijolos)',1,2,'2018-08-21 14:15:54',NULL),(1429,'Operador de abastecimento de combustível de aeronave',1,2,'2018-08-21 14:15:54',NULL),(1430,'Operador de abertura (fiação)',1,2,'2018-08-21 14:15:54',NULL),(1431,'Operador de acabamento (indústria gráfica)',1,2,'2018-08-21 14:15:54',NULL),(1432,'Operador de acabamento de peças fundidas',1,2,'2018-08-21 14:15:54',NULL),(1433,'Operador de aciaria (basculamento de convertedor)',1,2,'2018-08-21 14:15:54',NULL),(1434,'Operador de aciaria (dessulfuração de gusa)',1,2,'2018-08-21 14:15:54',NULL),(1435,'Operador de aciaria (recebimento de gusa)',1,2,'2018-08-21 14:15:54',NULL),(1436,'Operador de alambique de funcionamento contínuo (produtos químicos, exceto petróleo)',1,2,'2018-08-21 14:15:54',NULL),(1437,'Operador de aparelho de flotação',1,2,'2018-08-21 14:15:54',NULL),(1438,'Operador de aparelho de precipitação (minas de ouro ou prata)',1,2,'2018-08-21 14:15:54',NULL),(1439,'Operador de aparelho de reação e conversão (produtos químicos, exceto petróleo)',1,2,'2018-08-21 14:15:54',NULL),(1440,'Operador de área de corrida',1,2,'2018-08-21 14:15:54',NULL),(1441,'Operador de atendimento aeroviário',1,2,'2018-08-21 14:15:54',NULL),(1442,'Operador de atomizador',1,2,'2018-08-21 14:15:54',NULL),(1443,'Operador de áudio de continuidade (rádio)',1,2,'2018-08-21 14:15:54',NULL),(1444,'Operador de banho metálico de vidro por flutuação',1,2,'2018-08-21 14:15:54',NULL),(1445,'Operador de bate-estacas',1,2,'2018-08-21 14:15:54',NULL),(1446,'Operador de bateria de gás de hulha',1,2,'2018-08-21 14:15:54',NULL),(1447,'Operador de betoneira',1,2,'2018-08-21 14:15:54',NULL),(1448,'Operador de binadeira',1,2,'2018-08-21 14:15:54',NULL),(1449,'Operador de bobinadeira',1,2,'2018-08-21 14:15:54',NULL),(1450,'Operador de bobinadeira de tiras a quente, no acabamento de chapas e metais',1,2,'2018-08-21 14:15:54',NULL),(1451,'Operador de bomba de concreto',1,2,'2018-08-21 14:15:54',NULL),(1452,'Operador de branqueador de pasta para fabricação de papel',1,2,'2018-08-21 14:15:54',NULL),(1453,'Operador de britadeira (tratamentos químicos e afins)',1,2,'2018-08-21 14:15:54',NULL),(1454,'Operador de britador de coque',1,2,'2018-08-21 14:15:54',NULL),(1455,'Operador de britador de mandíbulas',1,2,'2018-08-21 14:15:54',NULL),(1456,'Operador de cabine de laminação (fio-máquina)',1,2,'2018-08-21 14:15:54',NULL),(1457,'Operador de caixa',1,2,'2018-08-21 14:15:54',NULL),(1458,'Operador de calandra (química, petroquímica e afins)',1,2,'2018-08-21 14:15:54',NULL),(1459,'Operador de calandras (tecidos)',1,2,'2018-08-21 14:15:54',NULL),(1460,'Operador de calcinação (tratamento químico e afins)',1,2,'2018-08-21 14:15:54',NULL),(1461,'Operador de caldeira',1,2,'2018-08-21 14:15:54',NULL),(1462,'Operador de câmaras frias',1,2,'2018-08-21 14:15:54',NULL),(1463,'Operador de câmera de televisão',1,2,'2018-08-21 14:15:54',NULL),(1464,'Operador de caminhão (minas e pedreiras)',1,2,'2018-08-21 14:15:54',NULL),(1465,'Operador de cardas',1,2,'2018-08-21 14:15:54',NULL),(1466,'Operador de carregadeira',1,2,'2018-08-21 14:15:54',NULL),(1467,'Operador de carro de apagamento e coque',1,2,'2018-08-21 14:15:54',NULL),(1468,'Operador de ceifadeira na conservação de vias permanentes',1,2,'2018-08-21 14:15:54',NULL),(1469,'Operador de central de concreto',1,2,'2018-08-21 14:15:54',NULL),(1470,'Operador de central de rádio',1,2,'2018-08-21 14:15:54',NULL),(1471,'Operador de central hidrelétrica',1,2,'2018-08-21 14:15:54',NULL),(1472,'Operador de central termoelétrica',1,2,'2018-08-21 14:15:54',NULL),(1473,'Operador de centrifugadora (tratamentos químicos e afins)',1,2,'2018-08-21 14:15:54',NULL),(1474,'Operador de centro de controle',1,2,'2018-08-21 14:15:54',NULL),(1475,'Operador de centro de controle (ferrovia e metrô)',1,2,'2018-08-21 14:15:54',NULL),(1476,'Operador de centro de usinagem com comando numérico',1,2,'2018-08-21 14:15:54',NULL),(1477,'Operador de centro de usinagem de madeira (cnc)',1,2,'2018-08-21 14:15:54',NULL),(1478,'Operador de chamuscadeira de tecidos',1,2,'2018-08-21 14:15:54',NULL),(1479,'Operador de cobrança bancária',1,2,'2018-08-21 14:15:54',NULL),(1480,'Operador de colhedor florestal',1,2,'2018-08-21 14:15:54',NULL),(1481,'Operador de colheitadeira',1,2,'2018-08-21 14:15:54',NULL),(1482,'Operador de compactadora de solos',1,2,'2018-08-21 14:15:54',NULL),(1483,'Operador de compressor de ar',1,2,'2018-08-21 14:15:54',NULL),(1484,'Operador de computador (inclusive microcomputador)',1,2,'2018-08-21 14:15:54',NULL),(1485,'Operador de concentração',1,2,'2018-08-21 14:15:54',NULL),(1486,'Operador de conicaleira',1,2,'2018-08-21 14:15:54',NULL),(1487,'Operador de cortadeira de papel',1,2,'2018-08-21 14:15:54',NULL),(1488,'Operador de cristalização na refinação de açucar',1,2,'2018-08-21 14:15:54',NULL),(1489,'Operador de desempenadeira na usinagem convencional de madeira',1,2,'2018-08-21 14:15:54',NULL),(1490,'Operador de desgaseificação',1,2,'2018-08-21 14:15:54',NULL),(1491,'Operador de destilação e subprodutos de coque',1,2,'2018-08-21 14:15:54',NULL),(1492,'Operador de digestor de pasta para fabricação de papel',1,2,'2018-08-21 14:15:54',NULL),(1493,'Operador de docagem',1,2,'2018-08-21 14:15:54',NULL),(1494,'Operador de draga',1,2,'2018-08-21 14:15:54',NULL),(1495,'Operador de empilhadeira',1,2,'2018-08-21 14:15:54',NULL),(1496,'Operador de enfornamento e desenfornamento de coque',1,2,'2018-08-21 14:15:54',NULL),(1497,'Operador de engomadeira de urdume',1,2,'2018-08-21 14:15:54',NULL),(1498,'Operador de entalhadeira (usinagem de madeira)',1,2,'2018-08-21 14:15:54',NULL),(1499,'Operador de equipamento de destilação de álcool',1,2,'2018-08-21 14:15:54',NULL),(1500,'Operador de equipamento de secagem de pintura',1,2,'2018-08-21 14:15:54',NULL),(1501,'Operador de equipamento para resfriamento',1,2,'2018-08-21 14:15:54',NULL),(1502,'Operador de equipamentos de preparação de areia',1,2,'2018-08-21 14:15:54',NULL),(1503,'Operador de equipamentos de refinação de açúcar (processo contínuo)',1,2,'2018-08-21 14:15:54',NULL),(1504,'Operador de escavadeira',1,2,'2018-08-21 14:15:54',NULL),(1505,'Operador de escória e sucata',1,2,'2018-08-21 14:15:54',NULL),(1506,'Operador de esmaltadeira',1,2,'2018-08-21 14:15:54',NULL),(1507,'Operador de espelhamento',1,2,'2018-08-21 14:15:54',NULL),(1508,'Operador de espessador',1,2,'2018-08-21 14:15:54',NULL),(1509,'Operador de espuladeira',1,2,'2018-08-21 14:15:54',NULL),(1510,'Operador de estação de bombeamento',1,2,'2018-08-21 14:15:54',NULL),(1511,'Operador de estação de captação, tratamento e distribuição de água',1,2,'2018-08-21 14:15:54',NULL),(1512,'Operador de estação de tratamento de água e efluentes',1,2,'2018-08-21 14:15:54',NULL),(1513,'Operador de evaporador na destilação',1,2,'2018-08-21 14:15:54',NULL),(1514,'Operador de exaustor (coqueria)',1,2,'2018-08-21 14:15:54',NULL),(1515,'Operador de exploração de petróleo',1,2,'2018-08-21 14:15:54',NULL),(1516,'Operador de externa (rádio)',1,2,'2018-08-21 14:15:54',NULL),(1517,'Operador de extração de café solúvel',1,2,'2018-08-21 14:15:54',NULL),(1518,'Operador de extrusora (química, petroquímica e afins)',1,2,'2018-08-21 14:15:54',NULL),(1519,'Operador de filatório',1,2,'2018-08-21 14:15:54',NULL),(1520,'Operador de filtro de secagem (mineração)',1,2,'2018-08-21 14:15:54',NULL),(1521,'Operador de filtro de tambor rotativo (tratamentos químicos e afins)',1,2,'2018-08-21 14:15:54',NULL),(1522,'Operador de filtro-esteira (mineração)',1,2,'2018-08-21 14:15:54',NULL),(1523,'Operador de filtro-prensa (tratamentos químicos e afins)',1,2,'2018-08-21 14:15:54',NULL),(1524,'Operador de filtros de parafina (tratamentos químicos e afins)',1,2,'2018-08-21 14:15:54',NULL),(1525,'Operador de forno (fabricação de pães, biscoitos e similares)',1,2,'2018-08-21 14:15:54',NULL),(1526,'Operador de forno (serviços funerários)',1,2,'2018-08-21 14:15:54',NULL),(1527,'Operador de forno de incineração no tratamento de água, efluentes e resíduos industriais',1,2,'2018-08-21 14:15:54',NULL),(1528,'Operador de forno de tratamento térmico de metais',1,2,'2018-08-21 14:15:54',NULL),(1529,'Operador de fresadora (usinagem de madeira)',1,2,'2018-08-21 14:15:54',NULL),(1530,'Operador de fresadora com comando numérico',1,2,'2018-08-21 14:15:54',NULL),(1531,'Operador de gravação de rádio',1,2,'2018-08-21 14:15:54',NULL),(1532,'Operador de guilhotina (corte de papel)',1,2,'2018-08-21 14:15:54',NULL),(1533,'Operador de guindaste (fixo)',1,2,'2018-08-21 14:15:54',NULL),(1534,'Operador de guindaste móvel',1,2,'2018-08-21 14:15:54',NULL),(1535,'Operador de impermeabilizador de tecidos',1,2,'2018-08-21 14:15:54',NULL),(1536,'Operador de incubadora',1,2,'2018-08-21 14:15:54',NULL),(1537,'Operador de inspeção de qualidade',1,2,'2018-08-21 14:15:54',NULL),(1538,'Operador de instalação de ar-condicionado',1,2,'2018-08-21 14:15:54',NULL),(1539,'Operador de instalação de extração, processamento, envasamento e distribuição de gases',1,2,'2018-08-21 14:15:54',NULL),(1540,'Operador de instalação de refrigeração',1,2,'2018-08-21 14:15:54',NULL),(1541,'Operador de jato abrasivo',1,2,'2018-08-21 14:15:54',NULL),(1542,'Operador de jig (minas)',1,2,'2018-08-21 14:15:54',NULL),(1543,'Operador de laços de cabos de aço',1,2,'2018-08-21 14:15:54',NULL),(1544,'Operador de laminadeira e reunideira',1,2,'2018-08-21 14:15:54',NULL),(1545,'Operador de laminador',1,2,'2018-08-21 14:15:54',NULL),(1546,'Operador de laminador de barras a frio',1,2,'2018-08-21 14:15:54',NULL),(1547,'Operador de laminador de barras a quente',1,2,'2018-08-21 14:15:54',NULL),(1548,'Operador de laminador de metais não-ferrosos',1,2,'2018-08-21 14:15:54',NULL),(1549,'Operador de laminador de tubos',1,2,'2018-08-21 14:15:54',NULL),(1550,'Operador de lavagem e depuração de pasta para fabricação de papel',1,2,'2018-08-21 14:15:54',NULL),(1551,'Operador de linha de montagem (aparelhos elétricos)',1,2,'2018-08-21 14:15:54',NULL),(1552,'Operador de linha de montagem (aparelhos eletrônicos)',1,2,'2018-08-21 14:15:54',NULL),(1553,'Operador de lixadeira (usinagem de madeira)',1,2,'2018-08-21 14:15:54',NULL),(1554,'Operador de maçaroqueira',1,2,'2018-08-21 14:15:54',NULL),(1555,'Operador de mandriladora com comando numérico',1,2,'2018-08-21 14:15:54',NULL),(1556,'Operador de máquina (fabricação de cigarros)',1,2,'2018-08-21 14:15:54',NULL),(1557,'Operador de máquina bordatriz',1,2,'2018-08-21 14:15:54',NULL),(1558,'Operador de máquina centrifugadora de fundição',1,2,'2018-08-21 14:15:54',NULL),(1559,'Operador de máquina copiadora (exceto operador de gráfica rápida)',1,2,'2018-08-21 14:15:54',NULL),(1560,'Operador de máquina cortadora (minas e pedreiras)',1,2,'2018-08-21 14:15:54',NULL),(1561,'Operador de máquina de abrir valas',1,2,'2018-08-21 14:15:54',NULL),(1562,'Operador de máquina de cilindrar chapas',1,2,'2018-08-21 14:15:54',NULL),(1563,'Operador de máquina de cordoalha',1,2,'2018-08-21 14:15:54',NULL),(1564,'Operador de máquina de cortar e dobrar papelão',1,2,'2018-08-21 14:15:54',NULL),(1565,'Operador de máquina de cortina d´água (produção de móveis)',1,2,'2018-08-21 14:15:54',NULL),(1566,'Operador de máquina de costura de acabamento',1,2,'2018-08-21 14:15:54',NULL),(1567,'Operador de máquina de dobrar chapas',1,2,'2018-08-21 14:15:54',NULL),(1568,'Operador de máquina de eletroerosão',1,2,'2018-08-21 14:15:54',NULL),(1569,'Operador de máquina de envasar líquidos',1,2,'2018-08-21 14:15:54',NULL),(1570,'Operador de máquina de etiquetar',1,2,'2018-08-21 14:15:54',NULL),(1571,'Operador de máquina de extração contínua (minas de carvão)',1,2,'2018-08-21 14:15:54',NULL),(1572,'Operador de máquina de fabricação de cosméticos',1,2,'2018-08-21 14:15:54',NULL),(1573,'Operador de máquina de fabricação de produtos de higiene e limpeza (sabão, sabonete, detergente, abs',1,2,'2018-08-21 14:15:54',NULL),(1574,'Operador de máquina de fabricar charutos e cigarrilhas',1,2,'2018-08-21 14:15:54',NULL),(1575,'Operador de máquina de fabricar papel  (fase úmida)',1,2,'2018-08-21 14:15:54',NULL),(1576,'Operador de máquina de fabricar papel (fase seca)',1,2,'2018-08-21 14:15:54',NULL),(1577,'Operador de máquina de fabricar papel e papelão',1,2,'2018-08-21 14:15:54',NULL),(1578,'Operador de máquina de fundir sob pressão',1,2,'2018-08-21 14:15:54',NULL),(1579,'Operador de máquina de lavar fios e tecidos',1,2,'2018-08-21 14:15:54',NULL),(1580,'Operador de máquina de moldar automatizada',1,2,'2018-08-21 14:15:54',NULL),(1581,'Operador de máquina de preparação de matéria prima para produção de cigarros',1,2,'2018-08-21 14:15:54',NULL),(1582,'Operador de máquina de produtos farmacêuticos',1,2,'2018-08-21 14:15:54',NULL),(1583,'Operador de máquina de secar celulose',1,2,'2018-08-21 14:15:54',NULL),(1584,'Operador de máquina de sinterizar',1,2,'2018-08-21 14:15:54',NULL),(1585,'Operador de máquina de soprar vidro',1,2,'2018-08-21 14:15:54',NULL),(1586,'Operador de máquina de usinagem de madeira (produção em série)',1,2,'2018-08-21 14:15:54',NULL),(1587,'Operador de máquina de usinagem madeira, em geral',1,2,'2018-08-21 14:15:54',NULL),(1588,'Operador de máquina eletroerosão, à fio, com comando numérico',1,2,'2018-08-21 14:15:54',NULL),(1589,'Operador de máquina extrusora de varetas e tubos de vidro',1,2,'2018-08-21 14:15:54',NULL),(1590,'Operador de máquina intercaladora e placas (compensados)',1,2,'2018-08-21 14:15:54',NULL),(1591,'Operador de máquina misturadeira (tratamentos químicos e afins)',1,2,'2018-08-21 14:15:54',NULL),(1592,'Operador de máquina perfuradora (minas e pedreiras)',1,2,'2018-08-21 14:15:54',NULL),(1593,'Operador de máquina perfuratriz',1,2,'2018-08-21 14:15:54',NULL),(1594,'Operador de máquina recobridora de arame',1,2,'2018-08-21 14:15:54',NULL),(1595,'Operador de máquina rodoferroviária',1,2,'2018-08-21 14:15:54',NULL),(1596,'Operador de máquinas de beneficiamento de produtos agrícolas',1,2,'2018-08-21 14:15:54',NULL),(1597,'Operador de máquinas de construção civil e mineração',1,2,'2018-08-21 14:15:54',NULL),(1598,'Operador de máquinas de fabricação de chocolates e achocolatados',1,2,'2018-08-21 14:15:54',NULL),(1599,'Operador de máquinas de fabricação de doces, salgados e massas alimentícias',1,2,'2018-08-21 14:15:54',NULL),(1600,'Operador de máquinas de usinar madeira (cnc)',1,2,'2018-08-21 14:15:54',NULL),(1601,'Operador de máquinas do acabamento de couros e peles',1,2,'2018-08-21 14:15:54',NULL),(1602,'Operador de máquinas especiais em conservação de via permanente (trilhos)',1,2,'2018-08-21 14:15:54',NULL),(1603,'Operador de máquinas fixas, em geral',1,2,'2018-08-21 14:15:54',NULL),(1604,'Operador de máquinas florestais estáticas',1,2,'2018-08-21 14:15:54',NULL),(1605,'Operador de máquinas operatrizes',1,2,'2018-08-21 14:15:54',NULL),(1606,'Operador de máquinas-ferramenta convencionais',1,2,'2018-08-21 14:15:54',NULL),(1607,'Operador de martelete',1,2,'2018-08-21 14:15:54',NULL),(1608,'Operador de mensagens de telecomunicações (correios)',1,2,'2018-08-21 14:15:54',NULL),(1609,'Operador de moenda na fabricação de açúcar',1,2,'2018-08-21 14:15:54',NULL),(1610,'Operador de molduradora (usinagem de madeira)',1,2,'2018-08-21 14:15:54',NULL),(1611,'Operador de monta-cargas (construção civil)',1,2,'2018-08-21 14:15:54',NULL),(1612,'Operador de montagem de cilindros e mancais',1,2,'2018-08-21 14:15:54',NULL),(1613,'Operador de motoniveladora',1,2,'2018-08-21 14:15:54',NULL),(1614,'Operador de motoniveladora (extração de minerais sólidos)',1,2,'2018-08-21 14:15:54',NULL),(1615,'Operador de motosserra',1,2,'2018-08-21 14:15:54',NULL),(1616,'Operador de negócios',1,2,'2018-08-21 14:15:54',NULL),(1617,'Operador de open-end',1,2,'2018-08-21 14:15:54',NULL),(1618,'Operador de pá carregadeira',1,2,'2018-08-21 14:15:54',NULL),(1619,'Operador de painel de controle',1,2,'2018-08-21 14:15:54',NULL),(1620,'Operador de painel de controle (refinação de petróleo)',1,2,'2018-08-21 14:15:54',NULL),(1621,'Operador de passador (fiação)',1,2,'2018-08-21 14:15:54',NULL),(1622,'Operador de pavimentadora (asfalto, concreto e materiais similares)',1,2,'2018-08-21 14:15:54',NULL),(1623,'Operador de peneiras hidráulicas',1,2,'2018-08-21 14:15:54',NULL),(1624,'Operador de penteadeira',1,2,'2018-08-21 14:15:54',NULL),(1625,'Operador de plaina desengrossadeira',1,2,'2018-08-21 14:15:54',NULL),(1626,'Operador de ponte rolante',1,2,'2018-08-21 14:15:54',NULL),(1627,'Operador de pórtico rolante',1,2,'2018-08-21 14:15:54',NULL),(1628,'Operador de prensa de alta freqüência na usinagem de madeira',1,2,'2018-08-21 14:15:54',NULL),(1629,'Operador de prensa de embutir papelão',1,2,'2018-08-21 14:15:54',NULL),(1630,'Operador de prensa de enfardamento',1,2,'2018-08-21 14:15:54',NULL),(1631,'Operador de prensa de material reciclável',1,2,'2018-08-21 14:15:54',NULL),(1632,'Operador de prensa de moldar vidro',1,2,'2018-08-21 14:15:54',NULL),(1633,'Operador de preparação de grãos vegetais (óleos e gorduras)',1,2,'2018-08-21 14:15:54',NULL),(1634,'Operador de preservação e controle térmico',1,2,'2018-08-21 14:15:54',NULL),(1635,'Operador de processo (química, petroquímica e afins)',1,2,'2018-08-21 14:15:54',NULL),(1636,'Operador de processo de moagem',1,2,'2018-08-21 14:15:54',NULL),(1637,'Operador de processo de tratamento de imagem',1,2,'2018-08-21 14:15:54',NULL),(1638,'Operador de processos químicos e petroquímicos',1,2,'2018-08-21 14:15:54',NULL),(1639,'Operador de produção (química, petroquímica e afins)',1,2,'2018-08-21 14:15:54',NULL),(1640,'Operador de projetor cinematográfico',1,2,'2018-08-21 14:15:54',NULL),(1641,'Operador de quadro de distribuição de energia elétrica',1,2,'2018-08-21 14:15:54',NULL),(1642,'Operador de rádio-chamada',1,2,'2018-08-21 14:15:54',NULL),(1643,'Operador de rameuse',1,2,'2018-08-21 14:15:54',NULL),(1644,'Operador de reator de coque de petróleo',1,2,'2018-08-21 14:15:54',NULL),(1645,'Operador de reator nuclear',1,2,'2018-08-21 14:15:54',NULL),(1646,'Operador de rebobinadeira na fabricação de papel e papelão',1,2,'2018-08-21 14:15:54',NULL),(1647,'Operador de rede de teleprocessamento',1,2,'2018-08-21 14:15:54',NULL),(1648,'Operador de refrigeração (coqueria)',1,2,'2018-08-21 14:15:54',NULL),(1649,'Operador de refrigeração com amônia',1,2,'2018-08-21 14:15:54',NULL),(1650,'Operador de retificadora com comando numérico',1,2,'2018-08-21 14:15:54',NULL),(1651,'Operador de retorcedeira',1,2,'2018-08-21 14:15:54',NULL),(1652,'Operador de sala de controle de instalações químicas, petroquímicas e afins',1,2,'2018-08-21 14:15:54',NULL),(1653,'Operador de salina (sal marinho)',1,2,'2018-08-21 14:15:54',NULL),(1654,'Operador de schutthecar',1,2,'2018-08-21 14:15:54',NULL),(1655,'Operador de serras (usinagem de madeira)',1,2,'2018-08-21 14:15:54',NULL),(1656,'Operador de serras no desdobramento de madeira',1,2,'2018-08-21 14:15:54',NULL),(1657,'Operador de sistema de reversão (coqueria)',1,2,'2018-08-21 14:15:54',NULL),(1658,'Operador de sistemas de prova (analógico e digital)',1,2,'2018-08-21 14:15:54',NULL),(1659,'Operador de sonda de percussão',1,2,'2018-08-21 14:15:54',NULL),(1660,'Operador de sonda rotativa',1,2,'2018-08-21 14:15:54',NULL),(1661,'Operador de subestação',1,2,'2018-08-21 14:15:54',NULL),(1662,'Operador de talha elétrica',1,2,'2018-08-21 14:15:54',NULL),(1663,'Operador de teleférico (passageiros)',1,2,'2018-08-21 14:15:54',NULL),(1664,'Operador de telemarketing ativo',1,2,'2018-08-21 14:15:54',NULL),(1665,'Operador de telemarketing ativo e receptivo',1,2,'2018-08-21 14:15:54',NULL),(1666,'Operador de telemarketing receptivo',1,2,'2018-08-21 14:15:54',NULL),(1667,'Operador de telemarketing técnico',1,2,'2018-08-21 14:15:54',NULL),(1668,'Operador de tesoura mecânica e máquina de corte, no acabamento de chapas e metais',1,2,'2018-08-21 14:15:54',NULL),(1669,'Operador de time de montagem',1,2,'2018-08-21 14:15:54',NULL),(1670,'Operador de torno automático (usinagem de madeira)',1,2,'2018-08-21 14:15:54',NULL),(1671,'Operador de torno com comando numérico',1,2,'2018-08-21 14:15:54',NULL),(1672,'Operador de transferência e estocagem - na refinação do petróleo',1,2,'2018-08-21 14:15:54',NULL),(1673,'Operador de transmissor de rádio',1,2,'2018-08-21 14:15:54',NULL),(1674,'Operador de transporte multimodal',1,2,'2018-08-21 14:15:54',NULL),(1675,'Operador de tratamento de calda na refinação de açúcar',1,2,'2018-08-21 14:15:54',NULL),(1676,'Operador de tratamento químico de materiais radioativos',1,2,'2018-08-21 14:15:54',NULL),(1677,'Operador de trator (minas e pedreiras)',1,2,'2018-08-21 14:15:54',NULL),(1678,'Operador de trator de lâmina',1,2,'2018-08-21 14:15:54',NULL),(1679,'Operador de trator florestal',1,2,'2018-08-21 14:15:54',NULL),(1680,'Operador de trem de metrô',1,2,'2018-08-21 14:15:54',NULL),(1681,'Operador de triagem e transbordo',1,2,'2018-08-21 14:15:54',NULL),(1682,'Operador de tupia (usinagem de madeira)',1,2,'2018-08-21 14:15:54',NULL),(1683,'Operador de turismo',1,2,'2018-08-21 14:15:54',NULL),(1684,'Operador de urdideira',1,2,'2018-08-21 14:15:54',NULL),(1685,'Operador de usinagem convencional por abrasão',1,2,'2018-08-21 14:15:54',NULL),(1686,'Operador de utilidade (produção e distribuição de vapor, gás, óleo, combustível, energia, oxigênio)',1,2,'2018-08-21 14:15:54',NULL),(1687,'Operador de vazamento (lingotamento)',1,2,'2018-08-21 14:15:54',NULL),(1688,'Operador de veículos subaquáticos controlados remotamente',1,2,'2018-08-21 14:15:54',NULL),(1689,'Operador de zincagem (processo eletrolítico)',1,2,'2018-08-21 14:15:54',NULL),(1690,'Operador eletromecânico',1,2,'2018-08-21 14:15:54',NULL),(1691,'Operador polivalente da indústria têxtil',1,2,'2018-08-21 14:15:54',NULL),(1692,'Operador-mantenedor de projetor cinematográfico',1,2,'2018-08-21 14:15:54',NULL),(1693,'Organizador de evento',1,2,'2018-08-21 14:15:54',NULL),(1694,'Orientador educacional',1,2,'2018-08-21 14:15:54',NULL),(1695,'Ortoptista',1,2,'2018-08-21 14:15:54',NULL),(1696,'Osteopata',1,2,'2018-08-21 14:15:54',NULL),(1697,'Ourives',1,2,'2018-08-21 14:15:54',NULL),(1698,'Ouvidor',1,2,'2018-08-21 14:15:54',NULL),(1699,'Oxicortador a mão e a  máquina',1,2,'2018-08-21 14:15:54',NULL),(1700,'Oxidador',1,2,'2018-08-21 14:15:54',NULL),(1701,'Padeiro',1,2,'2018-08-21 14:15:54',NULL),(1702,'Paginador',1,2,'2018-08-21 14:15:54',NULL),(1703,'Palecionador de couros e peles',1,2,'2018-08-21 14:15:54',NULL),(1704,'Paleontólogo',1,2,'2018-08-21 14:15:54',NULL),(1705,'Palhaço',1,2,'2018-08-21 14:15:54',NULL),(1706,'Papiloscopista policial',1,2,'2018-08-21 14:15:54',NULL),(1707,'Paranormal',1,2,'2018-08-21 14:15:54',NULL),(1708,'Parteira leiga',1,2,'2018-08-21 14:15:54',NULL),(1709,'Passadeira de peças confeccionadas',1,2,'2018-08-21 14:15:54',NULL),(1710,'Passador de roupas em geral',1,2,'2018-08-21 14:15:54',NULL),(1711,'Passador de roupas, à mão',1,2,'2018-08-21 14:15:54',NULL),(1712,'Passamaneiro a  máquina',1,2,'2018-08-21 14:15:54',NULL),(1713,'Pasteurizador',1,2,'2018-08-21 14:15:54',NULL),(1714,'Pastilheiro',1,2,'2018-08-21 14:15:54',NULL),(1715,'Patrão de pesca de alto-mar',1,2,'2018-08-21 14:15:54',NULL),(1716,'Patrão de pesca na navegação interior',1,2,'2018-08-21 14:15:54',NULL),(1717,'Pedagogo',1,2,'2018-08-21 14:15:54',NULL),(1718,'Pedicure',1,2,'2018-08-21 14:15:54',NULL),(1719,'Pedreiro',1,2,'2018-08-21 14:15:54',NULL),(1720,'Pedreiro (chaminés industriais)',1,2,'2018-08-21 14:15:54',NULL),(1721,'Pedreiro (material refratário)',1,2,'2018-08-21 14:15:54',NULL),(1722,'Pedreiro (mineração)',1,2,'2018-08-21 14:15:54',NULL),(1723,'Pedreiro de conservação de vias permanentes (exceto trilhos)',1,2,'2018-08-21 14:15:54',NULL),(1724,'Pedreiro de edificações',1,2,'2018-08-21 14:15:54',NULL),(1725,'Perfumista',1,2,'2018-08-21 14:15:54',NULL),(1726,'Perfusionista',1,2,'2018-08-21 14:15:54',NULL),(1727,'Perito contábil',1,2,'2018-08-21 14:15:54',NULL),(1728,'Perito criminal',1,2,'2018-08-21 14:15:54',NULL),(1729,'Pescador artesanal de água doce',1,2,'2018-08-21 14:15:54',NULL),(1730,'Pescador artesanal de lagostas',1,2,'2018-08-21 14:15:54',NULL),(1731,'Pescador artesanal de peixes e camarões',1,2,'2018-08-21 14:15:54',NULL),(1732,'Pescador industrial',1,2,'2018-08-21 14:15:54',NULL),(1733,'Pescador profissional',1,2,'2018-08-21 14:15:54',NULL),(1734,'Pesquisador de clínica médica',1,2,'2018-08-21 14:15:54',NULL),(1735,'Pesquisador de engenharia civil',1,2,'2018-08-21 14:15:54',NULL),(1736,'Pesquisador de engenharia e tecnologia (outras áreas da engenharia)',1,2,'2018-08-21 14:15:54',NULL),(1737,'Pesquisador de engenharia elétrica e eletrônica',1,2,'2018-08-21 14:15:54',NULL),(1738,'Pesquisador de engenharia mecânica',1,2,'2018-08-21 14:15:54',NULL),(1739,'Pesquisador de engenharia metalúrgica, de minas e de materiais',1,2,'2018-08-21 14:15:54',NULL),(1740,'Pesquisador de engenharia química',1,2,'2018-08-21 14:15:54',NULL),(1741,'Pesquisador de medicina básica',1,2,'2018-08-21 14:15:54',NULL),(1742,'Pesquisador em biologia ambiental',1,2,'2018-08-21 14:15:54',NULL),(1743,'Pesquisador em biologia animal',1,2,'2018-08-21 14:15:54',NULL),(1744,'Pesquisador em biologia de microorganismos e parasitas',1,2,'2018-08-21 14:15:54',NULL),(1745,'Pesquisador em biologia humana',1,2,'2018-08-21 14:15:54',NULL),(1746,'Pesquisador em biologia vegetal',1,2,'2018-08-21 14:15:54',NULL),(1747,'Pesquisador em ciências agronômicas',1,2,'2018-08-21 14:15:54',NULL),(1748,'Pesquisador em ciências da computação e informática',1,2,'2018-08-21 14:15:54',NULL),(1749,'Pesquisador em ciências da educação',1,2,'2018-08-21 14:15:54',NULL),(1750,'Pesquisador em ciências da pesca e aqüicultura',1,2,'2018-08-21 14:15:54',NULL),(1751,'Pesquisador em ciências da terra e meio ambiente',1,2,'2018-08-21 14:15:54',NULL),(1752,'Pesquisador em ciências da zootecnia',1,2,'2018-08-21 14:15:54',NULL),(1753,'Pesquisador em ciências florestais',1,2,'2018-08-21 14:15:54',NULL),(1754,'Pesquisador em ciências sociais e humanas',1,2,'2018-08-21 14:15:54',NULL),(1755,'Pesquisador em economia',1,2,'2018-08-21 14:15:54',NULL),(1756,'Pesquisador em física',1,2,'2018-08-21 14:15:54',NULL),(1757,'Pesquisador em história',1,2,'2018-08-21 14:15:54',NULL),(1758,'Pesquisador em matemática',1,2,'2018-08-21 14:15:54',NULL),(1759,'Pesquisador em medicina veterinária',1,2,'2018-08-21 14:15:54',NULL),(1760,'Pesquisador em metrologia',1,2,'2018-08-21 14:15:54',NULL),(1761,'Pesquisador em psicologia',1,2,'2018-08-21 14:15:54',NULL),(1762,'Pesquisador em química',1,2,'2018-08-21 14:15:54',NULL),(1763,'Pesquisador em saúde coletiva',1,2,'2018-08-21 14:15:54',NULL),(1764,'Petrógrafo',1,2,'2018-08-21 14:15:54',NULL),(1765,'Picotador de cartões jacquard',1,2,'2018-08-21 14:15:54',NULL),(1766,'Piloto agrícola',1,2,'2018-08-21 14:15:54',NULL),(1767,'Piloto comercial (exceto linhas aéreas)',1,2,'2018-08-21 14:15:54',NULL),(1768,'Piloto comercial de helicóptero (exceto linhas aéreas)',1,2,'2018-08-21 14:15:54',NULL),(1769,'Piloto de aeronaves',1,2,'2018-08-21 14:15:54',NULL),(1770,'Piloto de competição automobilística',1,2,'2018-08-21 14:15:54',NULL),(1771,'Piloto de ensaios em vôo',1,2,'2018-08-21 14:15:54',NULL),(1772,'Piloto fluvial',1,2,'2018-08-21 14:15:54',NULL),(1773,'Pintor a pincel e rolo (exceto obras e estruturas metálicas)',1,2,'2018-08-21 14:15:54',NULL),(1774,'Pintor de cerâmica, a  pincel',1,2,'2018-08-21 14:15:54',NULL),(1775,'Pintor de estruturas metálicas',1,2,'2018-08-21 14:15:54',NULL),(1776,'Pintor de letreiros',1,2,'2018-08-21 14:15:54',NULL),(1777,'Pintor de obras',1,2,'2018-08-21 14:15:54',NULL),(1778,'Pintor de veículos (fabricação)',1,2,'2018-08-21 14:15:54',NULL),(1779,'Pintor de veículos (reparação)',1,2,'2018-08-21 14:15:54',NULL),(1780,'Pintor por imersão',1,2,'2018-08-21 14:15:54',NULL),(1781,'Pintor, a  pistola (exceto obras e estruturas metálicas)',1,2,'2018-08-21 14:15:54',NULL),(1782,'Pipoqueiro ambulante',1,2,'2018-08-21 14:15:54',NULL),(1783,'Pirotécnico',1,2,'2018-08-21 14:15:54',NULL),(1784,'Pizzaiolo',1,2,'2018-08-21 14:15:54',NULL),(1785,'Planejista',1,2,'2018-08-21 14:15:54',NULL),(1786,'Plataformista (petróleo)',1,2,'2018-08-21 14:15:54',NULL),(1787,'Poceiro (edificações)',1,2,'2018-08-21 14:15:54',NULL),(1788,'Podólogo',1,2,'2018-08-21 14:15:54',NULL),(1789,'Poeta',1,2,'2018-08-21 14:15:54',NULL),(1790,'Policial rodoviário federal',1,2,'2018-08-21 14:15:54',NULL),(1791,'Polidor de metais',1,2,'2018-08-21 14:15:54',NULL),(1792,'Polidor de pedras',1,2,'2018-08-21 14:15:54',NULL),(1793,'Porteiro (hotel)',1,2,'2018-08-21 14:15:54',NULL),(1794,'Porteiro de edifícios',1,2,'2018-08-21 14:15:54',NULL),(1795,'Porteiro de locais de diversão',1,2,'2018-08-21 14:15:54',NULL),(1796,'Praça da aeronáutica',1,2,'2018-08-21 14:15:54',NULL),(1797,'Praça da marinha',1,2,'2018-08-21 14:15:54',NULL),(1798,'Praça do exército',1,2,'2018-08-21 14:15:54',NULL),(1799,'Prático de portos da marinha mercante',1,2,'2018-08-21 14:15:54',NULL),(1800,'Prefeito',1,2,'2018-08-21 14:15:54',NULL),(1801,'Prensador de couros e peles',1,2,'2018-08-21 14:15:54',NULL),(1802,'Prensador de frutas (exceto oleaginosas)',1,2,'2018-08-21 14:15:54',NULL),(1803,'Prensista (operador de prensa)',1,2,'2018-08-21 14:15:54',NULL),(1804,'Prensista de aglomerados',1,2,'2018-08-21 14:15:54',NULL),(1805,'Prensista de compensados',1,2,'2018-08-21 14:15:54',NULL),(1806,'Preparador de aditivos',1,2,'2018-08-21 14:15:54',NULL),(1807,'Preparador de aglomerantes',1,2,'2018-08-21 14:15:54',NULL),(1808,'Preparador de atleta',1,2,'2018-08-21 14:15:54',NULL),(1809,'Preparador de barbotina',1,2,'2018-08-21 14:15:54',NULL),(1810,'Preparador de calçados',1,2,'2018-08-21 14:15:54',NULL),(1811,'Preparador de couros curtidos',1,2,'2018-08-21 14:15:54',NULL),(1812,'Preparador de esmaltes (cerâmica)',1,2,'2018-08-21 14:15:54',NULL),(1813,'Preparador de estruturas metálicas',1,2,'2018-08-21 14:15:54',NULL),(1814,'Preparador de fumo na fabricação de charutos',1,2,'2018-08-21 14:15:54',NULL),(1815,'Preparador de máquinas-ferramenta',1,2,'2018-08-21 14:15:54',NULL),(1816,'Preparador de massa (fabricação de abrasivos)',1,2,'2018-08-21 14:15:54',NULL),(1817,'Preparador de massa (fabricação de vidro)',1,2,'2018-08-21 14:15:54',NULL),(1818,'Preparador de massa de argila',1,2,'2018-08-21 14:15:54',NULL),(1819,'Preparador de matrizes de corte e vinco',1,2,'2018-08-21 14:15:54',NULL),(1820,'Preparador de melado e essência de fumo',1,2,'2018-08-21 14:15:54',NULL),(1821,'Preparador de panelas (lingotamento)',1,2,'2018-08-21 14:15:54',NULL),(1822,'Preparador de rações',1,2,'2018-08-21 14:15:54',NULL),(1823,'Preparador de solas e palmilhas',1,2,'2018-08-21 14:15:54',NULL),(1824,'Preparador de sucata e aparas',1,2,'2018-08-21 14:15:54',NULL),(1825,'Preparador de tintas',1,2,'2018-08-21 14:15:54',NULL),(1826,'Preparador de tintas (fábrica de tecidos)',1,2,'2018-08-21 14:15:54',NULL),(1827,'Preparador físico',1,2,'2018-08-21 14:15:54',NULL),(1828,'Presidente da república',1,2,'2018-08-21 14:15:54',NULL),(1829,'Primeiro oficial de máquinas da marinha mercante',1,2,'2018-08-21 14:15:54',NULL),(1830,'Primeiro tenente de polícia militar',1,2,'2018-08-21 14:15:54',NULL),(1831,'Processador de fumo',1,2,'2018-08-21 14:15:54',NULL),(1832,'Procurador autárquico',1,2,'2018-08-21 14:15:54',NULL),(1833,'Procurador da assistência judiciária',1,2,'2018-08-21 14:15:54',NULL),(1834,'Procurador da fazenda nacional',1,2,'2018-08-21 14:15:54',NULL),(1835,'Procurador da república',1,2,'2018-08-21 14:15:54',NULL),(1836,'Procurador de justiça',1,2,'2018-08-21 14:15:54',NULL),(1837,'Procurador de justiça militar',1,2,'2018-08-21 14:15:54',NULL),(1838,'Procurador do estado',1,2,'2018-08-21 14:15:54',NULL),(1839,'Procurador do município',1,2,'2018-08-21 14:15:54',NULL),(1840,'Procurador do trabalho',1,2,'2018-08-21 14:15:54',NULL),(1841,'Procurador federal',1,2,'2018-08-21 14:15:54',NULL),(1842,'Procurador fundacional',1,2,'2018-08-21 14:15:54',NULL),(1843,'Procurador regional da república',1,2,'2018-08-21 14:15:54',NULL),(1844,'Procurador regional do trabalho',1,2,'2018-08-21 14:15:54',NULL),(1845,'Produtor agrícola polivalente',1,2,'2018-08-21 14:15:54',NULL),(1846,'Produtor agropecuário, em geral',1,2,'2018-08-21 14:15:54',NULL),(1847,'Produtor cinematográfico',1,2,'2018-08-21 14:15:54',NULL),(1848,'Produtor cultural',1,2,'2018-08-21 14:15:54',NULL),(1849,'Produtor da cultura de amendoim',1,2,'2018-08-21 14:15:54',NULL),(1850,'Produtor da cultura de canola',1,2,'2018-08-21 14:15:54',NULL),(1851,'Produtor da cultura de coco-da-baia',1,2,'2018-08-21 14:15:54',NULL),(1852,'Produtor da cultura de dendê',1,2,'2018-08-21 14:15:54',NULL),(1853,'Produtor da cultura de girassol',1,2,'2018-08-21 14:15:54',NULL),(1854,'Produtor da cultura de linho',1,2,'2018-08-21 14:15:54',NULL),(1855,'Produtor da cultura de mamona',1,2,'2018-08-21 14:15:54',NULL),(1856,'Produtor da cultura de soja',1,2,'2018-08-21 14:15:54',NULL),(1857,'Produtor de algodão',1,2,'2018-08-21 14:15:54',NULL),(1858,'Produtor de arroz',1,2,'2018-08-21 14:15:54',NULL),(1859,'Produtor de árvores frutíferas',1,2,'2018-08-21 14:15:54',NULL),(1860,'Produtor de cacau',1,2,'2018-08-21 14:15:54',NULL),(1861,'Produtor de cana-de-açúcar',1,2,'2018-08-21 14:15:54',NULL),(1862,'Produtor de cereais de inverno',1,2,'2018-08-21 14:15:54',NULL),(1863,'Produtor de curauá',1,2,'2018-08-21 14:15:54',NULL),(1864,'Produtor de erva-mate',1,2,'2018-08-21 14:15:54',NULL),(1865,'Produtor de especiarias',1,2,'2018-08-21 14:15:54',NULL),(1866,'Produtor de espécies frutíferas rasteiras',1,2,'2018-08-21 14:15:54',NULL),(1867,'Produtor de espécies frutíferas trepadeiras',1,2,'2018-08-21 14:15:54',NULL),(1868,'Produtor de flores de corte',1,2,'2018-08-21 14:15:54',NULL),(1869,'Produtor de flores em vaso',1,2,'2018-08-21 14:15:54',NULL),(1870,'Produtor de forrações',1,2,'2018-08-21 14:15:54',NULL),(1871,'Produtor de fumo',1,2,'2018-08-21 14:15:54',NULL),(1872,'Produtor de gramíneas forrageiras',1,2,'2018-08-21 14:15:54',NULL),(1873,'Produtor de guaraná',1,2,'2018-08-21 14:15:54',NULL),(1874,'Produtor de juta',1,2,'2018-08-21 14:15:54',NULL),(1875,'Produtor de milho e sorgo',1,2,'2018-08-21 14:15:54',NULL),(1876,'Produtor de plantas aromáticas e medicinais',1,2,'2018-08-21 14:15:54',NULL),(1877,'Produtor de plantas ornamentais',1,2,'2018-08-21 14:15:54',NULL),(1878,'Produtor de rádio',1,2,'2018-08-21 14:15:54',NULL),(1879,'Produtor de rami',1,2,'2018-08-21 14:15:54',NULL),(1880,'Produtor de sisal',1,2,'2018-08-21 14:15:54',NULL),(1881,'Produtor de teatro',1,2,'2018-08-21 14:15:54',NULL),(1882,'Produtor de televisão',1,2,'2018-08-21 14:15:54',NULL),(1883,'Produtor de texto',1,2,'2018-08-21 14:15:54',NULL),(1884,'Produtor na olericultura de frutos e sementes',1,2,'2018-08-21 14:15:54',NULL),(1885,'Produtor na olericultura de legumes',1,2,'2018-08-21 14:15:54',NULL),(1886,'Produtor na olericultura de raízes, bulbos e tubérculos',1,2,'2018-08-21 14:15:54',NULL),(1887,'Produtor na olericultura de talos, folhas e flores',1,2,'2018-08-21 14:15:54',NULL),(1888,'Proeiro',1,2,'2018-08-21 14:15:54',NULL),(1889,'Professor da  educação de jovens e adultos do ensino fundamental (primeira a quarta série)',1,2,'2018-08-21 14:15:54',NULL),(1890,'Professor da área de meio ambiente',1,2,'2018-08-21 14:15:54',NULL),(1891,'Professor de administração',1,2,'2018-08-21 14:15:54',NULL),(1892,'Professor de alunos com deficiência auditiva e surdos',1,2,'2018-08-21 14:15:54',NULL),(1893,'Professor de alunos com deficiência física',1,2,'2018-08-21 14:15:54',NULL),(1894,'Professor de alunos com deficiência mental',1,2,'2018-08-21 14:15:54',NULL),(1895,'Professor de alunos com deficiência múltipla',1,2,'2018-08-21 14:15:54',NULL),(1896,'Professor de alunos com deficiência visual',1,2,'2018-08-21 14:15:54',NULL),(1897,'Professor de antropologia do ensino superior',1,2,'2018-08-21 14:15:54',NULL),(1898,'Professor de arquitetura',1,2,'2018-08-21 14:15:54',NULL),(1899,'Professor de arquivologia do ensino superior',1,2,'2018-08-21 14:15:54',NULL),(1900,'Professor de artes do espetáculo no ensino superior',1,2,'2018-08-21 14:15:54',NULL),(1901,'Professor de artes no ensino médio',1,2,'2018-08-21 14:15:54',NULL),(1902,'Professor de artes visuais no ensino superior (artes plásticas e multimídia)',1,2,'2018-08-21 14:15:54',NULL),(1903,'Professor de astronomia (ensino superior)',1,2,'2018-08-21 14:15:54',NULL),(1904,'Professor de biblioteconomia do ensino superior',1,2,'2018-08-21 14:15:54',NULL),(1905,'Professor de biologia no ensino médio',1,2,'2018-08-21 14:15:54',NULL),(1906,'Professor de ciência política do ensino superior',1,2,'2018-08-21 14:15:54',NULL),(1907,'Professor de ciências biológicas do ensino superior',1,2,'2018-08-21 14:15:54',NULL),(1908,'Professor de ciências exatas e naturais do ensino fundamental',1,2,'2018-08-21 14:15:54',NULL),(1909,'Professor de computação (no ensino superior)',1,2,'2018-08-21 14:15:54',NULL),(1910,'Professor de comunicação social do ensino superior',1,2,'2018-08-21 14:15:54',NULL),(1911,'Professor de contabilidade',1,2,'2018-08-21 14:15:54',NULL),(1912,'Professor de dança',1,2,'2018-08-21 14:15:54',NULL),(1913,'Professor de desenho técnico',1,2,'2018-08-21 14:15:54',NULL),(1914,'Professor de direito do ensino superior',1,2,'2018-08-21 14:15:54',NULL),(1915,'Professor de disciplinas pedagógicas no ensino médio',1,2,'2018-08-21 14:15:54',NULL),(1916,'Professor de economia',1,2,'2018-08-21 14:15:54',NULL),(1917,'Professor de educação artística do ensino fundamental',1,2,'2018-08-21 14:15:54',NULL),(1918,'Professor de educação física do ensino fundamental',1,2,'2018-08-21 14:15:54',NULL),(1919,'Professor de educação física no ensino médio',1,2,'2018-08-21 14:15:54',NULL),(1920,'Professor de educação física no ensino superior',1,2,'2018-08-21 14:15:54',NULL),(1921,'Professor de enfermagem do ensino superior',1,2,'2018-08-21 14:15:54',NULL),(1922,'Professor de engenharia',1,2,'2018-08-21 14:15:54',NULL),(1923,'Professor de ensino superior na área de didática',1,2,'2018-08-21 14:15:54',NULL),(1924,'Professor de ensino superior na área de orientação educacional',1,2,'2018-08-21 14:15:54',NULL),(1925,'Professor de ensino superior na área de pesquisa educacional',1,2,'2018-08-21 14:15:54',NULL),(1926,'Professor de ensino superior na área de prática de ensino',1,2,'2018-08-21 14:15:54',NULL),(1927,'Professor de estatística (no ensino superior)',1,2,'2018-08-21 14:15:54',NULL),(1928,'Professor de farmácia e bioquímica',1,2,'2018-08-21 14:15:54',NULL),(1929,'Professor de filologia e crítica textual',1,2,'2018-08-21 14:15:54',NULL),(1930,'Professor de filosofia do ensino superior',1,2,'2018-08-21 14:15:54',NULL),(1931,'Professor de filosofia no ensino médio',1,2,'2018-08-21 14:15:54',NULL),(1932,'Professor de física (ensino superior)',1,2,'2018-08-21 14:15:54',NULL),(1933,'Professor de física no ensino médio',1,2,'2018-08-21 14:15:54',NULL),(1934,'Professor de fisioterapia',1,2,'2018-08-21 14:15:54',NULL),(1935,'Professor de fonoaudiologia',1,2,'2018-08-21 14:15:54',NULL),(1936,'Professor de geofísica',1,2,'2018-08-21 14:15:54',NULL),(1937,'Professor de geografia do ensino fundamental',1,2,'2018-08-21 14:15:54',NULL),(1938,'Professor de geografia do ensino superior',1,2,'2018-08-21 14:15:54',NULL),(1939,'Professor de geografia no ensino médio',1,2,'2018-08-21 14:15:54',NULL),(1940,'Professor de geologia',1,2,'2018-08-21 14:15:54',NULL),(1941,'Professor de história do ensino fundamental',1,2,'2018-08-21 14:15:54',NULL),(1942,'Professor de história do ensino superior',1,2,'2018-08-21 14:15:54',NULL),(1943,'Professor de história no ensino médio',1,2,'2018-08-21 14:15:54',NULL),(1944,'Professor de jornalismo',1,2,'2018-08-21 14:15:54',NULL),(1945,'Professor de língua alemã',1,2,'2018-08-21 14:15:54',NULL),(1946,'Professor de língua e literatura brasileira no ensino médio',1,2,'2018-08-21 14:15:54',NULL),(1947,'Professor de língua espanhola',1,2,'2018-08-21 14:15:54',NULL),(1948,'Professor de língua estrangeira moderna do ensino fundamental',1,2,'2018-08-21 14:15:54',NULL),(1949,'Professor de língua estrangeira moderna no ensino médio',1,2,'2018-08-21 14:15:54',NULL),(1950,'Professor de língua francesa',1,2,'2018-08-21 14:15:54',NULL),(1951,'Professor de língua inglesa',1,2,'2018-08-21 14:15:54',NULL),(1952,'Professor de língua italiana',1,2,'2018-08-21 14:15:54',NULL),(1953,'Professor de língua portuguesa',1,2,'2018-08-21 14:15:54',NULL),(1954,'Professor de língua portuguesa do ensino fundamental',1,2,'2018-08-21 14:15:54',NULL),(1955,'Professor de línguas estrangeiras modernas',1,2,'2018-08-21 14:15:54',NULL),(1956,'Professor de lingüística e lingüística aplicada',1,2,'2018-08-21 14:15:54',NULL),(1957,'Professor de literatura alemã',1,2,'2018-08-21 14:15:54',NULL),(1958,'Professor de literatura brasileira',1,2,'2018-08-21 14:15:54',NULL),(1959,'Professor de literatura comparada',1,2,'2018-08-21 14:15:54',NULL),(1960,'Professor de literatura de línguas estrangeiras modernas',1,2,'2018-08-21 14:15:54',NULL),(1961,'Professor de literatura espanhola',1,2,'2018-08-21 14:15:54',NULL),(1962,'Professor de literatura francesa',1,2,'2018-08-21 14:15:54',NULL),(1963,'Professor de literatura inglesa',1,2,'2018-08-21 14:15:54',NULL),(1964,'Professor de literatura italiana',1,2,'2018-08-21 14:15:54',NULL),(1965,'Professor de literatura portuguesa',1,2,'2018-08-21 14:15:54',NULL),(1966,'Professor de matemática aplicada (no ensino superior)',1,2,'2018-08-21 14:15:54',NULL),(1967,'Professor de matemática do ensino fundamental',1,2,'2018-08-21 14:15:54',NULL),(1968,'Professor de matemática no ensino médio',1,2,'2018-08-21 14:15:54',NULL),(1969,'Professor de matemática pura (no ensino superior)',1,2,'2018-08-21 14:15:54',NULL),(1970,'Professor de medicina',1,2,'2018-08-21 14:15:54',NULL),(1971,'Professor de medicina veterinária',1,2,'2018-08-21 14:15:54',NULL),(1972,'Professor de museologia do ensino superior',1,2,'2018-08-21 14:15:54',NULL),(1973,'Professor de música no ensino superior',1,2,'2018-08-21 14:15:54',NULL),(1974,'Professor de nível médio na educação infantil',1,2,'2018-08-21 14:15:54',NULL),(1975,'Professor de nível médio no ensino fundamental',1,2,'2018-08-21 14:15:54',NULL),(1976,'Professor de nível médio no ensino profissionalizante',1,2,'2018-08-21 14:15:54',NULL),(1977,'Professor de nível superior do ensino fundamental (primeira a quarta série)',1,2,'2018-08-21 14:15:54',NULL),(1978,'Professor de nível superior na educação infantil (quatro a seis anos)',1,2,'2018-08-21 14:15:54',NULL),(1979,'Professor de nível superior na educação infantil (zero a três anos)',1,2,'2018-08-21 14:15:54',NULL),(1980,'Professor de nutrição',1,2,'2018-08-21 14:15:54',NULL),(1981,'Professor de odontologia',1,2,'2018-08-21 14:15:54',NULL),(1982,'Professor de outras línguas e literaturas',1,2,'2018-08-21 14:15:54',NULL),(1983,'Professor de pesquisa operacional (no ensino superior)',1,2,'2018-08-21 14:15:54',NULL),(1984,'Professor de psicologia do ensino superior',1,2,'2018-08-21 14:15:54',NULL),(1985,'Professor de psicologia no ensino médio',1,2,'2018-08-21 14:15:54',NULL),(1986,'Professor de química (ensino superior)',1,2,'2018-08-21 14:15:54',NULL),(1987,'Professor de química no ensino médio',1,2,'2018-08-21 14:15:54',NULL),(1988,'Professor de semiótica',1,2,'2018-08-21 14:15:54',NULL),(1989,'Professor de serviço social do ensino superior',1,2,'2018-08-21 14:15:54',NULL),(1990,'Professor de sociologia do ensino superior',1,2,'2018-08-21 14:15:54',NULL),(1991,'Professor de sociologia no ensino médio',1,2,'2018-08-21 14:15:54',NULL),(1992,'Professor de técnicas agrícolas',1,2,'2018-08-21 14:15:54',NULL),(1993,'Professor de técnicas comerciais e secretariais',1,2,'2018-08-21 14:15:54',NULL),(1994,'Professor de técnicas de enfermagem',1,2,'2018-08-21 14:15:54',NULL),(1995,'Professor de técnicas e recursos audiovisuais',1,2,'2018-08-21 14:15:54',NULL),(1996,'Professor de técnicas industriais',1,2,'2018-08-21 14:15:54',NULL),(1997,'Professor de tecnologia e cálculo técnico',1,2,'2018-08-21 14:15:54',NULL),(1998,'Professor de teoria da literatura',1,2,'2018-08-21 14:15:54',NULL),(1999,'Professor de terapia ocupacional',1,2,'2018-08-21 14:15:54',NULL),(2000,'Professor de zootecnia do ensino superior',1,2,'2018-08-21 14:15:54',NULL),(2001,'Professor instrutor de ensino e aprendizagem agroflorestal',1,2,'2018-08-21 14:15:54',NULL),(2002,'Professor instrutor de ensino e aprendizagem em serviços',1,2,'2018-08-21 14:15:54',NULL),(2003,'Professor leigo no ensino fundamental',1,2,'2018-08-21 14:15:54',NULL),(2004,'Professor prático no ensino profissionalizante',1,2,'2018-08-21 14:15:54',NULL),(2005,'Professores de cursos livres',1,2,'2018-08-21 14:15:54',NULL),(2006,'Profissional de atletismo',1,2,'2018-08-21 14:15:54',NULL),(2007,'Profissional de relações com investidores',1,2,'2018-08-21 14:15:54',NULL),(2008,'Profissional do sexo',1,2,'2018-08-21 14:15:54',NULL),(2009,'Programador de internet',1,2,'2018-08-21 14:15:54',NULL),(2010,'Programador de máquinas - ferramenta com comando numérico',1,2,'2018-08-21 14:15:54',NULL),(2011,'Programador de multimídia',1,2,'2018-08-21 14:15:54',NULL),(2012,'Programador de sistemas de informação',1,2,'2018-08-21 14:15:54',NULL),(2013,'Programador visual gráfico',1,2,'2018-08-21 14:15:54',NULL),(2014,'Projetista de móveis',1,2,'2018-08-21 14:15:54',NULL),(2015,'Projetista de sistemas de áudio',1,2,'2018-08-21 14:15:54',NULL),(2016,'Projetista de som',1,2,'2018-08-21 14:15:54',NULL),(2017,'Promotor de justiça',1,2,'2018-08-21 14:15:54',NULL),(2018,'Promotor de vendas',1,2,'2018-08-21 14:15:54',NULL),(2019,'Promotor de vendas especializado',1,2,'2018-08-21 14:15:54',NULL),(2020,'Propagandista de produtos famacêuticos',1,2,'2018-08-21 14:15:54',NULL),(2021,'Protético dentário',1,2,'2018-08-21 14:15:54',NULL),(2022,'Psicanalista',1,2,'2018-08-21 14:15:54',NULL),(2023,'Psicólogo acupunturista',1,2,'2018-08-21 14:15:54',NULL),(2024,'Psicólogo clínico',1,2,'2018-08-21 14:15:54',NULL),(2025,'Psicólogo do esporte',1,2,'2018-08-21 14:15:54',NULL),(2026,'Psicólogo do trabalho',1,2,'2018-08-21 14:15:54',NULL),(2027,'Psicólogo do trânsito',1,2,'2018-08-21 14:15:54',NULL),(2028,'Psicólogo educacional',1,2,'2018-08-21 14:15:54',NULL),(2029,'Psicólogo hospitalar',1,2,'2018-08-21 14:15:54',NULL),(2030,'Psicólogo jurídico',1,2,'2018-08-21 14:15:54',NULL),(2031,'Psicólogo social',1,2,'2018-08-21 14:15:54',NULL),(2032,'Psicopedagogo',1,2,'2018-08-21 14:15:54',NULL),(2033,'Publicitário',1,2,'2018-08-21 14:15:54',NULL),(2034,'Pugilista',1,2,'2018-08-21 14:15:54',NULL),(2035,'Queijeiro na fabricação de laticínio',1,2,'2018-08-21 14:15:54',NULL),(2036,'Químico',1,2,'2018-08-21 14:15:54',NULL),(2037,'Químico industrial',1,2,'2018-08-21 14:15:54',NULL),(2038,'Quiropraxista',1,2,'2018-08-21 14:15:54',NULL),(2039,'Rachador de couros e peles',1,2,'2018-08-21 14:15:54',NULL),(2040,'Radiotelegrafista',1,2,'2018-08-21 14:15:54',NULL),(2041,'Raizeiro',1,2,'2018-08-21 14:15:54',NULL),(2042,'Rebaixador de couros',1,2,'2018-08-21 14:15:54',NULL),(2043,'Rebarbador de metal',1,2,'2018-08-21 14:15:54',NULL),(2044,'Rebitador a  martelo pneumático',1,2,'2018-08-21 14:15:54',NULL),(2045,'Rebitador, a  mão',1,2,'2018-08-21 14:15:54',NULL),(2046,'Recebedor de apostas (loteria)',1,2,'2018-08-21 14:15:54',NULL),(2047,'Recebedor de apostas (turfe)',1,2,'2018-08-21 14:15:54',NULL),(2048,'Recepcionista de banco',1,2,'2018-08-21 14:15:54',NULL),(2049,'Recepcionista de casas de espetáculos',1,2,'2018-08-21 14:15:54',NULL),(2050,'Recepcionista de consultório médico ou dentário',1,2,'2018-08-21 14:15:54',NULL),(2051,'Recepcionista de hotel',1,2,'2018-08-21 14:15:54',NULL),(2052,'Recepcionista de seguro saúde',1,2,'2018-08-21 14:15:54',NULL),(2053,'Recepcionista, em geral',1,2,'2018-08-21 14:15:54',NULL),(2054,'Recreador',1,2,'2018-08-21 14:15:54',NULL),(2055,'Recreador de acantonamento',1,2,'2018-08-21 14:15:54',NULL),(2056,'Recuperador de guias e cilindros',1,2,'2018-08-21 14:15:54',NULL),(2057,'Redator de publicidade',1,2,'2018-08-21 14:15:54',NULL),(2058,'Redator de textos técnicos',1,2,'2018-08-21 14:15:54',NULL),(2059,'Redeiro',1,2,'2018-08-21 14:15:54',NULL),(2060,'Redeiro (pesca)',1,2,'2018-08-21 14:15:54',NULL),(2061,'Refinador de óleo e gordura',1,2,'2018-08-21 14:15:54',NULL),(2062,'Refinador de sal',1,2,'2018-08-21 14:15:54',NULL),(2063,'Relações públicas',1,2,'2018-08-21 14:15:54',NULL),(2064,'Relojoeiro (fabricação)',1,2,'2018-08-21 14:15:54',NULL),(2065,'Relojoeiro (reparação)',1,2,'2018-08-21 14:15:54',NULL),(2066,'Remetedor de fios',1,2,'2018-08-21 14:15:54',NULL),(2067,'Reparador de aparelhos de telecomunicações em laboratório',1,2,'2018-08-21 14:15:54',NULL),(2068,'Reparador de aparelhos eletrodomésticos (exceto imagem e som)',1,2,'2018-08-21 14:15:54',NULL),(2069,'Reparador de equipamentos de escritório',1,2,'2018-08-21 14:15:54',NULL),(2070,'Reparador de equipamentos fotográficos',1,2,'2018-08-21 14:15:54',NULL),(2071,'Reparador de instrumentos musicais',1,2,'2018-08-21 14:15:54',NULL),(2072,'Reparador de rádio, tv e som',1,2,'2018-08-21 14:15:54',NULL),(2073,'Repórter (exclusive rádio e televisão)',1,2,'2018-08-21 14:15:54',NULL),(2074,'Repórter de rádio e televisão',1,2,'2018-08-21 14:15:54',NULL),(2075,'Repórter fotográfico',1,2,'2018-08-21 14:15:54',NULL),(2076,'Repositor de mercadorias',1,2,'2018-08-21 14:15:54',NULL),(2077,'Representante comercial autônomo',1,2,'2018-08-21 14:15:54',NULL),(2078,'Restaurador de instrumentos musicais (exceto cordas arcadas)',1,2,'2018-08-21 14:15:54',NULL),(2079,'Restaurador de livros',1,2,'2018-08-21 14:15:54',NULL),(2080,'Retalhador de carne',1,2,'2018-08-21 14:15:54',NULL),(2081,'Revelador de filmes fotográficos, em cores',1,2,'2018-08-21 14:15:54',NULL),(2082,'Revelador de filmes fotográficos, em preto e branco',1,2,'2018-08-21 14:15:54',NULL),(2083,'Revestidor de interiores (papel, material plástico e emborrachados)',1,2,'2018-08-21 14:15:54',NULL),(2084,'Revestidor de superfícies de concreto',1,2,'2018-08-21 14:15:54',NULL),(2085,'Revisor de fios (produção têxtil)',1,2,'2018-08-21 14:15:54',NULL),(2086,'Revisor de tecidos acabados',1,2,'2018-08-21 14:15:54',NULL),(2087,'Revisor de tecidos crus',1,2,'2018-08-21 14:15:54',NULL),(2088,'Revisor de texto',1,2,'2018-08-21 14:15:54',NULL),(2089,'Riscador de estruturas metálicas',1,2,'2018-08-21 14:15:54',NULL),(2090,'Riscador de roupas',1,2,'2018-08-21 14:15:54',NULL),(2091,'Sacristão',1,2,'2018-08-21 14:15:54',NULL),(2092,'Salgador de alimentos',1,2,'2018-08-21 14:15:54',NULL),(2093,'Salsicheiro (fabricação de lingüiça, salsicha e produtos similares)',1,2,'2018-08-21 14:15:54',NULL),(2094,'Salva-vidas',1,2,'2018-08-21 14:15:54',NULL),(2095,'Sapateiro (calçados sob medida)',1,2,'2018-08-21 14:15:54',NULL),(2096,'Sargento bombeiro militar',1,2,'2018-08-21 14:15:54',NULL),(2097,'Sargento da policia militar',1,2,'2018-08-21 14:15:54',NULL),(2098,'Secador de madeira',1,2,'2018-08-21 14:15:54',NULL),(2099,'Secretária trilíngüe',1,2,'2018-08-21 14:15:54',NULL),(2100,'Secretária(o) executiva(o)',1,2,'2018-08-21 14:15:54',NULL),(2101,'Secretário  bilíngüe',1,2,'2018-08-21 14:15:54',NULL),(2102,'Secretário - executivo',1,2,'2018-08-21 14:15:54',NULL),(2103,'Segundo oficial de máquinas da marinha mercante',1,2,'2018-08-21 14:15:54',NULL),(2104,'Segundo tenente de polícia militar',1,2,'2018-08-21 14:15:54',NULL),(2105,'Selecionador de material reciclável',1,2,'2018-08-21 14:15:54',NULL),(2106,'Seleiro',1,2,'2018-08-21 14:15:54',NULL),(2107,'Senador',1,2,'2018-08-21 14:15:54',NULL),(2108,'Sepultador',1,2,'2018-08-21 14:15:54',NULL),(2109,'Sericultor',1,2,'2018-08-21 14:15:54',NULL),(2110,'Seringueiro',1,2,'2018-08-21 14:15:54',NULL),(2111,'Serrador de bordas no desdobramento de madeira',1,2,'2018-08-21 14:15:54',NULL),(2112,'Serrador de madeira',1,2,'2018-08-21 14:15:54',NULL),(2113,'Serrador de madeira (serra circular múltipla)',1,2,'2018-08-21 14:15:54',NULL),(2114,'Serrador de madeira (serra de fita múltipla)',1,2,'2018-08-21 14:15:54',NULL),(2115,'Serralheiro',1,2,'2018-08-21 14:15:54',NULL),(2116,'Servente de obras',1,2,'2018-08-21 14:15:54',NULL),(2117,'Sexador',1,2,'2018-08-21 14:15:54',NULL),(2118,'Sinaleiro (ponte-rolante)',1,2,'2018-08-21 14:15:54',NULL),(2119,'Sócioeducador',1,2,'2018-08-21 14:15:54',NULL),(2120,'Sociólogo',1,2,'2018-08-21 14:15:54',NULL),(2121,'Socorrista (exceto médicos e enfermeiros)',1,2,'2018-08-21 14:15:54',NULL),(2122,'Soldado bombeiro militar',1,2,'2018-08-21 14:15:54',NULL),(2123,'Soldado da polícia militar',1,2,'2018-08-21 14:15:54',NULL),(2124,'Soldador',1,2,'2018-08-21 14:15:54',NULL),(2125,'Soldador a  oxigás',1,2,'2018-08-21 14:15:54',NULL),(2126,'Soldador aluminotérmico em conservação de trilhos',1,2,'2018-08-21 14:15:54',NULL),(2127,'Soldador elétrico',1,2,'2018-08-21 14:15:54',NULL),(2128,'Sondador (poços de petróleo e gás)',1,2,'2018-08-21 14:15:54',NULL),(2129,'Sondador de poços (exceto de petróleo e gás)',1,2,'2018-08-21 14:15:54',NULL),(2130,'Soprador de convertedor',1,2,'2018-08-21 14:15:54',NULL),(2131,'Soprador de vidro',1,2,'2018-08-21 14:15:54',NULL),(2132,'Subprocurador de justiça militar',1,2,'2018-08-21 14:15:54',NULL),(2133,'Subprocurador-geral da república',1,2,'2018-08-21 14:15:54',NULL),(2134,'Subprocurador-geral do trabalho',1,2,'2018-08-21 14:15:54',NULL),(2135,'Subtenente bombeiro militar',1,2,'2018-08-21 14:15:54',NULL),(2136,'Subtenente da policia militar',1,2,'2018-08-21 14:15:54',NULL),(2137,'Superintendente técnico no transporte aquaviário',1,2,'2018-08-21 14:15:54',NULL),(2138,'Supervisor  (indústria de calçados e artefatos de couro)',1,2,'2018-08-21 14:15:54',NULL),(2139,'Supervisor administrativo',1,2,'2018-08-21 14:15:54',NULL),(2140,'Supervisor da administração de aeroportos',1,2,'2018-08-21 14:15:54',NULL),(2141,'Supervisor da aqüicultura',1,2,'2018-08-21 14:15:54',NULL),(2142,'Supervisor da área florestal',1,2,'2018-08-21 14:15:54',NULL),(2143,'Supervisor da confecção de artefatos de tecidos, couros e afins',1,2,'2018-08-21 14:15:54',NULL),(2144,'Supervisor da indústria de bebidas',1,2,'2018-08-21 14:15:54',NULL),(2145,'Supervisor da indústria de fumo',1,2,'2018-08-21 14:15:54',NULL),(2146,'Supervisor da indústria de minerais não metálicos (exceto os derivados de petróleo e carvão)',1,2,'2018-08-21 14:15:54',NULL),(2147,'Supervisor da manutenção e reparação de veículos leves',1,2,'2018-08-21 14:15:54',NULL),(2148,'Supervisor da manutenção e reparação de veículos pesados',1,2,'2018-08-21 14:15:54',NULL),(2149,'Supervisor da mecânica de precisão',1,2,'2018-08-21 14:15:54',NULL),(2150,'Supervisor das artes gráficas  (indústria editorial e gráfica)',1,2,'2018-08-21 14:15:54',NULL),(2151,'Supervisor de almoxarifado',1,2,'2018-08-21 14:15:54',NULL),(2152,'Supervisor de andar',1,2,'2018-08-21 14:15:54',NULL),(2153,'Supervisor de apoio operacional na mineração',1,2,'2018-08-21 14:15:54',NULL),(2154,'Supervisor de bombeiros',1,2,'2018-08-21 14:15:54',NULL),(2155,'Supervisor de caixas e bilheteiros (exceto caixa de banco)',1,2,'2018-08-21 14:15:54',NULL),(2156,'Supervisor de câmbio',1,2,'2018-08-21 14:15:54',NULL),(2157,'Supervisor de carga e descarga',1,2,'2018-08-21 14:15:54',NULL),(2158,'Supervisor de cobrança',1,2,'2018-08-21 14:15:54',NULL),(2159,'Supervisor de coletadores de apostas e de jogos',1,2,'2018-08-21 14:15:54',NULL),(2160,'Supervisor de compras',1,2,'2018-08-21 14:15:54',NULL),(2161,'Supervisor de contas a pagar',1,2,'2018-08-21 14:15:54',NULL),(2162,'Supervisor de controle de tratamento térmico',1,2,'2018-08-21 14:15:54',NULL),(2163,'Supervisor de controle patrimonial',1,2,'2018-08-21 14:15:54',NULL),(2164,'Supervisor de crédito e cobrança',1,2,'2018-08-21 14:15:54',NULL),(2165,'Supervisor de curtimento',1,2,'2018-08-21 14:15:54',NULL),(2166,'Supervisor de digitação e operação',1,2,'2018-08-21 14:15:54',NULL),(2167,'Supervisor de embalagem e etiquetagem',1,2,'2018-08-21 14:15:54',NULL),(2168,'Supervisor de empresa aérea em aeroportos',1,2,'2018-08-21 14:15:54',NULL),(2169,'Supervisor de ensino',1,2,'2018-08-21 14:15:54',NULL),(2170,'Supervisor de entrevistadores e recenseadores',1,2,'2018-08-21 14:15:54',NULL),(2171,'Supervisor de exploração agrícola',1,2,'2018-08-21 14:15:54',NULL),(2172,'Supervisor de exploração agropecuária',1,2,'2018-08-21 14:15:54',NULL),(2173,'Supervisor de exploração pecuária',1,2,'2018-08-21 14:15:54',NULL),(2174,'Supervisor de extração de sal',1,2,'2018-08-21 14:15:54',NULL),(2175,'Supervisor de fabricação de instrumentos musicais',1,2,'2018-08-21 14:15:54',NULL),(2176,'Supervisor de fabricação de produtos cerâmicos, porcelanatos e afins',1,2,'2018-08-21 14:15:54',NULL),(2177,'Supervisor de fabricação de produtos de vidro',1,2,'2018-08-21 14:15:54',NULL),(2178,'Supervisor de joalheria',1,2,'2018-08-21 14:15:54',NULL),(2179,'Supervisor de lavanderia',1,2,'2018-08-21 14:15:54',NULL),(2180,'Supervisor de manutenção de aparelhos térmicos, de climatização e de refrigeração',1,2,'2018-08-21 14:15:54',NULL),(2181,'Supervisor de manutenção de bombas, motores, compressores e equipamentos de transmissão',1,2,'2018-08-21 14:15:54',NULL),(2182,'Supervisor de manutenção de máquinas gráficas',1,2,'2018-08-21 14:15:54',NULL),(2183,'Supervisor de manutenção de máquinas industriais têxteis',1,2,'2018-08-21 14:15:54',NULL),(2184,'Supervisor de manutenção de máquinas operatrizes e de usinagem',1,2,'2018-08-21 14:15:54',NULL),(2185,'Supervisor de manutenção de vias férreas',1,2,'2018-08-21 14:15:54',NULL),(2186,'Supervisor de manutenção elétrica de alta tensão industrial',1,2,'2018-08-21 14:15:54',NULL),(2187,'Supervisor de manutenção eletromecânica',1,2,'2018-08-21 14:15:54',NULL),(2188,'Supervisor de manutenção eletromecânica (utilidades)',1,2,'2018-08-21 14:15:54',NULL),(2189,'Supervisor de manutenção eletromecânica industrial, comercial e predial',1,2,'2018-08-21 14:15:54',NULL),(2190,'Supervisor de montagem e instalação eletroeletrônica',1,2,'2018-08-21 14:15:54',NULL),(2191,'Supervisor de operação de fluidos (distribuição, captação, tratamento de água, gases, vapor)',1,2,'2018-08-21 14:15:54',NULL),(2192,'Supervisor de operação elétrica (geração, transmissão e distribuição de energia elétrica)',1,2,'2018-08-21 14:15:54',NULL),(2193,'Supervisor de operações portuárias',1,2,'2018-08-21 14:15:54',NULL),(2194,'Supervisor de orçamento',1,2,'2018-08-21 14:15:54',NULL),(2195,'Supervisor de perfuração e desmonte',1,2,'2018-08-21 14:15:54',NULL),(2196,'Supervisor de produção da indústria alimentícia',1,2,'2018-08-21 14:15:54',NULL),(2197,'Supervisor de produção na mineração',1,2,'2018-08-21 14:15:54',NULL),(2198,'Supervisor de recepcionistas',1,2,'2018-08-21 14:15:54',NULL),(2199,'Supervisor de reparos linhas férreas',1,2,'2018-08-21 14:15:54',NULL),(2200,'Supervisor de telefonistas',1,2,'2018-08-21 14:15:54',NULL),(2201,'Supervisor de telemarketing e atendimento',1,2,'2018-08-21 14:15:54',NULL),(2202,'Supervisor de tesouraria',1,2,'2018-08-21 14:15:54',NULL),(2203,'Supervisor de transporte na mineração',1,2,'2018-08-21 14:15:54',NULL),(2204,'Supervisor de transportes',1,2,'2018-08-21 14:15:54',NULL),(2205,'Supervisor de usina de concreto',1,2,'2018-08-21 14:15:54',NULL),(2206,'Supervisor de vendas comercial',1,2,'2018-08-21 14:15:54',NULL),(2207,'Supervisor de vendas de serviços',1,2,'2018-08-21 14:15:54',NULL),(2208,'Supervisor de vigilantes',1,2,'2018-08-21 14:15:54',NULL),(2209,'Supervisor técnico operacional de sistemas de televisão e produtoras de vídeo',1,2,'2018-08-21 14:15:54',NULL),(2210,'Surfassagista',1,2,'2018-08-21 14:15:54',NULL),(2211,'Sushiman',1,2,'2018-08-21 14:15:54',NULL),(2212,'Tabelião de notas',1,2,'2018-08-21 14:15:54',NULL),(2213,'Tabelião de protestos',1,2,'2018-08-21 14:15:54',NULL),(2214,'Taifeiro (exceto militares)',1,2,'2018-08-21 14:15:54',NULL),(2215,'Tanoeiro',1,2,'2018-08-21 14:15:54',NULL),(2216,'Tapeceiro de autos',1,2,'2018-08-21 14:15:54',NULL),(2217,'Taqueiro',1,2,'2018-08-21 14:15:54',NULL),(2218,'Taquígrafo',1,2,'2018-08-21 14:15:54',NULL),(2219,'Taxidermista',1,2,'2018-08-21 14:15:54',NULL),(2220,'Tecelão (redes)',1,2,'2018-08-21 14:15:54',NULL),(2221,'Tecelão (rendas e bordados)',1,2,'2018-08-21 14:15:54',NULL),(2222,'Tecelão (tear automático)',1,2,'2018-08-21 14:15:54',NULL),(2223,'Tecelão (tear jacquard)',1,2,'2018-08-21 14:15:54',NULL),(2224,'Tecelão (tear manual)',1,2,'2018-08-21 14:15:54',NULL),(2225,'Tecelão (tear mecânico de maquineta)',1,2,'2018-08-21 14:15:54',NULL),(2226,'Tecelão (tear mecânico de xadrez)',1,2,'2018-08-21 14:15:54',NULL),(2227,'Tecelão (tear mecânico liso)',1,2,'2018-08-21 14:15:54',NULL),(2228,'Tecelão (tear mecânico, exceto jacquard)',1,2,'2018-08-21 14:15:54',NULL),(2229,'Tecelão de malhas (máquina circular)',1,2,'2018-08-21 14:15:54',NULL),(2230,'Tecelão de malhas (máquina retilínea)',1,2,'2018-08-21 14:15:54',NULL),(2231,'Tecelão de malhas, a  máquina',1,2,'2018-08-21 14:15:54',NULL),(2232,'Tecelão de meias (máquina circular)',1,2,'2018-08-21 14:15:54',NULL),(2233,'Tecelão de meias (máquina retilínea)',1,2,'2018-08-21 14:15:54',NULL),(2234,'Tecelão de meias, a  máquina',1,2,'2018-08-21 14:15:54',NULL),(2235,'Tecelão de tapetes, a  mão',1,2,'2018-08-21 14:15:54',NULL),(2236,'Tecelão de tapetes, a  máquina',1,2,'2018-08-21 14:15:54',NULL),(2237,'Técnico agrícola',1,2,'2018-08-21 14:15:54',NULL),(2238,'Técnico agropecuário',1,2,'2018-08-21 14:15:54',NULL),(2239,'Técnico da receita federal',1,2,'2018-08-21 14:15:54',NULL),(2240,'Técnico de acabamento em siderurgia',1,2,'2018-08-21 14:15:54',NULL),(2241,'Técnico de aciaria em siderurgia',1,2,'2018-08-21 14:15:54',NULL),(2242,'Técnico de alimentos',1,2,'2018-08-21 14:15:54',NULL),(2243,'Técnico de apoio à bioengenharia',1,2,'2018-08-21 14:15:54',NULL),(2244,'Técnico de apoio ao usuário de informática (helpdesk)',1,2,'2018-08-21 14:15:54',NULL),(2245,'Técnico de apoio em pesquisa e desenvolvimento (exceto agropecuário e florestal)',1,2,'2018-08-21 14:15:54',NULL),(2246,'Técnico de apoio em pesquisa e desenvolvimento agropecuário florestal',1,2,'2018-08-21 14:15:54',NULL),(2247,'Técnico de celulose e papel',1,2,'2018-08-21 14:15:54',NULL),(2248,'Técnico de comunicação de dados',1,2,'2018-08-21 14:15:54',NULL),(2249,'Técnico de contabilidade',1,2,'2018-08-21 14:15:54',NULL),(2250,'Técnico de controle de meio ambiente',1,2,'2018-08-21 14:15:54',NULL),(2251,'Técnico de desporto individual e coletivo (exceto futebol)',1,2,'2018-08-21 14:15:54',NULL),(2252,'Técnico de enfermagem',1,2,'2018-08-21 14:15:54',NULL),(2253,'Técnico de enfermagem da estratégia de saúde da família',1,2,'2018-08-21 14:15:54',NULL),(2254,'Técnico de enfermagem de terapia intensiva',1,2,'2018-08-21 14:15:54',NULL),(2255,'Técnico de enfermagem do trabalho',1,2,'2018-08-21 14:15:54',NULL),(2256,'Técnico de enfermagem psiquiátrica',1,2,'2018-08-21 14:15:54',NULL),(2257,'Técnico de estradas',1,2,'2018-08-21 14:15:54',NULL),(2258,'Técnico de fundição em siderurgia',1,2,'2018-08-21 14:15:54',NULL),(2259,'Técnico de garantia da qualidade',1,2,'2018-08-21 14:15:54',NULL),(2260,'Técnico de imobilização ortopédica',1,2,'2018-08-21 14:15:54',NULL),(2261,'Técnico de laboratório de análises físico-químicas (materiais de construção)',1,2,'2018-08-21 14:15:54',NULL),(2262,'Técnico de laboratório e fiscalização desportiva',1,2,'2018-08-21 14:15:54',NULL),(2263,'Técnico de laboratório industrial',1,2,'2018-08-21 14:15:54',NULL),(2264,'Técnico de laminação em siderurgia',1,2,'2018-08-21 14:15:54',NULL),(2265,'Técnico de manutenção de sistemas e instrumentos',1,2,'2018-08-21 14:15:54',NULL),(2266,'Técnico de manutenção elétrica',1,2,'2018-08-21 14:15:54',NULL),(2267,'Técnico de manutenção elétrica de máquina',1,2,'2018-08-21 14:15:54',NULL),(2268,'Técnico de manutenção eletrônica',1,2,'2018-08-21 14:15:54',NULL),(2269,'Técnico de manutenção eletrônica (circuitos de máquinas com comando numérico)',1,2,'2018-08-21 14:15:54',NULL),(2270,'Técnico de matéria-prima e material',1,2,'2018-08-21 14:15:54',NULL),(2271,'Técnico de meteorologia',1,2,'2018-08-21 14:15:54',NULL),(2272,'Técnico de mineração',1,2,'2018-08-21 14:15:54',NULL),(2273,'Técnico de mineração (óleo e petróleo)',1,2,'2018-08-21 14:15:54',NULL),(2274,'Técnico de obras civis',1,2,'2018-08-21 14:15:54',NULL),(2275,'Técnico de operação (química, petroquímica e afins)',1,2,'2018-08-21 14:15:54',NULL),(2276,'Técnico de operações e serviços bancários - câmbio',1,2,'2018-08-21 14:15:54',NULL),(2277,'Técnico de operações e serviços bancários - crédito imobiliário',1,2,'2018-08-21 14:15:54',NULL),(2278,'Técnico de operações e serviços bancários - crédito rural',1,2,'2018-08-21 14:15:54',NULL),(2279,'Técnico de operações e serviços bancários - leasing',1,2,'2018-08-21 14:15:54',NULL),(2280,'Técnico de operações e serviços bancários - renda fixa e variável',1,2,'2018-08-21 14:15:54',NULL),(2281,'Técnico de ortopedia',1,2,'2018-08-21 14:15:54',NULL),(2282,'Técnico de painel de controle',1,2,'2018-08-21 14:15:54',NULL),(2283,'Técnico de planejamento de produção',1,2,'2018-08-21 14:15:54',NULL),(2284,'Técnico de planejamento e programação da manutenção',1,2,'2018-08-21 14:15:54',NULL),(2285,'Técnico de produção em refino de petróleo',1,2,'2018-08-21 14:15:54',NULL),(2286,'Técnico de rede (telecomunicações)',1,2,'2018-08-21 14:15:54',NULL),(2287,'Técnico de redução na siderurgia (primeira fusão)',1,2,'2018-08-21 14:15:54',NULL),(2288,'Técnico de refratário em siderurgia',1,2,'2018-08-21 14:15:54',NULL),(2289,'Técnico de resseguros',1,2,'2018-08-21 14:15:54',NULL),(2290,'Técnico de saneamento',1,2,'2018-08-21 14:15:54',NULL),(2291,'Técnico de seguros',1,2,'2018-08-21 14:15:54',NULL),(2292,'Técnico de telecomunicações (telefonia)',1,2,'2018-08-21 14:15:54',NULL),(2293,'Técnico de transmissão (telecomunicações)',1,2,'2018-08-21 14:15:54',NULL),(2294,'Técnico de tributos estadual',1,2,'2018-08-21 14:15:54',NULL),(2295,'Técnico de tributos municipal',1,2,'2018-08-21 14:15:54',NULL),(2296,'Técnico de utilidade (produção e distribuição de vapor, gases, óleos, combustíveis, energia)',1,2,'2018-08-21 14:15:54',NULL),(2297,'Técnico de vendas',1,2,'2018-08-21 14:15:54',NULL),(2298,'Técnico do mobiliário',1,2,'2018-08-21 14:15:54',NULL),(2299,'Técnico eletricista',1,2,'2018-08-21 14:15:54',NULL),(2300,'Técnico eletrônico',1,2,'2018-08-21 14:15:54',NULL),(2301,'Técnico em acupuntura',1,2,'2018-08-21 14:15:54',NULL),(2302,'Técnico em administração',1,2,'2018-08-21 14:15:54',NULL),(2303,'Técnico em administração de comércio exterior',1,2,'2018-08-21 14:15:54',NULL),(2304,'Técnico em agrimensura',1,2,'2018-08-21 14:15:54',NULL),(2305,'Técnico em atendimento e vendas',1,2,'2018-08-21 14:15:54',NULL),(2306,'Técnico em automobilística',1,2,'2018-08-21 14:15:54',NULL),(2307,'Técnico em biblioteconomia',1,2,'2018-08-21 14:15:54',NULL),(2308,'Técnico em biotecnologia',1,2,'2018-08-21 14:15:54',NULL),(2309,'Técnico em bioterismo',1,2,'2018-08-21 14:15:54',NULL),(2310,'Técnico em borracha',1,2,'2018-08-21 14:15:54',NULL),(2311,'Técnico em calçados e artefatos de couro',1,2,'2018-08-21 14:15:54',NULL),(2312,'Técnico em caldeiraria',1,2,'2018-08-21 14:15:54',NULL),(2313,'Técnico em calibração',1,2,'2018-08-21 14:15:54',NULL),(2314,'Técnico em carcinicultura',1,2,'2018-08-21 14:15:54',NULL),(2315,'Técnico em confecções do vestuário',1,2,'2018-08-21 14:15:54',NULL),(2316,'Técnico em curtimento',1,2,'2018-08-21 14:15:54',NULL),(2317,'Técnico em direitos autorais',1,2,'2018-08-21 14:15:54',NULL),(2318,'Técnico em eletromecânica',1,2,'2018-08-21 14:15:54',NULL),(2319,'Técnico em estruturas metálicas',1,2,'2018-08-21 14:15:54',NULL),(2320,'Técnico em farmácia',1,2,'2018-08-21 14:15:54',NULL),(2321,'Técnico em fotônica',1,2,'2018-08-21 14:15:54',NULL),(2322,'Técnico em geodésia e cartografia',1,2,'2018-08-21 14:15:54',NULL),(2323,'Técnico em geofísica',1,2,'2018-08-21 14:15:54',NULL),(2324,'Técnico em geologia',1,2,'2018-08-21 14:15:54',NULL),(2325,'Técnico em geoquímica',1,2,'2018-08-21 14:15:54',NULL),(2326,'Técnico em geotecnia',1,2,'2018-08-21 14:15:54',NULL),(2327,'Técnico em gravação de áudio',1,2,'2018-08-21 14:15:54',NULL),(2328,'Técnico em hemoterapia',1,2,'2018-08-21 14:15:54',NULL),(2329,'Técnico em hidrografia',1,2,'2018-08-21 14:15:54',NULL),(2330,'Técnico em higiene ocupacional',1,2,'2018-08-21 14:15:54',NULL),(2331,'Técnico em histologia',1,2,'2018-08-21 14:15:54',NULL),(2332,'Técnico em imunobiológicos',1,2,'2018-08-21 14:15:54',NULL),(2333,'Técnico em instalação de equipamentos de áudio',1,2,'2018-08-21 14:15:54',NULL),(2334,'Técnico em instrumentação',1,2,'2018-08-21 14:15:54',NULL),(2335,'Técnico em laboratório de farmácia',1,2,'2018-08-21 14:15:54',NULL),(2336,'Técnico em madeira',1,2,'2018-08-21 14:15:54',NULL),(2337,'Técnico em manutenção de balanças',1,2,'2018-08-21 14:15:54',NULL),(2338,'Técnico em manutenção de equipamentos de informática',1,2,'2018-08-21 14:15:54',NULL),(2339,'Técnico em manutenção de equipamentos e instrumentos médico-hospitalares',1,2,'2018-08-21 14:15:54',NULL),(2340,'Técnico em manutenção de hidrômetros',1,2,'2018-08-21 14:15:54',NULL),(2341,'Técnico em manutenção de instrumentos de medição e precisão',1,2,'2018-08-21 14:15:54',NULL),(2342,'Técnico em manutenção de máquinas',1,2,'2018-08-21 14:15:54',NULL),(2343,'Técnico em masterização de áudio',1,2,'2018-08-21 14:15:54',NULL),(2344,'Técnico em materiais, produtos cerâmicos e vidros',1,2,'2018-08-21 14:15:54',NULL),(2345,'Técnico em mecânica de precisão',1,2,'2018-08-21 14:15:54',NULL),(2346,'Técnico em mecatrônica - automação da manufatura',1,2,'2018-08-21 14:15:54',NULL),(2347,'Técnico em mecatrônica - robótica',1,2,'2018-08-21 14:15:54',NULL),(2348,'Técnico em métodos eletrográficos em encefalografia',1,2,'2018-08-21 14:15:54',NULL),(2349,'Técnico em métodos gráficos em cardiologia',1,2,'2018-08-21 14:15:54',NULL),(2350,'Técnico em mitilicultura',1,2,'2018-08-21 14:15:54',NULL),(2351,'Técnico em mixagem de áudio',1,2,'2018-08-21 14:15:54',NULL),(2352,'Técnico em museologia',1,2,'2018-08-21 14:15:54',NULL),(2353,'Técnico em nutrição e dietética',1,2,'2018-08-21 14:15:54',NULL),(2354,'Técnico em operação de equipamento de exibição de televisão',1,2,'2018-08-21 14:15:54',NULL),(2355,'Técnico em operação de equipamentos de produção para televisão  e produtoras de vídeo',1,2,'2018-08-21 14:15:54',NULL),(2356,'Técnico em operação de equipamentos de transmissão/recepção de televisão',1,2,'2018-08-21 14:15:54',NULL),(2357,'Técnico em óptica e optometria',1,2,'2018-08-21 14:15:54',NULL),(2358,'Técnico em patologia clínica',1,2,'2018-08-21 14:15:54',NULL),(2359,'Técnico em pecuária',1,2,'2018-08-21 14:15:54',NULL),(2360,'Técnico em pesquisa mineral',1,2,'2018-08-21 14:15:54',NULL),(2361,'Técnico em petroquímica',1,2,'2018-08-21 14:15:54',NULL),(2362,'Técnico em piscicultura',1,2,'2018-08-21 14:15:54',NULL),(2363,'Técnico em planejamento de lavra de minas',1,2,'2018-08-21 14:15:54',NULL),(2364,'Técnico em plástico',1,2,'2018-08-21 14:15:54',NULL),(2365,'Técnico em processamento mineral (exceto petróleo)',1,2,'2018-08-21 14:15:54',NULL),(2366,'Técnico em programação visual',1,2,'2018-08-21 14:15:54',NULL),(2367,'Técnico em quiropraxia',1,2,'2018-08-21 14:15:54',NULL),(2368,'Técnico em radiologia e imagenologia',1,2,'2018-08-21 14:15:54',NULL),(2369,'Técnico em ranicultura',1,2,'2018-08-21 14:15:54',NULL),(2370,'Técnico em saúde bucal',1,2,'2018-08-21 14:15:54',NULL),(2371,'Técnico em saúde bucal da estratégia de saúde da família',1,2,'2018-08-21 14:15:54',NULL),(2372,'Técnico em secretariado',1,2,'2018-08-21 14:15:54',NULL),(2373,'Técnico em segurança do trabalho',1,2,'2018-08-21 14:15:54',NULL),(2374,'Técnico em soldagem',1,2,'2018-08-21 14:15:54',NULL),(2375,'Técnico em sonorização',1,2,'2018-08-21 14:15:54',NULL),(2376,'Técnico em tratamento de efluentes',1,2,'2018-08-21 14:15:54',NULL),(2377,'Técnico em turismo',1,2,'2018-08-21 14:15:54',NULL),(2378,'Técnico florestal',1,2,'2018-08-21 14:15:54',NULL),(2379,'Técnico gráfico',1,2,'2018-08-21 14:15:54',NULL),(2380,'Técnico mecânico',1,2,'2018-08-21 14:15:54',NULL),(2381,'Técnico mecânico (aeronaves)',1,2,'2018-08-21 14:15:54',NULL),(2382,'Técnico mecânico (calefação, ventilação e refrigeração)',1,2,'2018-08-21 14:15:54',NULL),(2383,'Técnico mecânico (embarcações)',1,2,'2018-08-21 14:15:54',NULL),(2384,'Técnico mecânico (máquinas)',1,2,'2018-08-21 14:15:54',NULL),(2385,'Técnico mecânico (motores)',1,2,'2018-08-21 14:15:54',NULL),(2386,'Técnico mecânico na fabricação de ferramentas',1,2,'2018-08-21 14:15:54',NULL),(2387,'Técnico mecânico na manutenção de ferramentas',1,2,'2018-08-21 14:15:54',NULL),(2388,'Técnico operacional de serviços de correios',1,2,'2018-08-21 14:15:54',NULL),(2389,'Técnico químico',1,2,'2018-08-21 14:15:54',NULL),(2390,'Técnico químico de petróleo',1,2,'2018-08-21 14:15:54',NULL),(2391,'Técnico têxtil',1,2,'2018-08-21 14:15:54',NULL),(2392,'Técnico têxtil (tratamentos químicos)',1,2,'2018-08-21 14:15:54',NULL),(2393,'Técnico têxtil de fiação',1,2,'2018-08-21 14:15:54',NULL),(2394,'Técnico têxtil de malharia',1,2,'2018-08-21 14:15:54',NULL),(2395,'Técnico têxtil de tecelagem',1,2,'2018-08-21 14:15:54',NULL),(2396,'Tecnólogo em alimentos',1,2,'2018-08-21 14:15:54',NULL),(2397,'Tecnólogo em automação industrial',1,2,'2018-08-21 14:15:54',NULL),(2398,'Tecnólogo em construção civil',1,2,'2018-08-21 14:15:54',NULL),(2399,'Tecnólogo em eletricidade',1,2,'2018-08-21 14:15:54',NULL),(2400,'Tecnólogo em eletrônica',1,2,'2018-08-21 14:15:54',NULL),(2401,'Tecnólogo em fabricação mecânica',1,2,'2018-08-21 14:15:54',NULL),(2402,'Tecnólogo em gastronomia',1,2,'2018-08-21 14:15:54',NULL),(2403,'Tecnólogo em gestão administrativo- financeira',1,2,'2018-08-21 14:15:54',NULL),(2404,'Tecnólogo em gestão da tecnologia da informação',1,2,'2018-08-21 14:15:54',NULL),(2405,'Tecnólogo em gestão hospitalar',1,2,'2018-08-21 14:15:54',NULL),(2406,'Tecnólogo em logística de transporte',1,2,'2018-08-21 14:15:54',NULL),(2407,'Tecnólogo em mecatrônica',1,2,'2018-08-21 14:15:54',NULL),(2408,'Tecnólogo em meio ambiente',1,2,'2018-08-21 14:15:54',NULL),(2409,'Tecnólogo em metalurgia',1,2,'2018-08-21 14:15:54',NULL),(2410,'Tecnólogo em petróleo e gás',1,2,'2018-08-21 14:15:54',NULL),(2411,'Tecnólogo em processos químicos',1,2,'2018-08-21 14:15:54',NULL),(2412,'Tecnólogo em produção audiovisual',1,2,'2018-08-21 14:15:54',NULL),(2413,'Tecnólogo em produção fonográfica',1,2,'2018-08-21 14:15:54',NULL),(2414,'Tecnólogo em produção industrial',1,2,'2018-08-21 14:15:54',NULL),(2415,'Tecnólogo em produção sulcroalcooleira',1,2,'2018-08-21 14:15:54',NULL),(2416,'Tecnólogo em radiologia',1,2,'2018-08-21 14:15:54',NULL),(2417,'Tecnólogo em rochas ornamentais',1,2,'2018-08-21 14:15:54',NULL),(2418,'Tecnólogo em secretariado escolar',1,2,'2018-08-21 14:15:54',NULL),(2419,'Tecnólogo em segurança do trabalho',1,2,'2018-08-21 14:15:54',NULL),(2420,'Tecnólogo em sistemas biomédicos',1,2,'2018-08-21 14:15:54',NULL),(2421,'Tecnólogo em soldagem',1,2,'2018-08-21 14:15:54',NULL),(2422,'Tecnólogo em telecomunicações',1,2,'2018-08-21 14:15:54',NULL),(2423,'Tecnólogo oftálmico',1,2,'2018-08-21 14:15:54',NULL),(2424,'Telefonista',1,2,'2018-08-21 14:15:54',NULL),(2425,'Teleoperador',1,2,'2018-08-21 14:15:54',NULL),(2426,'Telhador (telhas de argila e materiais similares)',1,2,'2018-08-21 14:15:54',NULL),(2427,'Telhador (telhas de cimento-amianto)',1,2,'2018-08-21 14:15:54',NULL),(2428,'Telhador (telhas metálicas)',1,2,'2018-08-21 14:15:54',NULL),(2429,'Telhador (telhas plásticas)',1,2,'2018-08-21 14:15:54',NULL),(2430,'Temperador de metais e de compósitos',1,2,'2018-08-21 14:15:54',NULL),(2431,'Temperador de vidro',1,2,'2018-08-21 14:15:54',NULL),(2432,'Tenente do corpo de bombeiros militar',1,2,'2018-08-21 14:15:54',NULL),(2433,'Tenente-coronel bombeiro militar',1,2,'2018-08-21 14:15:54',NULL),(2434,'Tenente-coronel da polícia militar',1,2,'2018-08-21 14:15:54',NULL),(2435,'Teólogo',1,2,'2018-08-21 14:15:54',NULL),(2436,'Terapeuta holístico',1,2,'2018-08-21 14:15:54',NULL),(2437,'Terapeuta ocupacional',1,2,'2018-08-21 14:15:54',NULL),(2438,'Tesoureiro de banco',1,2,'2018-08-21 14:15:54',NULL),(2439,'Tingidor de couros e peles',1,2,'2018-08-21 14:15:54',NULL),(2440,'Tingidor de roupas',1,2,'2018-08-21 14:15:54',NULL),(2441,'Tipógrafo',1,2,'2018-08-21 14:15:54',NULL),(2442,'Titeriteiro',1,2,'2018-08-21 14:15:54',NULL),(2443,'Topógrafo',1,2,'2018-08-21 14:15:54',NULL),(2444,'Torneiro (lavra de pedra)',1,2,'2018-08-21 14:15:54',NULL),(2445,'Torneiro na usinagem convencional de madeira',1,2,'2018-08-21 14:15:54',NULL),(2446,'Torrador de cacau',1,2,'2018-08-21 14:15:54',NULL),(2447,'Torrador de café',1,2,'2018-08-21 14:15:54',NULL),(2448,'Torrista (petróleo)',1,2,'2018-08-21 14:15:54',NULL),(2449,'Tosador de animais domésticos',1,2,'2018-08-21 14:15:54',NULL),(2450,'Trabalhador agropecuário em geral',1,2,'2018-08-21 14:15:54',NULL),(2451,'Trabalhador da avicultura de corte',1,2,'2018-08-21 14:15:54',NULL),(2452,'Trabalhador da avicultura de postura',1,2,'2018-08-21 14:15:54',NULL),(2453,'Trabalhador da caprinocultura',1,2,'2018-08-21 14:15:54',NULL),(2454,'Trabalhador da cultura de algodão',1,2,'2018-08-21 14:15:54',NULL),(2455,'Trabalhador da cultura de arroz',1,2,'2018-08-21 14:15:54',NULL),(2456,'Trabalhador da cultura de cacau',1,2,'2018-08-21 14:15:54',NULL),(2457,'Trabalhador da cultura de café',1,2,'2018-08-21 14:15:54',NULL),(2458,'Trabalhador da cultura de cana-de-açúcar',1,2,'2018-08-21 14:15:54',NULL),(2459,'Trabalhador da cultura de erva-mate',1,2,'2018-08-21 14:15:54',NULL),(2460,'Trabalhador da cultura de especiarias',1,2,'2018-08-21 14:15:54',NULL),(2461,'Trabalhador da cultura de fumo',1,2,'2018-08-21 14:15:54',NULL),(2462,'Trabalhador da cultura de guaraná',1,2,'2018-08-21 14:15:54',NULL),(2463,'Trabalhador da cultura de milho e sorgo',1,2,'2018-08-21 14:15:54',NULL),(2464,'Trabalhador da cultura de plantas aromáticas e medicinais',1,2,'2018-08-21 14:15:54',NULL),(2465,'Trabalhador da cultura de sisal',1,2,'2018-08-21 14:15:54',NULL),(2466,'Trabalhador da cultura de trigo, aveia, cevada e triticale',1,2,'2018-08-21 14:15:54',NULL),(2467,'Trabalhador da cultura do rami',1,2,'2018-08-21 14:15:54',NULL),(2468,'Trabalhador da cunicultura',1,2,'2018-08-21 14:15:54',NULL),(2469,'Trabalhador da elaboração de pré-fabricados (cimento amianto)',1,2,'2018-08-21 14:15:54',NULL),(2470,'Trabalhador da elaboração de pré-fabricados (concreto armado)',1,2,'2018-08-21 14:15:54',NULL),(2471,'Trabalhador da exploração de açaí',1,2,'2018-08-21 14:15:54',NULL),(2472,'Trabalhador da exploração de andiroba',1,2,'2018-08-21 14:15:54',NULL),(2473,'Trabalhador da exploração de árvores e arbustos produtores de substâncias aromát., Medic. E tóxicas',1,2,'2018-08-21 14:15:54',NULL),(2474,'Trabalhador da exploração de babaçu',1,2,'2018-08-21 14:15:54',NULL),(2475,'Trabalhador da exploração de bacaba',1,2,'2018-08-21 14:15:54',NULL),(2476,'Trabalhador da exploração de buriti',1,2,'2018-08-21 14:15:54',NULL),(2477,'Trabalhador da exploração de carnaúba',1,2,'2018-08-21 14:15:54',NULL),(2478,'Trabalhador da exploração de castanha',1,2,'2018-08-21 14:15:54',NULL),(2479,'Trabalhador da exploração de cipós produtores de substâncias aromáticas, medicinais e tóxicas',1,2,'2018-08-21 14:15:54',NULL),(2480,'Trabalhador da exploração de coco-da-praia',1,2,'2018-08-21 14:15:54',NULL),(2481,'Trabalhador da exploração de copaíba',1,2,'2018-08-21 14:15:54',NULL),(2482,'Trabalhador da exploração de espécies produtoras de gomas não elásticas',1,2,'2018-08-21 14:15:54',NULL),(2483,'Trabalhador da exploração de madeiras tanantes',1,2,'2018-08-21 14:15:54',NULL),(2484,'Trabalhador da exploração de malva (pãina)',1,2,'2018-08-21 14:15:54',NULL),(2485,'Trabalhador da exploração de murumuru',1,2,'2018-08-21 14:15:54',NULL),(2486,'Trabalhador da exploração de oiticica',1,2,'2018-08-21 14:15:54',NULL),(2487,'Trabalhador da exploração de ouricuri',1,2,'2018-08-21 14:15:54',NULL),(2488,'Trabalhador da exploração de pequi',1,2,'2018-08-21 14:15:54',NULL),(2489,'Trabalhador da exploração de piaçava',1,2,'2018-08-21 14:15:54',NULL),(2490,'Trabalhador da exploração de pinhão',1,2,'2018-08-21 14:15:54',NULL),(2491,'Trabalhador da exploração de pupunha',1,2,'2018-08-21 14:15:54',NULL),(2492,'Trabalhador da exploração de raízes produtoras de substâncias aromáticas, medicinais e tóxicas',1,2,'2018-08-21 14:15:54',NULL),(2493,'Trabalhador da exploração de resinas',1,2,'2018-08-21 14:15:54',NULL),(2494,'Trabalhador da exploração de tucum',1,2,'2018-08-21 14:15:54',NULL),(2495,'Trabalhador da extração de substâncias aromáticas, medicinais e tóxicas, em geral',1,2,'2018-08-21 14:15:54',NULL),(2496,'Trabalhador da fabricação de munição e explosivos',1,2,'2018-08-21 14:15:54',NULL),(2497,'Trabalhador da fabricação de pedras artificiais',1,2,'2018-08-21 14:15:54',NULL),(2498,'Trabalhador da fabricação de resinas e vernizes',1,2,'2018-08-21 14:15:54',NULL),(2499,'Trabalhador da manutenção de edificações',1,2,'2018-08-21 14:15:54',NULL),(2500,'Trabalhador da ovinocultura',1,2,'2018-08-21 14:15:54',NULL),(2501,'Trabalhador da pecuária (asininos e muares)',1,2,'2018-08-21 14:15:54',NULL),(2502,'Trabalhador da pecuária (bovinos corte)',1,2,'2018-08-21 14:15:54',NULL),(2503,'Trabalhador da pecuária (bovinos leite)',1,2,'2018-08-21 14:15:54',NULL),(2504,'Trabalhador da pecuária (bubalinos)',1,2,'2018-08-21 14:15:54',NULL),(2505,'Trabalhador da pecuária (eqüinos)',1,2,'2018-08-21 14:15:54',NULL),(2506,'Trabalhador da suinocultura',1,2,'2018-08-21 14:15:54',NULL),(2507,'Trabalhador de extração florestal, em geral',1,2,'2018-08-21 14:15:54',NULL),(2508,'Trabalhador de fabricação de margarina',1,2,'2018-08-21 14:15:54',NULL),(2509,'Trabalhador de fabricação de sorvete',1,2,'2018-08-21 14:15:54',NULL),(2510,'Trabalhador de fabricação de tintas',1,2,'2018-08-21 14:15:54',NULL),(2511,'Trabalhador de fabricação de vinhos',1,2,'2018-08-21 14:15:54',NULL),(2512,'Trabalhador de pecuária polivalente',1,2,'2018-08-21 14:15:54',NULL),(2513,'Trabalhador de preparação de pescados (limpeza)',1,2,'2018-08-21 14:15:54',NULL),(2514,'Trabalhador de serviços de limpeza e conservação de áreas públicas',1,2,'2018-08-21 14:15:54',NULL),(2515,'Trabalhador de tratamento do leite e fabricação de laticínios e afins',1,2,'2018-08-21 14:15:54',NULL),(2516,'Trabalhador do acabamento de artefatos de tecidos e couros',1,2,'2018-08-21 14:15:54',NULL),(2517,'Trabalhador do beneficiamento de fumo',1,2,'2018-08-21 14:15:54',NULL),(2518,'Trabalhador em criatórios de animais produtores de veneno',1,2,'2018-08-21 14:15:54',NULL),(2519,'Trabalhador na apicultura',1,2,'2018-08-21 14:15:54',NULL),(2520,'Trabalhador na cultura de amendoim',1,2,'2018-08-21 14:15:54',NULL),(2521,'Trabalhador na cultura de canola',1,2,'2018-08-21 14:15:54',NULL),(2522,'Trabalhador na cultura de coco-da-baía',1,2,'2018-08-21 14:15:54',NULL),(2523,'Trabalhador na cultura de dendê',1,2,'2018-08-21 14:15:54',NULL),(2524,'Trabalhador na cultura de mamona',1,2,'2018-08-21 14:15:54',NULL),(2525,'Trabalhador na cultura de soja',1,2,'2018-08-21 14:15:54',NULL),(2526,'Trabalhador na cultura do girassol',1,2,'2018-08-21 14:15:54',NULL),(2527,'Trabalhador na cultura do linho',1,2,'2018-08-21 14:15:54',NULL),(2528,'Trabalhador na fabricação de produtos abrasivos',1,2,'2018-08-21 14:15:54',NULL),(2529,'Trabalhador na minhocultura',1,2,'2018-08-21 14:15:54',NULL),(2530,'Trabalhador na olericultura (frutos e sementes)',1,2,'2018-08-21 14:15:54',NULL),(2531,'Trabalhador na olericultura (legumes)',1,2,'2018-08-21 14:15:54',NULL),(2532,'Trabalhador na olericultura (raízes, bulbos e tubérculos)',1,2,'2018-08-21 14:15:54',NULL),(2533,'Trabalhador na olericultura (talos, folhas e flores)',1,2,'2018-08-21 14:15:54',NULL),(2534,'Trabalhador na operação de sistema de irrigação localizada (microaspersão e gotejamento)',1,2,'2018-08-21 14:15:54',NULL),(2535,'Trabalhador na operação de sistema de irrigação por aspersão (pivô central)',1,2,'2018-08-21 14:15:54',NULL),(2536,'Trabalhador na operação de sistemas convencionais de irrigação por aspersão',1,2,'2018-08-21 14:15:54',NULL),(2537,'Trabalhador na operação de sistemas de irrigação e aspersão (alto propelido)',1,2,'2018-08-21 14:15:54',NULL),(2538,'Trabalhador na operação de sistemas de irrigação por superfície e drenagem',1,2,'2018-08-21 14:15:54',NULL),(2539,'Trabalhador na produção de mudas e sementes',1,2,'2018-08-21 14:15:54',NULL),(2540,'Trabalhador na sericicultura',1,2,'2018-08-21 14:15:54',NULL),(2541,'Trabalhador no cultivo de árvores frutíferas',1,2,'2018-08-21 14:15:54',NULL),(2542,'Trabalhador no cultivo de espécies frutíferas rasteiras',1,2,'2018-08-21 14:15:54',NULL),(2543,'Trabalhador no cultivo de flores e folhagens de corte',1,2,'2018-08-21 14:15:54',NULL),(2544,'Trabalhador no cultivo de flores em vaso',1,2,'2018-08-21 14:15:54',NULL),(2545,'Trabalhador no cultivo de forrações',1,2,'2018-08-21 14:15:54',NULL),(2546,'Trabalhador no cultivo de mudas',1,2,'2018-08-21 14:15:54',NULL),(2547,'Trabalhador no cultivo de plantas ornamentais',1,2,'2018-08-21 14:15:54',NULL),(2548,'Trabalhador no cultivo de trepadeiras frutíferas',1,2,'2018-08-21 14:15:54',NULL),(2549,'Trabalhador polivalente da confecção de calçados',1,2,'2018-08-21 14:15:54',NULL),(2550,'Trabalhador polivalente do curtimento de couros e peles',1,2,'2018-08-21 14:15:54',NULL),(2551,'Trabalhador volante da agricultura',1,2,'2018-08-21 14:15:54',NULL),(2552,'Traçador de pedras',1,2,'2018-08-21 14:15:54',NULL),(2553,'Tradutor',1,2,'2018-08-21 14:15:54',NULL),(2554,'Trançador de cabos de aço',1,2,'2018-08-21 14:15:54',NULL),(2555,'Transformador de tubos de vidro',1,2,'2018-08-21 14:15:54',NULL),(2556,'Trapezista',1,2,'2018-08-21 14:15:54',NULL),(2557,'Tratador de animais',1,2,'2018-08-21 14:15:54',NULL),(2558,'Tratorista agrícola',1,2,'2018-08-21 14:15:54',NULL),(2559,'Trefilador (joalheria e ourivesaria)',1,2,'2018-08-21 14:15:54',NULL),(2560,'Trefilador de borracha',1,2,'2018-08-21 14:15:54',NULL),(2561,'Trefilador de metais, à máquina',1,2,'2018-08-21 14:15:54',NULL),(2562,'Treinador profissional de futebol',1,2,'2018-08-21 14:15:54',NULL),(2563,'Tricoteiro, à mão',1,2,'2018-08-21 14:15:54',NULL),(2564,'Tropeiro',1,2,'2018-08-21 14:15:54',NULL),(2565,'Turismólogo',1,2,'2018-08-21 14:15:54',NULL),(2566,'Urbanista',1,2,'2018-08-21 14:15:54',NULL),(2567,'Vaqueador de couros e peles',1,2,'2018-08-21 14:15:54',NULL),(2568,'Varredor de rua',1,2,'2018-08-21 14:15:54',NULL),(2569,'Vassoureiro',1,2,'2018-08-21 14:15:54',NULL),(2570,'Vendedor  permissionário',1,2,'2018-08-21 14:15:54',NULL),(2571,'Vendedor ambulante',1,2,'2018-08-21 14:15:54',NULL),(2572,'Vendedor de comércio varejista',1,2,'2018-08-21 14:15:54',NULL),(2573,'Vendedor em comércio atacadista',1,2,'2018-08-21 14:15:54',NULL),(2574,'Vendedor em domicílio',1,2,'2018-08-21 14:15:54',NULL),(2575,'Vendedor pracista',1,2,'2018-08-21 14:15:54',NULL),(2576,'Vereador',1,2,'2018-08-21 14:15:54',NULL),(2577,'Vibradorista',1,2,'2018-08-21 14:15:54',NULL),(2578,'Vice-governador de estado',1,2,'2018-08-21 14:15:54',NULL),(2579,'Vice-governador do distrito federal',1,2,'2018-08-21 14:15:54',NULL),(2580,'Vice-prefeito',1,2,'2018-08-21 14:15:54',NULL),(2581,'Vice-presidente da república',1,2,'2018-08-21 14:15:54',NULL),(2582,'Vidraceiro',1,2,'2018-08-21 14:15:54',NULL),(2583,'Vidraceiro (edificações)',1,2,'2018-08-21 14:15:54',NULL),(2584,'Vidraceiro (vitrais)',1,2,'2018-08-21 14:15:54',NULL),(2585,'Vigia',1,2,'2018-08-21 14:15:54',NULL),(2586,'Vigia florestal',1,2,'2018-08-21 14:15:54',NULL),(2587,'Vigia portuário',1,2,'2018-08-21 14:15:54',NULL),(2588,'Vigilante',1,2,'2018-08-21 14:15:54',NULL),(2589,'Vinagreiro',1,2,'2018-08-21 14:15:54',NULL),(2590,'Visitador sanitário',1,2,'2018-08-21 14:15:54',NULL),(2591,'Vistoriador naval',1,2,'2018-08-21 14:15:54',NULL),(2592,'Visual merchandiser',1,2,'2018-08-21 14:15:54',NULL),(2593,'Viveirista florestal',1,2,'2018-08-21 14:15:54',NULL),(2594,'Xaropeiro',1,2,'2018-08-21 14:15:54',NULL),(2595,'Zelador de edifício',1,2,'2018-08-21 14:15:54',NULL),(2596,'Zootecnista',1,2,'2018-08-21 14:15:54',NULL);
/*!40000 ALTER TABLE `apis_occupations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `apis_phone_types`
--

DROP TABLE IF EXISTS `apis_phone_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `apis_phone_types` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL DEFAULT '' COMMENT 'tipo de telefones',
  `status_origin_id` int(11) unsigned NOT NULL DEFAULT '1' COMMENT 'id da origem do status',
  `status_code` int(11) unsigned NOT NULL DEFAULT '1' COMMENT 'status do registro',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'data de criacao',
  `updated` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT 'data de updated',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `fk_mail_phone_status` (`status_origin_id`,`status_code`),
  CONSTRAINT `fk_phone_type_status` FOREIGN KEY (`status_origin_id`, `status_code`) REFERENCES `apis_status` (`status_origin_id`, `status_code`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='Lista de tipos de telefones';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `apis_phone_types`
--

LOCK TABLES `apis_phone_types` WRITE;
/*!40000 ALTER TABLE `apis_phone_types` DISABLE KEYS */;
INSERT INTO `apis_phone_types` VALUES (1,'Celular',1,2,'2018-08-21 21:24:03','2018-08-21 21:24:13');
/*!40000 ALTER TABLE `apis_phone_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `apis_status`
--

DROP TABLE IF EXISTS `apis_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `apis_status` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL COMMENT 'Nome do status',
  `status_origin_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'id da origem do status',
  `status_code` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'id status',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'data criacao',
  `updated` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT 'data da ultima alteracao do registro',
  PRIMARY KEY (`id`),
  KEY `created` (`created`),
  KEY `updated` (`updated`),
  KEY `fk_status_status_origin` (`status_origin_id`,`status_code`),
  CONSTRAINT `fk_status_status_origin` FOREIGN KEY (`status_origin_id`) REFERENCES `apis_status_origins` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='Status do dado';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `apis_status`
--

LOCK TABLES `apis_status` WRITE;
/*!40000 ALTER TABLE `apis_status` DISABLE KEYS */;
INSERT INTO `apis_status` VALUES (1,'Inativo',1,1,'2016-08-04 14:59:30',NULL),(2,'Ativo',1,2,'2016-08-04 14:59:01',NULL),(3,'Deletado',1,3,'2016-08-04 15:00:47',NULL),(4,'Primeiro Acesso',1,4,'2016-08-04 15:03:15',NULL),(5,'Suspenso',1,5,'2016-08-04 18:55:10',NULL),(6,'Revisao',1,6,'2016-08-04 18:57:23',NULL),(7,'Inativo',2,1,'2018-08-16 15:13:32',NULL),(8,'Ativo',2,2,'2018-08-16 15:13:47',NULL),(9,'Deletado',2,3,'2018-08-16 15:14:03',NULL),(10,'Suspenso',2,4,'2018-08-16 15:22:23',NULL),(11,'Revisao',2,5,'2018-08-16 15:22:37',NULL),(12,'Inativo',3,1,'2018-08-16 15:41:41',NULL),(13,'Ativo',3,2,'2018-08-16 15:41:53',NULL),(14,'Deletado',3,3,'2018-08-16 15:42:04',NULL),(15,'Suspenso',3,4,'2018-08-16 15:42:18',NULL),(16,'Revisao',3,5,'2018-08-16 15:42:49',NULL),(17,'Aguardando documentacao',3,6,'2018-08-16 15:43:29',NULL),(18,'Pago',4,1,'2018-08-16 19:36:11',NULL),(19,'Não autorizado',4,2,'2018-08-16 19:36:11',NULL),(20,'Aguardando pagamento',4,3,'2018-08-16 19:36:11',NULL),(21,'Problemas com o cartão',4,5,'2018-08-16 19:36:11',NULL),(22,'Cartão de crédito cancelado',4,6,'2018-08-16 19:36:11',NULL),(23,'Cartão de crédito expirado',4,7,'2018-08-16 19:36:11',NULL),(24,'Cartão de crédito bloqueado',4,8,'2018-08-16 19:36:11',NULL),(25,'Nº de cartão inválido',4,9,'2018-08-16 19:36:11',NULL),(26,'Cancelado',4,10,'2018-08-16 19:36:11',NULL),(27,'Estornado',4,11,'2018-08-16 19:36:11',NULL),(28,'Prazo excedido',4,12,'2018-08-16 19:36:11',NULL),(29,'Timeout',4,13,'2018-08-16 19:36:11',NULL),(30,'Erro no gateway',4,14,'2018-08-16 19:36:11',NULL),(31,'Não finalizado',4,15,'2018-08-16 19:36:11',NULL),(33,'Inativo',5,1,'2018-08-20 20:55:34',NULL),(34,'Ativo',5,2,'2018-08-20 20:55:34',NULL),(35,'Deletado',5,3,'2018-08-20 20:55:34',NULL),(36,'Primeiro Acesso',5,4,'2018-08-20 20:55:34',NULL),(37,'Suspenso',5,5,'2018-08-20 20:55:34',NULL),(38,'Revisao',5,6,'2018-08-20 20:55:34',NULL),(40,'Cancelado',2,6,'2018-08-20 21:46:17',NULL),(41,'Em processamento',6,1,'2018-08-20 22:34:02',NULL),(42,'Aguardando pagamento',6,2,'2018-08-20 22:34:28',NULL),(43,'Aguardando confirmação do pagamento',6,3,'2018-08-20 22:36:13',NULL),(44,'Pagamento autorizado',6,4,'2018-08-20 22:40:54',NULL),(45,'Pagamento não autorizado',6,5,'2018-08-20 22:42:01',NULL),(46,'Falha na recorrência',6,6,'2018-08-20 22:42:56',NULL),(47,'Expirado',6,7,'2018-08-20 22:45:48',NULL),(48,'Cancelado',6,8,'2018-08-20 22:48:29',NULL),(49,'Pagamento em análise',4,4,'2018-09-05 23:08:46',NULL),(50,'Pagamento atrasado',4,16,'2018-09-05 23:16:11',NULL),(51,'Boleto impresso',4,17,'2018-09-06 13:29:29',NULL),(52,'Reembolsado',4,18,'2018-09-06 13:35:40',NULL),(53,'Aguardando pagamento do boleto',4,19,'2018-09-06 13:37:49',NULL);
/*!40000 ALTER TABLE `apis_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `apis_status_origins`
--

DROP TABLE IF EXISTS `apis_status_origins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `apis_status_origins` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(30) DEFAULT NULL COMMENT 'Nome da origem',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'data criacao',
  `updated` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT 'data da ultima alteracao do registro',
  PRIMARY KEY (`id`),
  KEY `created` (`created`),
  KEY `updated` (`updated`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='Origem do status';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `apis_status_origins`
--

LOCK TABLES `apis_status_origins` WRITE;
/*!40000 ALTER TABLE `apis_status_origins` DISABLE KEYS */;
INSERT INTO `apis_status_origins` VALUES (1,'Sistema','2018-08-13 19:48:29',NULL),(2,'Produto','2018-08-16 15:11:14',NULL),(3,'Marca','2018-08-16 15:40:55',NULL),(4,'Pagamento','2018-08-16 18:30:05',NULL),(5,'Cliente','2018-08-20 20:52:11',NULL),(6,'Order','2018-08-20 22:32:45',NULL);
/*!40000 ALTER TABLE `apis_status_origins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `apis_users`
--

DROP TABLE IF EXISTS `apis_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `apis_users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'id do pai',
  `icon_id` int(11) unsigned NOT NULL DEFAULT '1' COMMENT 'id do icone',
  `name` varchar(80) DEFAULT NULL COMMENT 'nome',
  `last_name` varchar(80) DEFAULT NULL COMMENT 'sobrenome',
  `mail` varchar(80) NOT NULL DEFAULT '' COMMENT 'login',
  `rg` varchar(11) DEFAULT NULL COMMENT 'rg do usuario',
  `cpf` varchar(11) DEFAULT NULL COMMENT 'cpf tambem pode ser usado para login',
  `username` varchar(80) NOT NULL DEFAULT '' COMMENT 'nome do usuario',
  `password` char(32) NOT NULL DEFAULT '' COMMENT 'senha',
  `token` varchar(32) DEFAULT NULL COMMENT 'token para autenticacao via sistema',
  `expire` timestamp NULL DEFAULT NULL COMMENT 'tempo de valide do token',
  `status_origin_id` int(11) unsigned NOT NULL DEFAULT '1' COMMENT 'id da origem do status',
  `status_code` int(11) unsigned NOT NULL DEFAULT '1' COMMENT 'status do registro',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'data da criacao',
  `updated` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT 'data da ultima alteracao do registro',
  PRIMARY KEY (`id`),
  KEY `fk_users_status` (`status_origin_id`,`status_code`),
  KEY `parent_id` (`parent_id`),
  KEY `icon_id` (`icon_id`),
  KEY `nome` (`name`),
  KEY `mail` (`mail`),
  KEY `cpf` (`cpf`),
  KEY `username` (`username`),
  KEY `token` (`token`),
  KEY `expire` (`expire`),
  KEY `created` (`created`),
  KEY `updated` (`updated`),
  CONSTRAINT `fk_users_status` FOREIGN KEY (`status_origin_id`, `status_code`) REFERENCES `apis_status` (`status_origin_id`, `status_code`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='Tabela de usuario do sistema';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `apis_users`
--

LOCK TABLES `apis_users` WRITE;
/*!40000 ALTER TABLE `apis_users` DISABLE KEYS */;
INSERT INTO `apis_users` VALUES (1,0,1,'Administrator','System','infra@digi5.com.br','268077046','25383793820','infra@digi5.com.br','a70e6a1f1516839a2ead394315cde4fe','17faf3424aae6b95f5ad13f9b77383ee','2018-09-17 19:40:06',1,2,'2018-08-13 19:51:13','2018-09-16 19:40:07'),(2,0,1,'Vida','Class','ti@vidaclass.com.br',NULL,NULL,'ti@vidaclass.com.br','fb6c2a74f9e7952aa4aaa7540299810d','589f0408e45e887ac0abf55cb19f25f7','2018-09-17 19:47:45',1,2,'2018-09-10 17:29:56','2018-09-16 19:47:45');
/*!40000 ALTER TABLE `apis_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cli_customer_documents`
--

DROP TABLE IF EXISTS `cli_customer_documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cli_customer_documents` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT 'id do cliente',
  `document_type_id` int(11) unsigned NOT NULL DEFAULT '1' COMMENT '1 = RG',
  `document_emitter_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'id do emissor',
  `issue_date` date NOT NULL DEFAULT '0000-00-00' COMMENT 'data de emissao',
  `number` varchar(30) NOT NULL DEFAULT '' COMMENT 'numero do documento',
  `status_origin_id` int(11) unsigned NOT NULL DEFAULT '5' COMMENT 'id da origem do status',
  `status_code` int(11) unsigned NOT NULL DEFAULT '1' COMMENT 'status do registro',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'data de criacao',
  `updated` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT 'data de updated',
  PRIMARY KEY (`id`),
  KEY `document_number` (`number`),
  KEY `document_type` (`document_type_id`),
  KEY `fk_customer_document_status` (`status_origin_id`,`status_code`),
  KEY `customer_id` (`customer_id`) USING BTREE,
  KEY `fk_customer_document_document_emitters` (`document_emitter_id`),
  CONSTRAINT `fk_customer_document_customer` FOREIGN KEY (`customer_id`) REFERENCES `cli_customers` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_customer_document_document_emitters` FOREIGN KEY (`document_emitter_id`) REFERENCES `apis_document_emitters` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_customer_document_document_types` FOREIGN KEY (`document_type_id`) REFERENCES `apis_document_types` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_customer_document_status` FOREIGN KEY (`status_origin_id`, `status_code`) REFERENCES `apis_status` (`status_origin_id`, `status_code`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='documentos do cliente';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cli_customer_documents`
--

LOCK TABLES `cli_customer_documents` WRITE;
/*!40000 ALTER TABLE `cli_customer_documents` DISABLE KEYS */;
/*!40000 ALTER TABLE `cli_customer_documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cli_customer_mails`
--

DROP TABLE IF EXISTS `cli_customer_mails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cli_customer_mails` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT 'id do cliente',
  `mail_type_id` int(11) unsigned NOT NULL DEFAULT '1' COMMENT '1 = pessoal',
  `mail` varchar(80) NOT NULL DEFAULT '' COMMENT 'email',
  `status_origin_id` int(11) unsigned NOT NULL DEFAULT '5' COMMENT 'id da origem do status',
  `status_code` int(11) unsigned NOT NULL DEFAULT '1' COMMENT 'status do registro',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'data de criacao',
  `updated` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT 'data de updated',
  PRIMARY KEY (`id`),
  UNIQUE KEY `mail` (`mail`),
  KEY `mail_type` (`mail_type_id`),
  KEY `fk_customer_mail_status` (`status_origin_id`,`status_code`),
  KEY `customer_id` (`customer_id`) USING BTREE,
  CONSTRAINT `fk_customer_mail` FOREIGN KEY (`customer_id`) REFERENCES `cli_customers` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_customer_mail_status` FOREIGN KEY (`status_origin_id`, `status_code`) REFERENCES `apis_status` (`status_origin_id`, `status_code`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_customer_mails_mail_mail_types` FOREIGN KEY (`mail_type_id`) REFERENCES `apis_mail_types` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='email do cliente';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cli_customer_mails`
--

LOCK TABLES `cli_customer_mails` WRITE;
/*!40000 ALTER TABLE `cli_customer_mails` DISABLE KEYS */;
/*!40000 ALTER TABLE `cli_customer_mails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cli_customer_phones`
--

DROP TABLE IF EXISTS `cli_customer_phones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cli_customer_phones` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT 'id do cliente',
  `phone_type_id` int(11) unsigned NOT NULL DEFAULT '1' COMMENT '1 = celular, 2 = fixo',
  `phone` char(11) NOT NULL DEFAULT '' COMMENT 'telefone do cliente',
  `status_origin_id` int(11) unsigned NOT NULL DEFAULT '5' COMMENT 'id da origem do status',
  `status_code` int(11) unsigned NOT NULL DEFAULT '1' COMMENT 'status do registro',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'data de criacao',
  `updated` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT 'data de updated',
  PRIMARY KEY (`id`),
  KEY `phone` (`phone`),
  KEY `customer_id` (`customer_id`) USING BTREE,
  KEY `fk_customer_phone_status` (`status_origin_id`,`status_code`) USING BTREE,
  KEY `phone_type_id` (`phone_type_id`),
  CONSTRAINT `fk_customer_phone` FOREIGN KEY (`customer_id`) REFERENCES `cli_customers` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_customer_phone_phone_types` FOREIGN KEY (`phone_type_id`) REFERENCES `apis_phone_types` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_customer_phone_status` FOREIGN KEY (`status_origin_id`, `status_code`) REFERENCES `apis_status` (`status_origin_id`, `status_code`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='phone do cliente';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cli_customer_phones`
--

LOCK TABLES `cli_customer_phones` WRITE;
/*!40000 ALTER TABLE `cli_customer_phones` DISABLE KEYS */;
/*!40000 ALTER TABLE `cli_customer_phones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cli_customers`
--

DROP TABLE IF EXISTS `cli_customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cli_customers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL DEFAULT '' COMMENT 'nome do cliente',
  `gender` char(1) NOT NULL DEFAULT '' COMMENT 'sexo',
  `cpf` char(12) NOT NULL DEFAULT '' COMMENT 'cpf',
  `password` char(32) NOT NULL DEFAULT '' COMMENT 'senha',
  `estimated_assets` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT 'valor estimado do bens',
  `monthly_income` decimal(10,2) unsigned NOT NULL DEFAULT '0.00' COMMENT 'renda mensal',
  `politycal_exposure` bit(1) NOT NULL DEFAULT b'0' COMMENT 'politicamente exposto',
  `birth` date NOT NULL DEFAULT '0000-00-00' COMMENT 'data de nascimento',
  `occupation_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'profissao',
  `marital_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'id do estado civil',
  `status_origin_id` int(11) unsigned NOT NULL DEFAULT '5' COMMENT 'id da origem do status',
  `status_code` int(11) unsigned NOT NULL DEFAULT '1' COMMENT 'status do registro',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'data de criacao',
  `updated` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT 'data de updated',
  PRIMARY KEY (`id`),
  UNIQUE KEY `cpf` (`cpf`),
  KEY `name` (`name`),
  KEY `birth` (`birth`),
  KEY `fk_customers_status` (`status_origin_id`,`status_code`),
  KEY `gender` (`gender`),
  KEY `fk_customers_occupations` (`occupation_id`),
  KEY `fk_customers_maritals` (`marital_id`),
  KEY `politycal_exposure` (`politycal_exposure`),
  CONSTRAINT `fk_customers_maritals` FOREIGN KEY (`marital_id`) REFERENCES `apis_maritals` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_customers_occupations` FOREIGN KEY (`occupation_id`) REFERENCES `apis_occupations` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_customers_status` FOREIGN KEY (`status_origin_id`, `status_code`) REFERENCES `apis_status` (`status_origin_id`, `status_code`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Cadastro do Clientes';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cli_customers`
--

LOCK TABLES `cli_customers` WRITE;
/*!40000 ALTER TABLE `cli_customers` DISABLE KEYS */;
/*!40000 ALTER TABLE `cli_customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cli_order_credit_card_actives`
--

DROP TABLE IF EXISTS `cli_order_credit_card_actives`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cli_order_credit_card_actives` (
  `id` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT 'id da order',
  `gateway_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'id do gateway ultimo pagamento',
  `credit_card_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT 'id do cartao ativo',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'data de criacao',
  PRIMARY KEY (`id`),
  KEY `fk_cli_order_credit_card_active_orders` (`order_id`),
  KEY `fk_cli_order_credit_card_active_credit_card` (`credit_card_id`),
  KEY `fk_cli_order_credit_card_active_gateway` (`gateway_id`),
  CONSTRAINT `fk_cli_order_credit_card_active_credit_card` FOREIGN KEY (`credit_card_id`) REFERENCES `apis_credit_card` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_cli_order_credit_card_active_gateway` FOREIGN KEY (`gateway_id`) REFERENCES `pay_gateways` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_cli_order_credit_card_active_orders` FOREIGN KEY (`order_id`) REFERENCES `cli_orders` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Cartao ativo na order';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cli_order_credit_card_actives`
--

LOCK TABLES `cli_order_credit_card_actives` WRITE;
/*!40000 ALTER TABLE `cli_order_credit_card_actives` DISABLE KEYS */;
/*!40000 ALTER TABLE `cli_order_credit_card_actives` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cli_order_itens`
--

DROP TABLE IF EXISTS `cli_order_itens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cli_order_itens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT 'id da order',
  `product_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'id do produto',
  `qtd` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'quantidade do produto',
  `value_uni` decimal(10,2) unsigned NOT NULL DEFAULT '0.00' COMMENT 'valor do produto',
  `value_total` decimal(10,2) unsigned NOT NULL DEFAULT '0.00' COMMENT 'valor total',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'data de criacao',
  `updated` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT 'data de updated',
  PRIMARY KEY (`id`),
  KEY `fk_order_itens_orders` (`order_id`),
  KEY `fk_order_itens_products` (`product_id`),
  CONSTRAINT `fk_order_itens_orders` FOREIGN KEY (`order_id`) REFERENCES `cli_orders` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_order_itens_products` FOREIGN KEY (`product_id`) REFERENCES `for_products` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='produtos da order';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cli_order_itens`
--

LOCK TABLES `cli_order_itens` WRITE;
/*!40000 ALTER TABLE `cli_order_itens` DISABLE KEYS */;
/*!40000 ALTER TABLE `cli_order_itens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cli_orders`
--

DROP TABLE IF EXISTS `cli_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cli_orders` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'id a companhia',
  `external_code` varchar(40) DEFAULT NULL COMMENT 'codigo externo se houver',
  `customer_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT 'id do cliente',
  `value` decimal(10,2) unsigned NOT NULL DEFAULT '0.00' COMMENT 'id do produto',
  `beginning` date DEFAULT NULL COMMENT 'data inicio de vigencia',
  `expiration` date DEFAULT NULL COMMENT 'data de expiracao',
  `due_monthly` date DEFAULT NULL COMMENT 'data do proximo vencimento',
  `status_origin_id` int(11) unsigned NOT NULL DEFAULT '6' COMMENT 'id da origem do status',
  `status_code` int(11) unsigned NOT NULL DEFAULT '1' COMMENT 'status do registro',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'data de criacao',
  `updated` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT 'data de updated',
  PRIMARY KEY (`id`),
  UNIQUE KEY `external_key` (`company_id`,`external_code`),
  KEY `external_code` (`external_code`),
  KEY `fk_order_customers` (`customer_id`),
  KEY `beginning` (`beginning`),
  KEY `expiration` (`expiration`),
  KEY `due_monthly` (`due_monthly`),
  CONSTRAINT `fk_order_company` FOREIGN KEY (`company_id`) REFERENCES `apis_companys` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_order_customers` FOREIGN KEY (`customer_id`) REFERENCES `cli_customers` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='ordem de compra';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cli_orders`
--

LOCK TABLES `cli_orders` WRITE;
/*!40000 ALTER TABLE `cli_orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `cli_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `for_brands`
--

DROP TABLE IF EXISTS `for_brands`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `for_brands` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `cnpj` varchar(15) NOT NULL DEFAULT '' COMMENT 'cnpj da marca',
  `company` varchar(80) NOT NULL DEFAULT '' COMMENT 'razao social',
  `trade` varchar(80) NOT NULL DEFAULT '' COMMENT 'nome fantasia',
  `name` varchar(80) NOT NULL DEFAULT '' COMMENT 'nome da marca',
  `status_origin_id` int(11) unsigned NOT NULL DEFAULT '3' COMMENT 'id da origem do status',
  `status_code` int(11) unsigned NOT NULL DEFAULT '1' COMMENT 'status do registro',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'data de criacao',
  `updated` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT 'data de updated',
  PRIMARY KEY (`id`),
  KEY `status_origin_id` (`status_origin_id`),
  KEY `status_code` (`status_code`),
  KEY `created` (`created`),
  KEY `update` (`updated`),
  KEY `cnpj` (`cnpj`),
  KEY `fk_brands_status` (`status_origin_id`,`status_code`),
  CONSTRAINT `fk_brands_status` FOREIGN KEY (`status_origin_id`, `status_code`) REFERENCES `apis_status` (`status_origin_id`, `status_code`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='Marcas - Fornecedores';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `for_brands`
--

LOCK TABLES `for_brands` WRITE;
/*!40000 ALTER TABLE `for_brands` DISABLE KEYS */;
INSERT INTO `for_brands` VALUES (1,'6107417500138','Mapfre Seguros SA.','Mapfre Seguros','Mapfre Seguros',3,2,'2018-08-16 15:44:05',NULL);
/*!40000 ALTER TABLE `for_brands` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `for_product_pay_methods`
--

DROP TABLE IF EXISTS `for_product_pay_methods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `for_product_pay_methods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) unsigned NOT NULL DEFAULT '0',
  `method_id` int(11) unsigned NOT NULL DEFAULT '0',
  `status_origin_id` int(11) unsigned NOT NULL DEFAULT '2' COMMENT 'id da origem do status',
  `status_code` int(11) unsigned NOT NULL DEFAULT '1' COMMENT 'status do registro',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'data de criacao',
  `updated` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT 'data de updated',
  PRIMARY KEY (`id`),
  KEY `fk_status_origin_id_status` (`status_origin_id`,`status_code`),
  KEY `fk_status_origin_id_product` (`product_id`),
  CONSTRAINT `fk_status_origin_id_method` FOREIGN KEY (`status_origin_id`) REFERENCES `pay_methods` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_status_origin_id_product` FOREIGN KEY (`product_id`) REFERENCES `for_products` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_status_origin_id_status` FOREIGN KEY (`status_origin_id`, `status_code`) REFERENCES `apis_status` (`status_origin_id`, `status_code`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COMMENT='Metodos de pagamento para o produto';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `for_product_pay_methods`
--

LOCK TABLES `for_product_pay_methods` WRITE;
/*!40000 ALTER TABLE `for_product_pay_methods` DISABLE KEYS */;
INSERT INTO `for_product_pay_methods` VALUES (1,1,2,2,2,'2018-08-17 13:34:11',NULL),(2,2,2,2,2,'2018-08-17 13:35:22',NULL),(3,3,2,2,2,'2018-08-17 13:35:29',NULL),(4,4,2,2,2,'2018-08-17 13:35:39',NULL),(5,5,2,2,2,'2018-08-17 13:35:51',NULL),(6,6,2,2,2,'2018-08-17 13:36:14',NULL);
/*!40000 ALTER TABLE `for_product_pay_methods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `for_product_type_brands`
--

DROP TABLE IF EXISTS `for_product_type_brands`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `for_product_type_brands` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `brand_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'marca do produto',
  `product_type_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'id do tipo de produto',
  `status_origin_id` int(11) unsigned NOT NULL DEFAULT '2' COMMENT 'id da origem do status',
  `status_code` int(11) unsigned NOT NULL DEFAULT '1' COMMENT 'status do registro',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'data de criacao',
  `updated` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT 'data de updated',
  PRIMARY KEY (`id`),
  KEY `brand_id` (`brand_id`),
  KEY `name` (`product_type_id`),
  KEY `fk_product_type_brands_status` (`status_origin_id`,`status_code`),
  KEY `produtc_type_brand_key` (`product_type_id`,`brand_id`),
  CONSTRAINT `fk_product_type_brands_brands` FOREIGN KEY (`brand_id`) REFERENCES `for_brands` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_product_type_brands_product_types` FOREIGN KEY (`product_type_id`) REFERENCES `for_product_types` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_product_type_brands_status` FOREIGN KEY (`status_origin_id`, `status_code`) REFERENCES `apis_status` (`status_origin_id`, `status_code`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='Tipos de produtos';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `for_product_type_brands`
--

LOCK TABLES `for_product_type_brands` WRITE;
/*!40000 ALTER TABLE `for_product_type_brands` DISABLE KEYS */;
INSERT INTO `for_product_type_brands` VALUES (1,1,1,2,2,'2018-08-16 15:10:26','2018-09-13 19:24:33');
/*!40000 ALTER TABLE `for_product_type_brands` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `for_product_type_police_order_itens`
--

DROP TABLE IF EXISTS `for_product_type_police_order_itens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `for_product_type_police_order_itens` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `product_type_brand_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'id tipo de produto',
  `customer_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT 'id do cliente',
  `order_item_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT 'numero da ordem item',
  `police` varchar(10) NOT NULL DEFAULT '' COMMENT 'numero da apolice',
  `status_origin_id` int(11) unsigned NOT NULL DEFAULT '2' COMMENT 'id da origem do status',
  `status_code` int(11) unsigned NOT NULL DEFAULT '1' COMMENT 'status do registro',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'data de criacao',
  `updated` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT 'data de updated',
  PRIMARY KEY (`id`),
  UNIQUE KEY `police_key` (`product_type_brand_id`,`police`),
  KEY `fk_product_type_police_order_status` (`status_origin_id`,`status_code`),
  KEY `police` (`police`),
  KEY `fk_product_type_police_order_itens_order_itens` (`order_item_id`),
  KEY `fk_for_product_type_police_order_itens_customer` (`customer_id`),
  CONSTRAINT `fk_for_product_type_police_order_itens_customer` FOREIGN KEY (`customer_id`) REFERENCES `cli_customers` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_product_type_police_order_itens_order_itens` FOREIGN KEY (`order_item_id`) REFERENCES `cli_order_itens` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_product_type_police_order_product_type` FOREIGN KEY (`product_type_brand_id`) REFERENCES `for_product_type_brands` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_product_type_police_order_status` FOREIGN KEY (`status_origin_id`, `status_code`) REFERENCES `apis_status` (`status_origin_id`, `status_code`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Apolices da marca';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `for_product_type_police_order_itens`
--

LOCK TABLES `for_product_type_police_order_itens` WRITE;
/*!40000 ALTER TABLE `for_product_type_police_order_itens` DISABLE KEYS */;
/*!40000 ALTER TABLE `for_product_type_police_order_itens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `for_product_types`
--

DROP TABLE IF EXISTS `for_product_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `for_product_types` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(60) NOT NULL DEFAULT '' COMMENT 'nome do tipo de produto',
  `status_origin_id` int(11) unsigned NOT NULL DEFAULT '2' COMMENT 'id da origem do status',
  `status_code` int(11) unsigned NOT NULL DEFAULT '1' COMMENT 'status do registro',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'data de criacao',
  `updated` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT 'data de updated',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `fk_product_types_status` (`status_origin_id`,`status_code`),
  CONSTRAINT `fk_product_types_status` FOREIGN KEY (`status_origin_id`, `status_code`) REFERENCES `apis_status` (`status_origin_id`, `status_code`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='Tipos de produtos';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `for_product_types`
--

LOCK TABLES `for_product_types` WRITE;
/*!40000 ALTER TABLE `for_product_types` DISABLE KEYS */;
INSERT INTO `for_product_types` VALUES (1,'Seguro Internação',2,2,'2018-08-28 18:36:05',NULL);
/*!40000 ALTER TABLE `for_product_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `for_products`
--

DROP TABLE IF EXISTS `for_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `for_products` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `product_type_brand_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'id tipo do produto',
  `external_code` varchar(40) DEFAULT '' COMMENT 'codigo externo caso tenha',
  `name` varchar(120) NOT NULL DEFAULT '' COMMENT 'nome do produto',
  `description` varchar(255) NOT NULL DEFAULT '' COMMENT 'descricao do produto',
  `disclaimer` varchar(255) NOT NULL DEFAULT '' COMMENT 'regras legais',
  `susep_code` varchar(255) DEFAULT NULL COMMENT 'codigo da susep se houver',
  `value` decimal(10,2) unsigned NOT NULL DEFAULT '0.00' COMMENT 'valor do produto',
  `installments` int(3) unsigned NOT NULL DEFAULT '0' COMMENT 'numero de parcelas',
  `valid_period_days` int(11) NOT NULL DEFAULT '0' COMMENT 'dias de validade',
  `status_origin_id` int(11) unsigned NOT NULL DEFAULT '2' COMMENT 'id da origem do status',
  `status_code` int(11) unsigned NOT NULL DEFAULT '1' COMMENT 'status do registro',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'data de criacao',
  `updated` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT 'data de updated',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `created` (`created`),
  KEY `updated` (`updated`),
  KEY `external_code` (`external_code`),
  KEY `fk_products_status` (`status_origin_id`,`status_code`),
  KEY `fk_products_product_type_brands` (`product_type_brand_id`),
  CONSTRAINT `fk_products_product_type_brands` FOREIGN KEY (`product_type_brand_id`) REFERENCES `for_product_type_brands` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_products_status` FOREIGN KEY (`status_origin_id`, `status_code`) REFERENCES `apis_status` (`status_origin_id`, `status_code`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COMMENT='Lista de produtos Mapfre';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `for_products`
--

LOCK TABLES `for_products` WRITE;
/*!40000 ALTER TABLE `for_products` DISABLE KEYS */;
INSERT INTO `for_products` VALUES (1,1,'','Vida Class Internação Ideal','10 diárias de internação limitadas ao valor de R$ 1.000,00 / dia','','06238',36.50,12,365,2,2,'2018-08-16 15:24:23','2018-09-08 19:52:22'),(2,1,'','Vida Class Internação Essencial','10 diárias de internação limitadas ao valor de R$ 500,00 / dia','','06238',27.50,12,365,2,2,'2018-08-16 15:27:11','2018-09-08 19:52:27'),(3,1,'','Vida Class Internação POP','10 diárias de internação limitadas ao valor de R$ 250,00 / dia','','06238',19.50,12,365,2,2,'2018-08-16 15:28:20',NULL),(4,1,'','Vida Class Internação Sênior Ideal','10 diárias de internação limitadas ao valor de R$ 1.000,00 / dia','','06238',59.90,12,365,2,2,'2018-08-16 15:53:23',NULL),(5,1,'','Vida Class Internação Sênior Essencial','10 diárias de internação limitadas ao valor de R$ 500,00 / dia','','06238',39.90,12,365,2,2,'2018-08-16 15:54:15',NULL),(6,1,'','Vida Class Internação Sênior POP','10 diárias de internação limitadas ao valor de R$ 250,00/dia','','06238',25.00,12,365,2,2,'2018-08-16 15:57:16',NULL);
/*!40000 ALTER TABLE `for_products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_banks`
--

DROP TABLE IF EXISTS `pay_banks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay_banks` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL DEFAULT '' COMMENT 'nome do banco',
  `status_origin_id` int(11) unsigned NOT NULL DEFAULT '4' COMMENT 'id da origem do status',
  `status_code` int(11) unsigned NOT NULL DEFAULT '1' COMMENT 'status do registro',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'data de criacao',
  `updated` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT 'data de updated',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='Lista de Bancos';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_banks`
--

LOCK TABLES `pay_banks` WRITE;
/*!40000 ALTER TABLE `pay_banks` DISABLE KEYS */;
INSERT INTO `pay_banks` VALUES (1,'Itau',4,2,'2018-08-16 22:20:37',NULL);
/*!40000 ALTER TABLE `pay_banks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_card_brands`
--

DROP TABLE IF EXISTS `pay_card_brands`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay_card_brands` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `order_list` int(11) unsigned DEFAULT NULL,
  `name` varchar(30) DEFAULT NULL,
  `name_view` varchar(30) NOT NULL DEFAULT '' COMMENT 'nome da bandeira do cartao',
  `status_origin_id` int(11) unsigned NOT NULL DEFAULT '4' COMMENT 'id da origem do status',
  `status_code` int(11) unsigned NOT NULL DEFAULT '1' COMMENT 'status do registro',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'data de criacao',
  `updated` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT 'data de updated',
  PRIMARY KEY (`id`),
  KEY `fk_card_brands_status` (`status_origin_id`,`status_code`),
  KEY `created` (`created`),
  KEY `updated` (`updated`),
  KEY `order_list` (`order_list`),
  KEY `name` (`name`),
  CONSTRAINT `fk_card_brands_status` FOREIGN KEY (`status_origin_id`, `status_code`) REFERENCES `apis_status` (`status_origin_id`, `status_code`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COMMENT='Bandeiras disponiveis';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_card_brands`
--

LOCK TABLES `pay_card_brands` WRITE;
/*!40000 ALTER TABLE `pay_card_brands` DISABLE KEYS */;
INSERT INTO `pay_card_brands` VALUES (1,5,'diners','Diners',4,2,'2018-08-16 21:45:52',NULL),(2,9,'discover','Discover',4,2,'2018-08-16 21:45:52',NULL),(3,4,'elo','Elo',4,2,'2018-08-16 21:45:52',NULL),(4,8,'enroute','enRoute',4,2,'2018-08-16 21:45:52',NULL),(5,7,'jcb','JCB',4,2,'2018-08-16 21:45:52',NULL),(6,1,'mastercard','MasterCard',4,2,'2018-08-16 21:45:52',NULL),(7,2,'visa','Visa',4,2,'2018-08-16 21:45:52',NULL),(8,6,'voyager','Voyager',4,2,'2018-08-16 21:45:52',NULL),(9,3,'amex','American Express',4,2,'2018-08-20 14:50:58',NULL),(10,10,'aura','Aura',4,2,'2018-08-20 19:09:39',NULL);
/*!40000 ALTER TABLE `pay_card_brands` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_gateway_card_brands`
--

DROP TABLE IF EXISTS `pay_gateway_card_brands`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay_gateway_card_brands` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `gateway_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'id do gateway',
  `card_brand_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'id da bandeiro do cartao',
  `status_origin_id` int(11) unsigned NOT NULL DEFAULT '4' COMMENT 'id da origem do status',
  `status_code` int(11) unsigned NOT NULL DEFAULT '1' COMMENT 'status do registro',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'data de criacao',
  `updated` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT 'data de updated',
  PRIMARY KEY (`id`),
  KEY `fk_gateway_card_brands_status` (`status_origin_id`,`status_code`),
  KEY `fk_gateway_card_brands_gateway` (`gateway_id`),
  KEY `fk_gateway_card_brands_card_brand` (`card_brand_id`),
  CONSTRAINT `fk_gateway_card_brands_card_brand` FOREIGN KEY (`card_brand_id`) REFERENCES `pay_card_brands` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_gateway_card_brands_gateway` FOREIGN KEY (`gateway_id`) REFERENCES `pay_gateways` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_gateway_card_brands_status` FOREIGN KEY (`status_origin_id`, `status_code`) REFERENCES `apis_status` (`status_origin_id`, `status_code`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COMMENT='cartoes que o gateway aceita';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_gateway_card_brands`
--

LOCK TABLES `pay_gateway_card_brands` WRITE;
/*!40000 ALTER TABLE `pay_gateway_card_brands` DISABLE KEYS */;
INSERT INTO `pay_gateway_card_brands` VALUES (1,2,1,4,2,'2018-08-16 21:57:32',NULL),(2,2,2,4,2,'2018-08-16 22:00:17',NULL),(3,2,3,4,2,'2018-08-16 22:01:43',NULL),(4,2,6,4,2,'2018-08-16 22:03:01',NULL),(5,2,7,4,2,'2018-08-16 22:03:18',NULL),(6,2,9,4,2,'2018-08-20 14:53:34',NULL),(7,2,10,4,2,'2018-08-20 19:10:45',NULL);
/*!40000 ALTER TABLE `pay_gateway_card_brands` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_gateway_debit_banks`
--

DROP TABLE IF EXISTS `pay_gateway_debit_banks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay_gateway_debit_banks` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `gateway_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'id do gateway',
  `bank_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'id do banco',
  `status_origin_id` int(11) unsigned NOT NULL DEFAULT '4' COMMENT 'id da origem do status',
  `status_code` int(11) unsigned NOT NULL DEFAULT '1' COMMENT 'status do registro',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'data de criacao',
  `updated` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT 'data de updated',
  PRIMARY KEY (`id`),
  KEY `fk_gateway_debit_banks_bank` (`bank_id`),
  KEY `fk_gateway_debit_banks_gateway` (`gateway_id`),
  KEY `fk_gateway_debit_banks_status` (`status_origin_id`,`status_code`),
  CONSTRAINT `fk_gateway_debit_banks_bank` FOREIGN KEY (`bank_id`) REFERENCES `pay_banks` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_gateway_debit_banks_gateway` FOREIGN KEY (`gateway_id`) REFERENCES `pay_gateways` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_gateway_debit_banks_status` FOREIGN KEY (`status_origin_id`, `status_code`) REFERENCES `apis_status` (`status_origin_id`, `status_code`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='gateway faz debitos em quais bancos';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_gateway_debit_banks`
--

LOCK TABLES `pay_gateway_debit_banks` WRITE;
/*!40000 ALTER TABLE `pay_gateway_debit_banks` DISABLE KEYS */;
INSERT INTO `pay_gateway_debit_banks` VALUES (1,2,1,4,2,'2018-08-16 22:53:04',NULL);
/*!40000 ALTER TABLE `pay_gateway_debit_banks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_gateway_events`
--

DROP TABLE IF EXISTS `pay_gateway_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay_gateway_events` (
  `id` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `gateway_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'id do gateway',
  `event_key` varchar(50) DEFAULT NULL COMMENT 'chave do evento',
  `event_type` varchar(50) DEFAULT NULL COMMENT 'tipo do evento',
  `event_status` varchar(50) DEFAULT NULL COMMENT 'status do evento',
  `content` text COMMENT 'conteúdo do evento',
  `created` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'data do cadastro',
  PRIMARY KEY (`id`),
  KEY `gateway_id` (`gateway_id`),
  KEY `event_key` (`event_key`),
  KEY `event_type` (`event_type`),
  KEY `event_status` (`event_status`),
  KEY `created` (`created`),
  KEY `content` (`content`(10))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='eventos dos gateways de pagamento';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_gateway_events`
--

LOCK TABLES `pay_gateway_events` WRITE;
/*!40000 ALTER TABLE `pay_gateway_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `pay_gateway_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_gateway_methods`
--

DROP TABLE IF EXISTS `pay_gateway_methods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay_gateway_methods` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `gateway_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'id do gateway',
  `method_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'id do metodo',
  `status_origin_id` int(11) unsigned NOT NULL DEFAULT '4' COMMENT 'id da origem do status',
  `status_code` int(11) unsigned NOT NULL DEFAULT '1' COMMENT 'status do registro',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'data de criacao',
  `updated` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT 'data de updated',
  PRIMARY KEY (`id`),
  KEY `fk_gateway_methods_status` (`status_origin_id`,`status_code`),
  KEY `fk_gateway_methods_method` (`method_id`),
  KEY `fk_gateway_methods_gateway` (`gateway_id`),
  CONSTRAINT `fk_gateway_methods_gateway` FOREIGN KEY (`gateway_id`) REFERENCES `pay_gateways` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_gateway_methods_method` FOREIGN KEY (`method_id`) REFERENCES `pay_methods` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_gateway_methods_status` FOREIGN KEY (`status_origin_id`, `status_code`) REFERENCES `apis_status` (`status_origin_id`, `status_code`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='Metodos de pagamentos do gateway';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_gateway_methods`
--

LOCK TABLES `pay_gateway_methods` WRITE;
/*!40000 ALTER TABLE `pay_gateway_methods` DISABLE KEYS */;
INSERT INTO `pay_gateway_methods` VALUES (1,2,1,4,2,'2018-08-16 22:15:08',NULL),(2,2,2,4,2,'2018-08-16 22:16:35',NULL),(3,2,6,4,2,'2018-08-16 22:16:51',NULL);
/*!40000 ALTER TABLE `pay_gateway_methods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_gateways`
--

DROP TABLE IF EXISTS `pay_gateways`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay_gateways` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT 'nome do gateway',
  `description` varchar(255) DEFAULT '' COMMENT 'descricao do gateway',
  `status_origin_id` int(11) unsigned NOT NULL DEFAULT '4' COMMENT 'id da origem do status',
  `status_code` int(11) unsigned NOT NULL DEFAULT '1' COMMENT 'status do registro',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'data de criacao',
  `updated` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT 'data de updated',
  PRIMARY KEY (`id`),
  KEY `fk_gateways_status` (`status_origin_id`,`status_code`),
  CONSTRAINT `fk_gateways_status` FOREIGN KEY (`status_origin_id`, `status_code`) REFERENCES `apis_status` (`status_origin_id`, `status_code`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Lista do Gateways';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_gateways`
--

LOCK TABLES `pay_gateways` WRITE;
/*!40000 ALTER TABLE `pay_gateways` DISABLE KEYS */;
INSERT INTO `pay_gateways` VALUES (1,'Outros','Nao usa gateway',4,2,'2018-08-16 16:01:47',NULL),(2,'Moip','',4,2,'2018-08-16 18:31:33',NULL);
/*!40000 ALTER TABLE `pay_gateways` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_methods`
--

DROP TABLE IF EXISTS `pay_methods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay_methods` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT 'nome do metodo',
  `status_origin_id` int(11) unsigned NOT NULL DEFAULT '4' COMMENT 'id da origem do status',
  `status_code` int(11) unsigned NOT NULL DEFAULT '1' COMMENT 'status do registro',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'data de criacao',
  `updated` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT 'data de updated',
  PRIMARY KEY (`id`),
  KEY `fk_methods_status` (`status_origin_id`,`status_code`),
  CONSTRAINT `fk_methods_status` FOREIGN KEY (`status_origin_id`, `status_code`) REFERENCES `apis_status` (`status_origin_id`, `status_code`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Lista dos metodos de pagamento';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_methods`
--

LOCK TABLES `pay_methods` WRITE;
/*!40000 ALTER TABLE `pay_methods` DISABLE KEYS */;
INSERT INTO `pay_methods` VALUES (1,'Boleto',4,2,'2018-08-16 17:50:06',NULL),(2,'Cartão de Crédito',4,2,'2018-08-16 17:50:06',NULL),(3,'Cartão de Débito',4,2,'2018-08-16 17:50:06',NULL),(4,'Cheque',4,2,'2018-08-16 17:50:06',NULL),(5,'Débito em Conta',4,2,'2018-08-16 21:34:44',NULL),(6,'Débito On-line',4,2,'2018-08-16 21:34:26',NULL),(7,'Gratuito',4,2,'2018-08-16 17:50:06',NULL),(8,'Transferência eletrônica',4,2,'2018-08-16 17:50:06',NULL);
/*!40000 ALTER TABLE `pay_methods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_register_logs`
--

DROP TABLE IF EXISTS `pay_register_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay_register_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `register_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT 'id do registro de pagamento',
  `paid` tinyint(1) DEFAULT NULL COMMENT 'se pago',
  `status_code` int(11) unsigned NOT NULL DEFAULT '1' COMMENT 'status do registro',
  `created` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'data de criacao',
  PRIMARY KEY (`id`),
  KEY `register_id` (`register_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Registro das alteracoes no pay register';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_register_logs`
--

LOCK TABLES `pay_register_logs` WRITE;
/*!40000 ALTER TABLE `pay_register_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `pay_register_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_registers`
--

DROP TABLE IF EXISTS `pay_registers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay_registers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT 'id da order',
  `credit_card_id` bigint(20) unsigned DEFAULT NULL COMMENT 'id do cartao',
  `gateway_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'id do gateway',
  `method_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'id metodo de pagamento',
  `value` decimal(10,2) DEFAULT NULL COMMENT 'valor do pagamento',
  `installments` int(3) unsigned NOT NULL DEFAULT '1' COMMENT 'numero de parcelas',
  `paid` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT 'se pago',
  `paid_date` timestamp NULL DEFAULT NULL COMMENT 'dia que foi confirmado o pagamento',
  `acquirer_code` varchar(40) DEFAULT NULL COMMENT 'codigo do adquirente se houver',
  `order_code` varchar(40) DEFAULT NULL COMMENT 'codigo da ordem no adquirente se houver',
  `payment_code` varchar(40) DEFAULT NULL COMMENT 'codigo do pagamento no adquirente se houver',
  `checkout_url` varchar(255) DEFAULT NULL COMMENT 'url de checkout do adquirent se houver',
  `observation` varchar(255) DEFAULT NULL COMMENT 'observacoes sobre o pagamento',
  `status_origin_id` int(11) unsigned NOT NULL DEFAULT '4' COMMENT 'id da origem do status',
  `status_code` int(11) unsigned NOT NULL DEFAULT '1' COMMENT 'status do registro',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'data de criacao',
  `updated` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT 'data de updated',
  PRIMARY KEY (`id`),
  KEY `fk_registers_gateways` (`gateway_id`),
  KEY `fk_registers_status` (`status_origin_id`,`status_code`),
  KEY `fk_registers_methods` (`method_id`),
  KEY `purchase_id` (`order_id`),
  KEY `installments` (`installments`),
  KEY `paid` (`paid`),
  KEY `acquirer_code` (`acquirer_code`),
  KEY `order_code` (`order_code`),
  KEY `payment_code` (`payment_code`),
  KEY `created` (`created`),
  KEY `updated` (`updated`),
  KEY `credit_card_id` (`credit_card_id`),
  CONSTRAINT `fk_register_order` FOREIGN KEY (`order_id`) REFERENCES `cli_orders` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_registers_credit_card` FOREIGN KEY (`credit_card_id`) REFERENCES `apis_credit_card` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_registers_gateways` FOREIGN KEY (`gateway_id`) REFERENCES `pay_gateways` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_registers_methods` FOREIGN KEY (`method_id`) REFERENCES `pay_methods` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_registers_status` FOREIGN KEY (`status_origin_id`, `status_code`) REFERENCES `apis_status` (`status_origin_id`, `status_code`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Registros de pagamento';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_registers`
--

LOCK TABLES `pay_registers` WRITE;
/*!40000 ALTER TABLE `pay_registers` DISABLE KEYS */;
/*!40000 ALTER TABLE `pay_registers` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`digi5`@`%`*/ /*!50003 TRIGGER `registers_before_insert`
	BEFORE INSERT ON `pay_registers`
	FOR EACH ROW
BEGIN
	IF(NEW.paid = 1) THEN
		SET NEW.paid_date=NOW();
	END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`digi5`@`%`*/ /*!50003 TRIGGER `register_logs_after_insert`
	AFTER INSERT ON `pay_registers`
	FOR EACH ROW
BEGIN
		INSERT INTO
			pay_register_logs
		SET
			register_id=NEW.id,
			paid=NEW.paid,
			status_code=NEW.status_code;  
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`digi5`@`%`*/ /*!50003 TRIGGER `registers_before_update`
	BEFORE UPDATE ON `pay_registers`
	FOR EACH ROW
BEGIN
	IF(NEW.paid = 1 AND OLD.paid_date IS NULL) THEN
		SET NEW.paid_date=NOW();
	END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`digi5`@`%`*/ /*!50003 TRIGGER `register_logs_after_update`
	AFTER UPDATE ON `pay_registers`
	FOR EACH ROW
BEGIN
		IF(NEW.status_code != OLD.status_code) THEN
			INSERT INTO
				pay_register_logs
			SET
				register_id=NEW.id,
				paid=NEW.paid,
				status_code=NEW.status_code;
		END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Dumping routines for database 'digi5'
--
/*!50003 DROP PROCEDURE IF EXISTS `customer_address` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`digi5`@`%` PROCEDURE `customer_address`(
	IN customer_id INT,
	IN exec BOOLEAN
)
    READS SQL DATA
    SQL SECURITY INVOKER
STAGE_01: BEGIN
	
	-- DECLARE EXIT HANDLER FOR SQLSTATE '42S22'
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
	BEGIN
		SELECT 0 AS proc_status_id, 'Erro ao solicitar os dados customer_address, consulte o administrador da Api.' AS proc_status;
	END;
  
	-- Id não informado
	IF(customer_id IS NULL OR customer_id = '') THEN
		SELECT 0 AS proc_status_id, 'Erro ao solicitar os dados customer_address, customer_id não informado' AS proc_status;
		LEAVE STAGE_01;
	END IF;
	
	-- Query para a listagem
	SET @query = CONCAT("
		SELECT
			apis_address_types.id AS address_types_id,
			apis_address_types.name AS address_types_name,
			apis_address.id AS address_id,
			apis_address.public_place AS address_public_place,
			apis_address.number AS address_number,
			apis_address.complement AS address_complement,
			apis_address.neighborhood AS address_neighborhood,
			apis_address.city AS address_city,
			apis_address.state AS address_state,
			apis_address.country AS address_country,
			apis_address.zip AS address_zip,
			apis_address.lat AS address_lat,
			apis_address.lng AS address_lng,
			apis_status.status_code AS address_status_id,
			apis_status.name AS address_status_name,
			apis_address.created
		FROM
			apis_address
				INNER JOIN
					apis_address_types
						ON
							apis_address_types.id = apis_address.address_type_id
				INNER JOIN
					apis_status
						ON
							apis_status.status_origin_id = apis_address.status_origin_id
						AND
							apis_status.status_code = apis_address.status_code
		WHERE
			apis_address.address_base_id = 1
		AND
			apis_address.address_ref_id = " , customer_id , "
		ORDER BY
			apis_address_types.name
	");

	-- Executa a query ou a retorna
	IF(exec) THEN
		PREPARE statement FROM @query;
		EXECUTE statement;
		DEALLOCATE PREPARE statement;
	ELSE
		SELECT @query;
	END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `customer_document` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`digi5`@`%` PROCEDURE `customer_document`(
	IN customer_id INT,
	IN exec BOOLEAN
)
    READS SQL DATA
    SQL SECURITY INVOKER
STAGE_01: BEGIN
	
	-- DECLARE EXIT HANDLER FOR SQLSTATE '42S22'
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
	BEGIN
		SELECT 0 AS proc_status_id, 'Erro ao solicitar os dados customer_document, consulte o administrador da Api.' AS proc_status;
	END;
  
	-- Id não informado
	IF(customer_id IS NULL OR customer_id = '') THEN
		SELECT 0 AS proc_status_id, 'Erro ao solicitar os dados customer_document, customer_id não informado' AS proc_status;
		LEAVE STAGE_01;
	END IF;
	
	-- Query para a listagem
	SET @query = CONCAT("
		SELECT
			apis_document_types.id	AS document_type_id,
			apis_document_types.name AS document_type_name,
			apis_document_emitters.id AS document_emitter_id,
			apis_document_emitters.name AS document_emitter_name,
			cli_customer_documents.number AS document_number,
			cli_customer_documents.issue_date AS document_issue_date,
			apis_status.status_code AS document_status_id,
			apis_status.name AS document_status_name,
			cli_customer_documents.created
		FROM
			cli_customer_documents
				INNER JOIN
					apis_document_types
						ON
							apis_document_types.id = cli_customer_documents.document_type_id
				INNER JOIN
					apis_document_emitters
						ON
							apis_document_emitters.id = cli_customer_documents.document_emitter_id
				INNER JOIN
					apis_status
						ON
							apis_status.status_origin_id = cli_customer_documents.status_origin_id
						AND
							apis_status.status_code = cli_customer_documents.status_code
							
		WHERE
			cli_customer_documents.customer_id = " , customer_id , "
		ORDER BY
			apis_document_types.name
	");

	-- Executa a query ou a retorna
	IF(exec) THEN
		PREPARE statement FROM @query;
		EXECUTE statement;
		DEALLOCATE PREPARE statement;
	ELSE
		SELECT @query;
	END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `customer_mail` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`digi5`@`%` PROCEDURE `customer_mail`(
	IN customer_id INT,
	IN exec BOOLEAN
)
    READS SQL DATA
    SQL SECURITY INVOKER
STAGE_01: BEGIN
	
	-- DECLARE EXIT HANDLER FOR SQLSTATE '42S22'
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
	BEGIN
		SELECT 0 AS proc_status_id, 'Erro ao solicitar os dados customer_mail, consulte o administrador da Api.' AS proc_status;
	END;
  
	-- Id não informado
	IF(customer_id IS NULL OR customer_id = '') THEN
		SELECT 0 AS proc_status_id, 'Erro ao solicitar os dados customer_mail, customer_id não informado' AS proc_status;
		LEAVE STAGE_01;
	END IF;
	
	-- Query para a listagem
	SET @query = CONCAT("
		SELECT
			apis_mail_types.id AS mail_types_id,
			apis_mail_types.name AS mail_types_name,
			cli_customer_mails.id AS mail_id,
			cli_customer_mails.mail mail_mail,
			apis_status.status_code AS mail_status_id,
			apis_status.name AS mail_status_name,
			cli_customer_mails.created
		FROM
			cli_customer_mails
				INNER JOIN
					apis_mail_types
						ON
							apis_mail_types.id = cli_customer_mails.mail_type_id
				INNER JOIN
					apis_status
						ON
							apis_status.status_origin_id = cli_customer_mails.status_origin_id
						AND
							apis_status.status_code = cli_customer_mails.status_code
		WHERE
			cli_customer_mails.customer_id = " , customer_id , "
		ORDER BY
			apis_mail_types.name
	");

	-- Executa a query ou a retorna
	IF(exec) THEN
		PREPARE statement FROM @query;
		EXECUTE statement;
		DEALLOCATE PREPARE statement;
	ELSE
		SELECT @query;
	END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `customer_phone` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`digi5`@`%` PROCEDURE `customer_phone`(
	IN customer_id INT,
	IN exec BOOLEAN
)
    READS SQL DATA
    SQL SECURITY INVOKER
STAGE_01: BEGIN
	
	-- DECLARE EXIT HANDLER FOR SQLSTATE '42S22'
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
	BEGIN
		SELECT 0 AS proc_status_id, 'Erro ao solicitar os dados proc_customer_phones, consulte o administrador da Api.' AS proc_status;
	END;
  
	-- Id não informado
	IF(customer_id IS NULL OR customer_id = '') THEN
		SELECT 0 AS proc_status_id, 'Erro ao solicitar os dados proc_customer_phones, customer_id não informado' AS proc_status;
		LEAVE STAGE_01;
	END IF;
	
	-- Query para a listagem
	SET @query = CONCAT("
		SELECT
			apis_phone_types.id AS phone_type_id,
			apis_phone_types.name AS phone_type_name,
			cli_customer_phones.id AS phone_id,
			cli_customer_phones.phone AS phone_number,
			apis_status.status_code AS phone_status_id,
			apis_status.name AS phone_status_name,
			cli_customer_phones.created
		FROM
			cli_customer_phones
				INNER JOIN
					apis_phone_types
						ON
							apis_phone_types.id = cli_customer_phones.phone_type_id
				INNER JOIN
					apis_status
						ON
							apis_status.status_code = cli_customer_phones.status_code
						AND
							apis_status.status_origin_id = cli_customer_phones.status_origin_id
		WHERE
			cli_customer_phones.customer_id = " , customer_id , "
		ORDER BY
			apis_phone_types.name
	");

	-- Executa a query ou a retorna
	IF(exec) THEN
		PREPARE statement FROM @query;
		EXECUTE statement;
		DEALLOCATE PREPARE statement;
	ELSE
		SELECT @query;
	END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-09-16 22:48:34
